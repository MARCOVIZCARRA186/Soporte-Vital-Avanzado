import React, { useState } from 'react';
import TopBar from './components/navigation/TopBar';
import InteractiveMegaMenu from './components/navigation/InteractiveMegaMenu';
import ArrestCodeTimer from './components/acls/ArrestCodeTimer';
import ArrhythmiaCenter from './components/arrhythmias/ArrhythmiaCenter';
import DrugFlashcards from './components/pharmacology/DrugFlashcards';
import CalculatorsHub, { SubCalcId } from './components/calculators/CalculatorsHub';
import AirwayProtocols from './components/airway/AirwayProtocols';
import CriticalProtocols from './components/protocols/CriticalProtocols';
import { 
  Activity, Zap, Pill, Calculator, Shield, 
  Heart, Package, Check, LayoutGrid 
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('farmacos');
  const [activeSubCalc, setActiveSubCalc] = useState<SubCalcId>('dosis');
  const [activeAclsSubTab, setActiveAclsSubTab] = useState<'reanimacion' | 'post_paro'>('reanimacion');
  const [isNightMode, setIsNightMode] = useState<boolean>(false);
  const [isMegaMenuOpen, setIsMegaMenuOpen] = useState<boolean>(false);

  const handleMegaNavigate = (tab: string, subTab?: string) => {
    setActiveTab(tab);
    if (tab === 'calculadoras' && subTab) {
      setActiveSubCalc(subTab as SubCalcId);
    }
    if (tab === 'acls' && subTab) {
      setActiveAclsSubTab(subTab as 'reanimacion' | 'post_paro');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className={`min-h-screen flex flex-col transition-colors ${
      isNightMode ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'
    }`}>
      {/* 3-Zone Contract Top Bar with Mega Menu Trigger */}
      <TopBar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        isNightMode={isNightMode}
        setIsNightMode={setIsNightMode}
        onOpenMegaMenu={() => setIsMegaMenuOpen(true)}
      />

      {/* Interactive Mega Menu Modal / Drawer */}
      <InteractiveMegaMenu 
        isOpen={isMegaMenuOpen}
        onClose={() => setIsMegaMenuOpen(false)}
        onNavigate={handleMegaNavigate}
      />

      {/* Cruz Roja Quick Action Strip */}
      <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 py-2.5 transition-colors">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse" />
            <span className="font-bold text-slate-900 dark:text-white">Soporte Vital Avanzado Prehospitalario</span>
            <span className="text-slate-400 hidden sm:inline">· 42 Medicamentos, Dosis, Vía Aérea y Soporte Vital</span>
          </div>

          {/* Quick-switch buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
            {[
              { id: 'farmacos', label: 'Farmacología & Botiquín (42)', icon: Pill },
              { id: 'calculadoras', label: 'Calculadoras Clínicas', icon: Calculator },
              { id: 'acls', label: 'Código Paro ACLS', icon: Heart },
              { id: 'arritmias', label: 'Arritmias & ECG', icon: Zap },
              { id: 'via_aerea', label: 'Vía Aérea SRI', icon: Shield },
              { id: 'protocolos', label: 'Protocolos Críticos', icon: Activity },
            ].map(item => {
              const Icon = item.icon;
              const isCurrent = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                    isCurrent
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'farmacos' && <DrugFlashcards />}
        {activeTab === 'calculadoras' && (
          <CalculatorsHub 
            initialSubCalc={activeSubCalc}
            onSubCalcChange={(calc) => setActiveSubCalc(calc)}
          />
        )}
        {activeTab === 'acls' && <ArrestCodeTimer initialTab={activeAclsSubTab} />}
        {activeTab === 'arritmias' && <ArrhythmiaCenter />}
        {activeTab === 'via_aerea' && <AirwayProtocols />}
        {activeTab === 'protocolos' && <CriticalProtocols />}
      </main>

      {/* Minimalist Medical Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 py-5 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3 font-mono">
          <div className="flex items-center gap-2">
            <span className="font-bold text-red-600">Soporte Vital Avanzado Prehospitalario</span>
            <span>·</span>
            <span>Manual Táctico y Formulario Oficial de Cuidados Críticos</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <button
              type="button"
              onClick={() => setIsMegaMenuOpen(true)}
              className="text-red-600 hover:underline flex items-center gap-1"
            >
              <LayoutGrid className="w-3 h-3" />
              <span>Ver Menú Completo de Secciones</span>
            </button>
            <span>·</span>
            <span>Guías AHA / ERC / ITLS / PHTLS</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
