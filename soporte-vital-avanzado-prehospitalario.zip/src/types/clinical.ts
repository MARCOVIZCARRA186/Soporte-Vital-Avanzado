export type DrugCategory = 
  | 'resucitacion' 
  | 'sedacion_analgesia' 
  | 'via_aerea' 
  | 'vasoactivos' 
  | 'antiarritmicos' 
  | 'respiratorio' 
  | 'antidotos' 
  | 'cardiovascular'
  | 'electrolitos'
  | 'antiinflamatorios'
  | 'antiemeticos'
  | 'neurologico';

export interface DrugDosageGuide {
  adulto: string;
  pediatrico?: string;
  formulaMgKg?: number; // default dose in mg/kg
  formulaMcgKg?: number; // default dose in mcg/kg
  maxDose?: string;
  dilucionSugerida?: string;
}

export interface DrugItem {
  id: string;
  nombre: string;
  nombreComercial?: string;
  clasificacion: string; // e.g. "Antiagregante plaquetario", "Agonista adrenérgico"
  categoria: DrugCategory;
  presentacion: string; // e.g. "Comprimidos 100 mg y 500 mg", "Ampolla 1 mg / 1 mL"
  concentracion: string;
  mgPorMl: number; // For dosage calculator (or mg per unit)
  dosisPorDefecto?: {
    tipo: 'mg/kg' | 'mcg/kg' | 'mg_fijo';
    valor: number;
    etiqueta: string;
  };
  dosisPresets?: Array<{
    label: string;
    doseVal: number;
    unit: 'mg/kg' | 'mcg/kg' | 'mg_fijo';
  }>;
  viasAdministracion: string[]; // ['IV', 'IO', 'IM', 'IN', 'SL', 'VO', 'Neb', 'SC']
  indicaciones: string[];
  contraindicaciones: string[];
  dosis: DrugDosageGuide;
  mecanismoAccion: {
    farmacodinamia: string;
    farmacocinetica: {
      inicio: string;
      pico: string;
      duracion: string;
      metabolismoSemivida: string;
    };
  };
  efectosSecundarios: string[];
  efectosAdversos: string[];
  txSobredosis: string;
  riesgoEmbarazo: 'A' | 'B' | 'C' | 'D' | 'X';
  puntosImportantes: string[];
  flashcard: {
    pregunta: string;
    respuesta: string;
    puntosClave: string[];
  };
}

export interface InventoryItem {
  id: string;
  drugId?: string;
  nombre: string;
  presentacion: string;
  cantidad: number;
  ubicacion?: string; // e.g. "Mochila Vía Aérea", "Botiquín Central", "Cajón Rojo"
  fechaCaducidad?: string;
  notas?: string;
}

export interface VasoactiveDrugPreset {
  id: string;
  nombre: string;
  ampollaMg: number;
  ampollaMl: number;
  dilucionEstandarMl: number;
  unidadDosis: 'mcg/kg/min' | 'mcg/min' | 'mg/h';
  rangoDosis: { min: number; max: number; tipico: number };
  vehiculo: string;
  indicacion: string;
}

export interface ArrhythmiaItem {
  id: string;
  nombre: string;
  categoria: 'paro_desfibrilable' | 'paro_no_desfibrilable' | 'taquicardia' | 'bradicardia';
  esDesfibrilable: boolean;
  fcTipica: string;
  criteriosECG: string[];
  significadoClinico: string;
  tratamientoInmediato: {
    paso1: string;
    farmaco1?: string;
    paso2?: string;
    farmaco2?: string;
    cuidadosAvanzados: string[];
  };
  svgWaveformType: 'vf_coarse' | 'vf_fine' | 'vt_mono' | 'torsades' | 'asystole' | 'pea' | 'svt' | 'afib' | 'aflutter' | 'sinus_brady' | 'av_block_1' | 'av_block_2_1' | 'av_block_2_2' | 'av_block_3';
}

export interface CPRCodeLog {
  timestamp: string;
  minutoRelativo: string;
  tipo: 'descarga' | 'adrenalina' | 'amiodarona' | 'lidocaina' | 'ritmo' | 'via_aerea' | 'rosc' | 'nota';
  detalle: string;
}
