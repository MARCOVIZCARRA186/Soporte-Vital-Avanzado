import React from 'react';
import { Activity, Plus, Shield, Moon, Sun, Menu, LayoutGrid } from 'lucide-react';

interface TopBarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isNightMode?: boolean;
  setIsNightMode?: (val: boolean) => void;
  onOpenMegaMenu: () => void;
}

export default function TopBar({ 
  activeTab, 
  setActiveTab, 
  isNightMode, 
  setIsNightMode,
  onOpenMegaMenu 
}: TopBarProps) {
  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-950/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between gap-4 h-16">
        {/* Zone 1: Wordmark with iconic Cruz Roja badge & MegaMenu Trigger */}
        <div className="flex items-center gap-3">
          <div 
            onClick={() => setActiveTab('farmacos')}
            className="flex items-center gap-2.5 cursor-pointer shrink-0 select-none"
          >
            {/* Iconic Cruz Roja Cross */}
            <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center text-white font-black shadow-xs">
              <span className="text-xl font-bold leading-none select-none">+</span>
            </div>
            <div>
              <span className="text-sm sm:text-base font-extrabold tracking-tight text-slate-900 dark:text-white whitespace-nowrap block leading-tight">
                Soporte Vital Avanzado <span className="text-red-600">Prehospitalario</span>
              </span>
              <span className="text-[10px] text-slate-400 font-medium hidden md:block leading-none mt-0.5">
                Cruz Roja · Guías Clínicas de Emergencia
              </span>
            </div>
          </div>

          {/* Interactive Menu Button (1-click to all sections) */}
          <button
            type="button"
            onClick={onOpenMegaMenu}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-bold transition-all shadow-2xs"
            title="Abrir menú interactivo con todas las secciones"
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Menú Interactivo</span>
            <span className="sm:hidden">Menú</span>
          </button>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-6 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('farmacos')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'farmacos' 
                ? 'text-red-600 border-b-2 border-red-600 font-bold' 
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Farmacología & Botiquín
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('calculadoras')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'calculadoras' 
                ? 'text-red-600 border-b-2 border-red-600 font-bold' 
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Calculadoras Clínicas
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('acls')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'acls' 
                ? 'text-red-600 border-b-2 border-red-600 font-bold' 
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Paro ACLS
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('arritmias')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'arritmias' 
                ? 'text-red-600 border-b-2 border-red-600 font-bold' 
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Arritmias & ECG
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('via_aerea')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'via_aerea' 
                ? 'text-red-600 border-b-2 border-red-600 font-bold' 
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Vía Aérea SRI
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('protocolos')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'protocolos' 
                ? 'text-red-600 border-b-2 border-red-600 font-bold' 
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Protocolos Críticos
          </button>
        </nav>

        {/* Zone 3: Primary Action & Night Mode */}
        <div className="flex items-center gap-2 shrink-0">
          {setIsNightMode && (
            <button
              type="button"
              onClick={() => setIsNightMode(!isNightMode)}
              className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white text-xs transition-colors"
              title={isNightMode ? 'Modo Clínico Claro Cruz Roja' : 'Modo Nocturno Ambulancia'}
            >
              {isNightMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>
          )}

          <button
            type="button"
            onClick={() => setActiveTab('acls')}
            className="px-3.5 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors whitespace-nowrap shadow-xs flex items-center gap-1.5"
          >
            <Activity className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Código de Paro</span>
            <span className="sm:hidden">Paro</span>
          </button>
        </div>
      </div>
    </header>
  );
}
