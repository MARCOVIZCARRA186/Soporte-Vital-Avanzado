import React, { useState } from 'react';
import { 
  X, Search, Pill, Package, Calculator, Scale, Droplets, 
  Wind, Flame, HeartPulse, Brain, Zap, Heart, Shield, 
  Activity, ArrowRight, Sparkles, Check, ChevronRight, Eye, Stethoscope 
} from 'lucide-react';

export interface NavigationTarget {
  tab: string;
  subTab?: string;
  label: string;
  categoria: 'Farmacología' | 'Calculadoras' | 'Soporte Cardíaco' | 'Vía Aérea & Ventilación' | 'Protocolos';
  icon: any;
  descripcion: string;
  badge?: string;
}

export const ALL_APP_SECTIONS: NavigationTarget[] = [
  // Farmacología & Botiquín
  {
    tab: 'farmacos',
    subTab: 'buscador',
    label: 'Farmacología & Flashcards (42 Fármacos)',
    categoria: 'Farmacología',
    icon: Pill,
    descripcion: 'Buscador de tarjetas, dosis, contraindicaciones, farmacodinamia y modo estudio.',
    badge: '42 Medicamentos'
  },
  {
    tab: 'farmacos',
    subTab: 'botiquin',
    label: 'Botiquín Móvil de Ambulancia',
    categoria: 'Farmacología',
    icon: Package,
    descripcion: 'Inventario de medicamentos disponibles en ambulancia, ampollas y stock.',
    badge: 'Inventario'
  },

  // Calculadoras
  {
    tab: 'calculadoras',
    subTab: 'dosis',
    label: 'Calculador de Dosis por Fármaco',
    categoria: 'Calculadoras',
    icon: Calculator,
    descripcion: 'Dosis por peso, concentración y cálculo de volumen a extraer en mL.',
    badge: 'Bolo & mL'
  },
  {
    tab: 'calculadoras',
    subTab: 'peso_ideal',
    label: 'Formulador de Peso Ideal & PBW',
    categoria: 'Calculadoras',
    icon: Scale,
    descripcion: 'Fórmulas de Devine, Robinson, peso ajustado e IMC para hombres y mujeres.',
    badge: 'Devine / Robinson'
  },
  {
    tab: 'calculadoras',
    subTab: 'infusiones',
    label: 'Bombas de Infusión y Microgoteros',
    categoria: 'Calculadoras',
    icon: Droplets,
    descripcion: 'Infusiones continuas vasoactivas (mL/h, microgotas/min y gotas/min).',
    badge: 'Bombas & Goteo'
  },
  {
    tab: 'calculadoras',
    subTab: 'ventilacion',
    label: 'Ventilación Mecánica & Capnografía (EtCO₂)',
    categoria: 'Vía Aérea & Ventilación',
    icon: Wind,
    descripcion: 'Parámetros ARDSNet (Vt, VE, ΔP, Kirby) y Curvas de Capnografía interactivas.',
    badge: 'ARDSNet & Curvas'
  },
  {
    tab: 'calculadoras',
    subTab: 'parkland',
    label: 'Quemados: Regla de los 9 y Parkland',
    categoria: 'Calculadoras',
    icon: Flame,
    descripcion: 'Superficie corporal quemada (% SCQ) y horario de líquidos Ringer Lactato (8h/16h).',
    badge: 'SCQ & Líquidos'
  },
  {
    tab: 'calculadoras',
    subTab: 'shock',
    label: 'Índice de Choque (SI, MSI y SIPA)',
    categoria: 'Calculadoras',
    icon: HeartPulse,
    descripcion: 'Detección temprana de shock oculto, hemorragia activa y riesgo de transfusión.',
    badge: 'SI / MSI / SIPA'
  },
  {
    tab: 'calculadoras',
    subTab: 'glasgow',
    label: 'Escala de Coma de Glasgow y GCS-P',
    categoria: 'Calculadoras',
    icon: Brain,
    descripcion: 'Evaluación neurológica objetiva, reactividad pupilar y umbral de intubación (≤ 8).',
    badge: 'GCS & Pupilas'
  },

  // Soporte Cardíaco & Arritmias
  {
    tab: 'arritmias',
    label: 'Arritmias & ECG (17 Arritmias)',
    categoria: 'Soporte Cardíaco',
    icon: Zap,
    descripcion: 'Trazo ECG, signos de inestabilidad, cardioversión + pseudoanalgesia y post-paro.',
    badge: '17 Arritmias'
  },
  {
    tab: 'acls',
    label: 'Director de Paro Cardíaco ACLS',
    categoria: 'Soporte Cardíaco',
    icon: Heart,
    descripcion: 'Cronómetro de ciclos de 2 min, metrónomo de RCP a 110 cpm, registro y 5H / 5T.',
    badge: 'Metrónomo 110'
  },
  {
    tab: 'acls',
    subTab: 'post_paro',
    label: 'Cuidados Post-Paro Cardíaco (ROSC)',
    categoria: 'Soporte Cardíaco',
    icon: Activity,
    descripcion: 'Metas PAM ≥ 65, SpO2 92-98%, normocapnia, control térmico 32-36°C y ECG de 12 derivaciones.',
    badge: 'Post-ROSC'
  },

  // Vía Aérea & SRI (AVENTHO)
  {
    tab: 'via_aerea',
    label: 'Vía Aérea SRI (AVENTHO 2019)',
    categoria: 'Vía Aérea & Ventilación',
    icon: Shield,
    descripcion: 'Protocolo de las 7P, paciente inestable, valoración LEMON, 3-3-2 y SOAPME.',
    badge: 'AVENTHO SRI'
  },
  {
    tab: 'via_aerea',
    subTab: 'indicaciones',
    label: 'Indicaciones de Ventilación Mecánica',
    categoria: 'Vía Aérea & Ventilación',
    icon: Stethoscope,
    descripcion: 'Criterios clínicos de insuficiencia respiratoria, protección y neurológicos (Pág. 2).',
    badge: 'AVENTHO Pág. 2'
  },
  {
    tab: 'via_aerea',
    subTab: 'farmacos_sri',
    label: 'Sedantes & Relajantes Musculares SIR',
    categoria: 'Vía Aérea & Ventilación',
    icon: Pill,
    descripcion: 'Etomidato, Ketamina, Propofol, Rocuronio, Succinilcolina y latencias (Págs. 4-5).',
    badge: 'Dosis & Inicio'
  },

  // Protocolos Críticos
  {
    tab: 'protocolos',
    label: 'Protocolos Iniciales para Pacientes Críticos',
    categoria: 'Protocolos',
    icon: Activity,
    descripcion: 'Abordaje XABCDE, Sepsis qSOFA, Código Ictus Cincinnati, IAMCEST y Estatus.',
    badge: 'XABCDE & Ictus'
  },
];

interface InteractiveMegaMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: string, subTab?: string) => void;
}

export default function InteractiveMegaMenu({ isOpen, onClose, onNavigate }: InteractiveMegaMenuProps) {
  const [search, setSearch] = useState('');

  if (!isOpen) return null;

  const filtered = ALL_APP_SECTIONS.filter(sec => 
    sec.label.toLowerCase().includes(search.toLowerCase()) ||
    sec.descripcion.toLowerCase().includes(search.toLowerCase()) ||
    sec.categoria.toLowerCase().includes(search.toLowerCase()) ||
    (sec.badge && sec.badge.toLowerCase().includes(search.toLowerCase()))
  );

  const categories = ['Farmacología', 'Calculadoras', 'Soporte Cardíaco', 'Vía Aérea & Ventilación', 'Protocolos'] as const;

  const handleItemClick = (tab: string, subTab?: string) => {
    onNavigate(tab, subTab);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-150">
      <div 
        className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-150"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between gap-4 bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-red-600 flex items-center justify-center text-white font-black shadow-xs">
              <span className="text-xl leading-none">+</span>
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
                Menú Interactivo de Navegación Rápida
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200 hidden sm:inline">
                  Cruz Roja APH
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                Acceso directo a todas las herramientas, calculadoras y protocolos clínicos
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
            title="Cerrar menú"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search bar */}
        <div className="p-4 border-b border-slate-100 bg-white">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              autoFocus
              placeholder="Buscar cualquier sección, cálculo o protocolo (ej: Glasgow, Adrenalina, Parkland, EtCO2, 332...)"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-red-500 focus:bg-white transition-colors"
            />
          </div>
        </div>

        {/* Content list organized by categories */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {search ? (
            <div>
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                Resultados de búsqueda ({filtered.length})
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {filtered.map((item, idx) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleItemClick(item.tab, item.subTab)}
                      className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-red-400 hover:bg-red-50/40 text-left transition-all flex items-start gap-3 group shadow-2xs"
                    >
                      <div className="w-8 h-8 rounded-lg bg-red-50 border border-red-100 flex items-center justify-center text-red-600 shrink-0 group-hover:bg-red-600 group-hover:text-white transition-colors">
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-xs font-bold text-slate-900 group-hover:text-red-700 truncate">
                            {item.label}
                          </span>
                          {item.badge && (
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 shrink-0">
                              {item.badge}
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1 leading-snug">
                          {item.descripcion}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
              {filtered.length === 0 && (
                <div className="text-center py-10 text-slate-400 text-xs">
                  No se encontraron secciones para "{search}". Intente con otro término.
                </div>
              )}
            </div>
          ) : (
            categories.map(cat => {
              const catItems = ALL_APP_SECTIONS.filter(s => s.categoria === cat);
              return (
                <div key={cat} className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-600" />
                      {cat}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">
                      {catItems.length} accesos
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {catItems.map((item, idx) => {
                      const Icon = item.icon;
                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => handleItemClick(item.tab, item.subTab)}
                          className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-red-400 hover:bg-red-50/40 text-left transition-all flex items-start gap-3 group shadow-2xs"
                        >
                          <div className="w-8 h-8 rounded-lg bg-red-50 border border-red-100 flex items-center justify-center text-red-600 shrink-0 group-hover:bg-red-600 group-hover:text-white transition-colors">
                            <Icon className="w-4 h-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-xs font-bold text-slate-900 group-hover:text-red-700 truncate">
                                {item.label}
                              </span>
                              {item.badge && (
                                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 shrink-0">
                                  {item.badge}
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1 leading-snug">
                              {item.descripcion}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3 px-5 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-[11px] text-slate-500 font-mono">
          <span>Haga clic en cualquier sección para saltar directamente</span>
          <span className="text-red-600 font-bold">Cruz Roja APH Pro</span>
        </div>
      </div>
    </div>
  );
}
