import React, { useState } from 'react';
import { 
  Activity, AlertTriangle, ShieldAlert, CheckCircle2, 
  ChevronRight, ChevronDown, Clock, Search 
} from 'lucide-react';
import { CRITICAL_PROTOCOLS, CriticalProtocol } from '../../data/criticalProtocolsData';

export default function CriticalProtocols() {
  const [selectedProtocolId, setSelectedProtocolId] = useState<string>('xabcde');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Interactive qSOFA state for Sepsis
  const [qsofaFr, setQsofaFr] = useState<boolean>(false);
  const [qsofaGcs, setQsofaGcs] = useState<boolean>(false);
  const [qsofaTas, setQsofaTas] = useState<boolean>(false);

  // Interactive Cincinnati state
  const [cincinFacial, setCincinFacial] = useState<boolean>(false);
  const [cincinBrazo, setCincinBrazo] = useState<boolean>(false);
  const [cincinHabla, setCincinHabla] = useState<boolean>(false);

  const selectedProtocol = CRITICAL_PROTOCOLS.find(p => p.id === selectedProtocolId) || CRITICAL_PROTOCOLS[0];

  const filteredProtocols = CRITICAL_PROTOCOLS.filter(p => 
    p.nombre.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.resumen.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const qsofaScore = (qsofaFr ? 1 : 0) + (qsofaGcs ? 1 : 0) + (qsofaTas ? 1 : 0);
  const cincinnatiCount = (cincinFacial ? 1 : 0) + (cincinBrazo ? 1 : 0) + (cincinHabla ? 1 : 0);

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-600 font-bold">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Protocolos Iniciales para Pacientes Críticos Prehospitalarios
              </h2>
              <p className="text-xs text-slate-500">
                Abordaje Sistemático XABCDE, Sepsis (qSOFA), Código Ictus (Cincinnati), IAMCEST y Estatus Epiléptico
              </p>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-400">Guías Cruz Roja / PHTLS</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Protocol Selector Column */}
          <div className="lg:col-span-4 space-y-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Buscar protocolo o síntoma..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-red-500"
              />
            </div>

            <div className="space-y-2">
              {filteredProtocols.map(proto => {
                const isSelected = proto.id === selectedProtocolId;
                return (
                  <button
                    key={proto.id}
                    type="button"
                    onClick={() => setSelectedProtocolId(proto.id)}
                    className={`w-full text-left p-3 rounded-xl border transition-all ${
                      isSelected
                        ? 'bg-red-50/80 border-red-500 text-slate-900 shadow-2xs font-bold'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className={`text-xs ${isSelected ? 'text-red-700 font-bold' : 'text-slate-900'}`}>
                        {proto.nombre}
                      </span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                        {proto.categoria}
                      </span>
                    </div>
                    <div className="text-[11px] font-mono text-red-600 mt-1 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{proto.tiempoOro}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5 font-normal">
                      {proto.resumen}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Protocol Details & Interactive Calculators */}
          <div className="lg:col-span-8 space-y-4">
            {/* Header of selected protocol */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="text-xs uppercase font-mono tracking-wider text-red-600 font-bold block">
                  {selectedProtocol.categoria}
                </span>
                <h3 className="text-lg font-bold text-slate-900">{selectedProtocol.nombre}</h3>
                <p className="text-xs text-slate-500 mt-0.5">{selectedProtocol.resumen}</p>
              </div>
              <div className="px-3 py-1.5 rounded-lg bg-white border border-slate-200 text-xs font-mono text-slate-700 self-start sm:self-auto shadow-2xs">
                ⏱ Meta: <strong>{selectedProtocol.tiempoOro}</strong>
              </div>
            </div>

            {/* Interactive Sepsis qSOFA if viewing sepsis */}
            {selectedProtocol.id === 'sepsis' && (
              <div className="bg-red-50/50 border border-red-200 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-red-700 uppercase tracking-wider">
                    Score qSOFA de Tamizaje Rápido en Ambulancia
                  </span>
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-white border border-red-200 text-red-700">
                    Puntaje: {qsofaScore} / 3 pts
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <label className="flex items-center gap-2 text-xs bg-white p-2.5 rounded-lg border border-red-100 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={qsofaFr}
                      onChange={(e) => setQsofaFr(e.target.checked)}
                      className="rounded text-red-600"
                    />
                    <span>FR ≥ 22 rpm (+1)</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs bg-white p-2.5 rounded-lg border border-red-100 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={qsofaGcs}
                      onChange={(e) => setQsofaGcs(e.target.checked)}
                      className="rounded text-red-600"
                    />
                    <span>Glasgow &lt; 15 (+1)</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs bg-white p-2.5 rounded-lg border border-red-100 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={qsofaTas}
                      onChange={(e) => setQsofaTas(e.target.checked)}
                      className="rounded text-red-600"
                    />
                    <span>TAS ≤ 100 mmHg (+1)</span>
                  </label>
                </div>

                <div className="text-xs">
                  {qsofaScore >= 2 ? (
                    <span className="font-bold text-red-700">
                      ⚠️ ¡qSOFA POSITIVO (≥ 2)! Alto riesgo de mortalidad hospitalaria por Sepsis / Shock Séptico. Iniciar reposición hídrica a 30 mL/kg y preparar Noradrenalina.
                    </span>
                  ) : (
                    <span className="text-slate-600 font-medium">
                      qSOFA &lt; 2: Mantener sospecha clínica de foco infeccioso y monitorización.
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Interactive Stroke Cincinnati if viewing stroke */}
            {selectedProtocol.id === 'stroke_ictus' && (
              <div className="bg-red-50/50 border border-red-200 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-red-700 uppercase tracking-wider">
                    Escala Prehospitalaria de Cincinnati (CPSS)
                  </span>
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-white border border-red-200 text-red-700">
                    Positivos: {cincinnatiCount} / 3
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <label className="flex items-center gap-2 text-xs bg-white p-2.5 rounded-lg border border-red-100 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={cincinFacial}
                      onChange={(e) => setCincinFacial(e.target.checked)}
                      className="rounded text-red-600"
                    />
                    <span>Asimetría facial al sonreír</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs bg-white p-2.5 rounded-lg border border-red-100 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={cincinBrazo}
                      onChange={(e) => setCincinBrazo(e.target.checked)}
                      className="rounded text-red-600"
                    />
                    <span>Caída del brazo (10s)</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs bg-white p-2.5 rounded-lg border border-red-100 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={cincinHabla}
                      onChange={(e) => setCincinHabla(e.target.checked)}
                      className="rounded text-red-600"
                    />
                    <span>Habla arrastrada o afasia</span>
                  </label>
                </div>

                <div className="text-xs">
                  {cincinnatiCount >= 1 ? (
                    <span className="font-bold text-red-700">
                      🚨 ¡CINCINNATI POSITIVO (probabilidad de ACV &gt; 72%)! Activar Código Ictus prehospitalario, verificar glucemia capilar y determinar última hora visto normal (LKW).
                    </span>
                  ) : (
                    <span className="text-slate-600 font-medium">
                      Marque los hallazgos observados en el examen neurológico rápido.
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Protocol Steps */}
            <div className="space-y-3">
              {selectedProtocol.pasos.map((paso, idx) => (
                <div key={idx} className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs space-y-2">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-md bg-red-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                      {paso.etiqueta}
                    </span>
                    <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">{paso.titulo}</h4>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">{paso.descripcion}</p>

                  <div className="space-y-1 pt-1">
                    {paso.acciones.map((acc, aIdx) => (
                      <div key={aIdx} className="text-xs text-slate-700 flex items-start gap-2">
                        <span className="text-red-500 font-bold shrink-0">•</span>
                        <span>{acc}</span>
                      </div>
                    ))}
                  </div>

                  {paso.alertasRojas && paso.alertasRojas.length > 0 && (
                    <div className="bg-red-50 border border-red-200 p-2.5 rounded-lg mt-2 space-y-1">
                      {paso.alertasRojas.map((alerta, alIdx) => (
                        <div key={alIdx} className="text-[11px] text-red-800 flex items-start gap-1.5 font-medium">
                          <AlertTriangle className="w-3.5 h-3.5 text-red-600 shrink-0 mt-0.5" />
                          <span>{alerta}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Criteria & Pearls */}
            <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-2">
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
                Criterios de Alerta y Perlas Clínicas
              </span>
              <ul className="space-y-1.5">
                {selectedProtocol.criteriosAlerta.map((crit, idx) => (
                  <li key={idx} className="text-xs text-slate-700 flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{crit}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
