import React, { useState } from 'react';
import { 
  Activity, Zap, AlertTriangle, ShieldAlert, Search, 
  CheckCircle2, HeartPulse, Syringe, Scale, HelpCircle, 
  ShieldCheck, Heart, AlertCircle, Sparkles, ChevronRight 
} from 'lucide-react';
import { ARRHYTHMIAS_DATABASE, ExtendedArrhythmiaItem } from '../../data/arrhythmiasData';

export default function ArrhythmiaCenter() {
  const [selectedArrhythmiaId, setSelectedArrhythmiaId] = useState<string>('fv');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Pseudoanalgesia calculator states
  const [patientWeightKg, setPatientWeightKg] = useState<number>(70);
  const [selectedSedative, setSelectedSedative] = useState<'midazolam' | 'fentanilo' | 'ketamina' | 'etomidato'>('midazolam');

  // Hemodynamic instability checklist
  const [instabilitySigns, setInstabilitySigns] = useState({
    hipotension: false,
    conciencia: false,
    dolorToracico: false,
    shock: false,
    insuficienciaCardiaca: false,
  });

  const hasAnyInstability = Object.values(instabilitySigns).some(v => v);

  const currentArrhythmia = ARRHYTHMIAS_DATABASE.find(a => a.id === selectedArrhythmiaId) || ARRHYTHMIAS_DATABASE[0];

  const filteredArrhythmias = ARRHYTHMIAS_DATABASE.filter(a => {
    const matchesCat = filterCategory === 'all' || a.categoria === filterCategory;
    const matchesSearch = a.nombre.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          a.criteriosECG.some(c => c.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  // Calculate pseudoanalgesia dose and mL
  const getPseudoanalgesiaCalc = () => {
    switch (selectedSedative) {
      case 'midazolam':
        const doseMgMida = Number((patientWeightKg * 0.05).toFixed(1));
        const cappedDoseMida = Math.min(5, Math.max(1, doseMgMida));
        const mlMida1 = cappedDoseMida / 1;
        const mlMida5 = cappedDoseMida / 5;
        return {
          nombre: 'Midazolam (Dormicum)',
          dosisCalculada: `${cappedDoseMida} mg IV lento`,
          volumen: `${mlMida5.toFixed(2)} mL (ampolla 5 mg/mL) o ${mlMida1.toFixed(1)} mL (ampolla 1 mg/mL)`,
          notas: 'Inyectar en 1-2 minutos. Efecto en 2-3 min. Produce amnesia retrógrada protectora sin deprimir reflejos de vía aérea.',
        };
      case 'fentanilo':
        const doseMcgFent = Math.min(100, Math.round(patientWeightKg * 1));
        const mlFent = doseMcgFent / 50;
        return {
          nombre: 'Fentanilo',
          dosisCalculada: `${doseMcgFent} mcg IV lento`,
          volumen: `${mlFent.toFixed(1)} mL (ampolla 50 mcg/mL)`,
          notas: 'Inyectar lento en 1-2 minutos. Excelente estabilidad hemodinámica en cardiopatía.',
        };
      case 'ketamina':
        const doseMgKeta = Math.round(patientWeightKg * 0.75);
        const mlKeta = doseMgKeta / 50;
        return {
          nombre: 'Ketamina (Ketolar)',
          dosisCalculada: `${doseMgKeta} mg IV (0.75 mg/kg)`,
          volumen: `${mlKeta.toFixed(2)} mL (vial 50 mg/mL)`,
          notas: 'De elección si el paciente tiene TAS limítrofe o hipotensión (preserva la presión arterial y ventilación).',
        };
      case 'etomidato':
        const doseMgEto = Number((patientWeightKg * 0.15).toFixed(1));
        const mlEto = doseMgEto / 2;
        return {
          nombre: 'Etomidato (Hypnomidate)',
          dosisCalculada: `${doseMgEto} mg IV (0.15 mg/kg)`,
          volumen: `${mlEto.toFixed(1)} mL (ampolla 2 mg/mL)`,
          notas: 'Ideal en cardiopatía isquémica o fracción de eyección severamente deprimida.',
        };
    }
  };

  const pseudoCalc = getPseudoanalgesiaCalc();

  // Waveform renderer
  const renderSvgWaveform = (type: string) => {
    switch (type) {
      case 'vf_coarse':
      case 'vf_fine':
        return (
          <path
            d="M 0 50 Q 15 20, 30 55 T 60 25 T 90 75 T 120 15 T 150 85 T 180 30 T 210 70 T 240 20 T 270 80 T 300 35 T 330 65 T 360 15 T 390 85 T 420 30 T 450 70 T 480 25 T 510 80 T 540 35 T 570 65 T 600 50"
            fill="none"
            stroke="#ef4444"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        );
      case 'vt_mono':
        return (
          <path
            d="M 0 50 Q 20 5, 40 50 Q 60 95, 80 50 Q 100 5, 120 50 Q 140 95, 160 50 Q 180 5, 200 50 Q 220 95, 240 50 Q 260 5, 280 50 Q 300 95, 320 50 Q 340 5, 360 50 Q 380 95, 400 50 Q 420 5, 440 50 Q 460 95, 480 50 Q 500 5, 520 50 Q 540 95, 560 50 Q 580 5, 600 50"
            fill="none"
            stroke="#f97316"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        );
      case 'torsades':
        return (
          <path
            d="M 0 50 Q 15 25, 30 50 Q 45 75, 60 50 Q 75 10, 90 50 Q 105 90, 120 50 Q 135 30, 150 50 Q 165 70, 180 50 Q 195 40, 210 50 Q 225 60, 240 50 Q 255 15, 270 50 Q 285 85, 300 50 Q 315 25, 330 50 Q 345 75, 360 50 Q 375 10, 390 50 Q 405 90, 420 50 Q 435 30, 450 50 Q 465 70, 480 50 Q 495 40, 510 50 Q 525 60, 540 50 Q 555 15, 570 50 Q 585 85, 600 50"
            fill="none"
            stroke="#f43f5e"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        );
      case 'asystole':
        return (
          <path
            d="M 0 50 Q 100 48, 200 52 T 400 50 T 600 51"
            fill="none"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeLinecap="round"
          />
        );
      case 'sinus_brady':
      case 'av_block_1':
      case 'av_block_2_1':
      case 'av_block_2_2':
      case 'av_block_3':
        return (
          <path
            d="M 0 50 L 50 50 Q 60 42, 70 50 L 80 50 L 85 53 L 90 10 L 96 68 L 102 50 L 115 50 Q 135 35, 155 50 L 250 50 Q 260 42, 270 50 L 280 50 L 285 53 L 290 10 L 296 68 L 302 50 L 315 50 Q 335 35, 355 50 L 450 50 Q 460 42, 470 50 L 480 50 L 485 53 L 490 10 L 496 68 L 502 50 L 515 50 Q 535 35, 555 50 L 600 50"
            fill="none"
            stroke="#0ea5e9"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
        );
      case 'svt':
        return (
          <path
            d="M 0 50 L 15 50 L 20 52 L 25 12 L 30 65 L 35 50 Q 45 38, 55 50 L 70 50 L 75 52 L 80 12 L 85 65 L 90 50 Q 100 38, 110 50 L 125 50 L 130 52 L 135 12 L 140 65 L 145 50 Q 155 38, 165 50 L 180 50 L 185 52 L 190 12 L 195 65 L 200 50 Q 210 38, 220 50 L 235 50 L 240 52 L 245 12 L 250 65 L 255 50 Q 265 38, 275 50 L 290 50 L 295 52 L 300 12 L 305 65 L 310 50 Q 320 38, 330 50 L 345 50 L 350 52 L 355 12 L 360 65 L 365 50 Q 375 38, 385 50 L 400 50 L 405 52 L 410 12 L 415 65 L 420 50 Q 430 38, 440 50 L 455 50 L 460 52 L 465 12 L 470 65 L 475 50 Q 485 38, 495 50 L 510 50 L 515 52 L 520 12 L 525 65 L 530 50 Q 540 38, 550 50 L 565 50 L 570 52 L 575 12 L 580 65 L 585 50 Q 595 38, 600 50"
            fill="none"
            stroke="#eab308"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
        );
      case 'afib':
        return (
          <path
            d="M 0 50 Q 5 47, 10 53 T 20 48 T 30 52 L 32 54 L 35 10 L 40 68 L 44 50 Q 50 48, 60 53 T 80 48 T 100 52 L 103 54 L 106 10 L 111 68 L 115 50 Q 125 48, 140 53 T 160 48 T 170 52 L 172 54 L 175 10 L 180 68 L 184 50 Q 200 48, 230 53 T 260 48 T 280 52 L 282 54 L 285 10 L 290 68 L 294 50 Q 310 48, 330 53 T 350 48 T 360 52 L 362 54 L 365 10 L 370 68 L 374 50 Q 390 48, 420 53 T 450 48 T 480 52 L 483 54 L 486 10 L 491 68 L 495 50 Q 510 48, 540 53 T 570 48 T 590 52 L 592 54 L 595 10 L 600 68"
            fill="none"
            stroke="#a855f7"
            strokeWidth="2"
            strokeLinecap="round"
          />
        );
      case 'aflutter':
        return (
          <path
            d="M 0 50 L 10 38 L 20 55 L 30 38 L 40 55 L 42 56 L 45 10 L 50 68 L 54 50 L 64 38 L 74 55 L 84 38 L 94 55 L 104 38 L 114 55 L 116 56 L 119 10 L 124 68 L 128 50 L 138 38 L 148 55 L 158 38 L 168 55 L 178 38 L 188 55 L 190 56 L 193 10 L 198 68 L 202 50 L 212 38 L 222 55 L 232 38 L 242 55 L 252 38 L 262 55 L 264 56 L 267 10 L 272 68 L 276 50 L 286 38 L 296 55 L 306 38 L 316 55 L 326 38 L 336 55 L 338 56 L 341 10 L 346 68 L 350 50 L 360 38 L 370 55 L 380 38 L 390 55 L 400 38 L 410 55 L 412 56 L 415 10 L 420 68 L 424 50 L 434 38 L 444 55 L 454 38 L 464 55 L 474 38 L 484 55 L 486 56 L 489 10 L 494 68 L 498 50 L 508 38 L 518 55 L 528 38 L 538 55 L 548 38 L 558 55 L 560 56 L 563 10 L 568 68 L 572 50 L 582 38 L 592 55 L 600 38"
            fill="none"
            stroke="#6366f1"
            strokeWidth="2"
            strokeLinecap="round"
          />
        );
      default:
        return (
          <path
            d="M 0 50 L 40 50 Q 50 42, 60 50 L 70 50 L 74 53 L 78 12 L 83 66 L 88 50 L 98 50 Q 115 36, 130 50 L 200 50 Q 210 42, 220 50 L 230 50 L 234 53 L 238 12 L 243 66 L 248 50 L 258 50 Q 275 36, 290 50 L 360 50 Q 370 42, 380 50 L 390 50 L 394 53 L 398 12 L 403 66 L 408 50 L 418 50 Q 435 36, 450 50 L 520 50 Q 530 42, 540 50 L 550 50 L 554 53 L 558 12 L 563 66 L 568 50 L 578 50 Q 595 36, 600 50"
            fill="none"
            stroke="#10b981"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. TOP BANNER: SIGNOS DE INESTABILIDAD HEMODINÁMICA */}
      <div className="bg-white border-2 border-red-500 rounded-xl p-5 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-red-100 gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center text-white font-bold shadow-xs">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
                Signos de Inestabilidad Hemodinámica
                <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200">
                  Regla de Oro ACLS
                </span>
              </h2>
              <p className="text-xs text-slate-500">
                Si CUALQUIERA de estos 5 signos está presente en una taquiarritmia o bradiarritmia con pulso, está indicada TERAPIA ELÉCTRICA INMEDIATA
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            {hasAnyInstability ? (
              <span className="px-3 py-1 bg-red-600 text-white text-xs font-black rounded-lg animate-pulse shadow-xs">
                ¡PACIENTE INESTABLE! → PREPARAR DESFIBRILADOR
              </span>
            ) : (
              <span className="px-3 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold rounded-lg">
                Estable (Sin signos marcados)
              </span>
            )}
          </div>
        </div>

        {/* 5 Signs Checkbox Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 pt-1">
          {[
            { key: 'hipotension', label: '1. Hipotensión', desc: 'TAS < 90 mmHg o PAM < 65' },
            { key: 'conciencia', label: '2. Alteración Mental', desc: 'Confusión, letargia o coma' },
            { key: 'dolorToracico', label: '3. Dolor Isquémico', desc: 'Angina típica opresiva' },
            { key: 'shock', label: '4. Signos de Shock', desc: 'Piel fría, diaforesis, llenado > 3s' },
            { key: 'insuficienciaCardiaca', label: '5. Falla Cardíaca', desc: 'Edema agudo pulmonar, estertores' },
          ].map(sign => (
            <button
              key={sign.key}
              type="button"
              onClick={() => setInstabilitySigns(prev => ({ ...prev, [sign.key]: !prev[sign.key as keyof typeof prev] }))}
              className={`p-3 rounded-lg border text-left transition-all ${
                instabilitySigns[sign.key as keyof typeof instabilitySigns]
                  ? 'bg-red-50 border-red-400 text-red-900 shadow-2xs font-bold'
                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold">{sign.label}</span>
                <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                  instabilitySigns[sign.key as keyof typeof instabilitySigns] ? 'bg-red-600 border-red-600' : 'border-slate-300'
                }`}>
                  {instabilitySigns[sign.key as keyof typeof instabilitySigns] && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-normal">{sign.desc}</p>
            </button>
          ))}
        </div>
      </div>

      {/* 2. MAIN ARITHMIAS SUITE: SELECTOR & ECG MONITOR */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Arrhythmia List (17 exact items) */}
        <div className="lg:col-span-4 space-y-3">
          <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Catálogo de Arritmias ({ARRHYTHMIAS_DATABASE.length})
              </span>
              <span className="text-[10px] font-mono text-slate-400">AHA / ERC</span>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Buscar arritmia o patrón..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-red-500"
              />
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap gap-1">
              {[
                { id: 'all', label: 'Todas' },
                { id: 'paro_desfibrilable', label: 'FV / TVSP' },
                { id: 'paro_no_desfibrilable', label: 'Asistolia / AESP' },
                { id: 'taquicardia', label: 'Taquiarritmias' },
                { id: 'bradicardia', label: 'Bradiarritmias' },
              ].map(cat => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setFilterCategory(cat.id)}
                  className={`px-2 py-1 rounded text-[11px] font-semibold transition-all ${
                    filterCategory === cat.id
                      ? 'bg-red-600 text-white shadow-2xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Arrhythmias Item List */}
            <div className="max-h-[500px] overflow-y-auto space-y-1.5 pr-1">
              {filteredArrhythmias.map(arr => {
                const isSelected = arr.id === currentArrhythmia.id;
                return (
                  <button
                    key={arr.id}
                    type="button"
                    onClick={() => setSelectedArrhythmiaId(arr.id)}
                    className={`w-full p-2.5 rounded-lg text-left transition-all border ${
                      isSelected
                        ? 'bg-red-50/80 border-red-500 text-slate-900 shadow-2xs'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-xs font-bold ${isSelected ? 'text-red-700' : 'text-slate-900'}`}>
                        {arr.nombre}
                      </span>
                      {arr.esDesfibrilable && (
                        <span className="px-1.5 py-0.2 rounded text-[10px] font-black bg-red-600 text-white">
                          DESFIBRILAR
                        </span>
                      )}
                      {arr.cardioversion && !arr.esDesfibrilable && (
                        <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-amber-100 text-amber-800">
                          CARDIOVERTIR
                        </span>
                      )}
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span>FC: {arr.fcTipica}</span>
                      <span className="truncate max-w-[120px]">{arr.categoria}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: ECG Screen, Criteria, Immediate Treatment */}
        <div className="lg:col-span-8 space-y-4">
          {/* ECG Monitor Screen */}
          <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 shadow-md">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-xs font-mono">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-white font-bold">{currentArrhythmia.nombre}</span>
                <span className="text-slate-500 hidden sm:inline">| Derivación DII (25 mm/s, 10 mm/mV)</span>
              </div>
              <div className="flex items-center gap-3 text-slate-400">
                <span>FC: <strong className="text-emerald-400 font-bold">{currentArrhythmia.fcTipica}</strong></span>
              </div>
            </div>

            {/* Oscilloscope Grid */}
            <div className="relative h-28 w-full bg-slate-950 rounded-lg overflow-hidden border border-slate-900 flex items-center">
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b1a_1px,transparent_1px),linear-gradient(to_bottom,#1e293b1a_1px,transparent_1px)] bg-[size:15px_15px]" />
              <svg className="w-full h-full relative z-10" viewBox="0 0 600 100" preserveAspectRatio="none">
                {renderSvgWaveform(currentArrhythmia.svgWaveformType)}
              </svg>
            </div>

            <div className="mt-2 text-[11px] font-mono text-slate-400">
              <strong className="text-slate-200">Significado Clínico:</strong> {currentArrhythmia.significadoClinico}
            </div>
          </div>

          {/* Diagnostic Criteria & Immediate Protocol */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Criteria */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm space-y-2.5">
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
                Criterios Diagnósticos Electrocardiográficos
              </span>
              <ul className="space-y-1.5">
                {currentArrhythmia.criteriosECG.map((crit, idx) => (
                  <li key={idx} className="text-xs text-slate-700 flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-600 mt-1.5 shrink-0" />
                    <span>{crit}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Immediate Prehospital Treatment */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-red-600 uppercase tracking-wider">
                  Tratamiento Inmediato (Protocolo Oficial)
                </span>
                {currentArrhythmia.esDesfibrilable && (
                  <span className="text-[10px] font-black px-2 py-0.5 rounded bg-red-600 text-white animate-pulse">
                    PARO DESFIBRILABLE
                  </span>
                )}
              </div>

              <div className="space-y-2 text-xs">
                {currentArrhythmia.tratamientoInmediato.paso1 && (
                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-slate-800 flex items-start gap-2">
                    <span className="w-4 h-4 rounded-full bg-red-600 text-white font-bold flex items-center justify-center shrink-0 text-[10px]">1</span>
                    <span className="leading-snug font-medium">{currentArrhythmia.tratamientoInmediato.paso1}</span>
                  </div>
                )}
                {currentArrhythmia.tratamientoInmediato.farmaco1 && (
                  <div className="bg-red-50/50 p-2.5 rounded-lg border border-red-100 text-red-900 flex items-start gap-2 font-medium">
                    <Syringe className="w-3.5 h-3.5 text-red-600 shrink-0 mt-0.5" />
                    <span>{currentArrhythmia.tratamientoInmediato.farmaco1}</span>
                  </div>
                )}
                {currentArrhythmia.tratamientoInmediato.paso2 && (
                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-slate-800 flex items-start gap-2">
                    <span className="w-4 h-4 rounded-full bg-slate-700 text-white font-bold flex items-center justify-center shrink-0 text-[10px]">2</span>
                    <span className="leading-snug font-medium">{currentArrhythmia.tratamientoInmediato.paso2}</span>
                  </div>
                )}
                {currentArrhythmia.tratamientoInmediato.cuidadosAvanzados?.map((ca, idx) => (
                  <div key={idx} className="text-[11px] text-slate-600 pl-2 border-l-2 border-red-300">
                    {ca}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Cardioversion info if applicable */}
          {currentArrhythmia.cardioversion && (
            <div className="bg-amber-50/70 border border-amber-300 rounded-xl p-4 space-y-2">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-600" />
                <span className="text-xs font-bold text-amber-900 uppercase tracking-wider">
                  Parámetros de Cardioversión Eléctrica Sincronizada
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-amber-950">
                <div className="bg-white p-2.5 rounded-lg border border-amber-200">
                  <span className="text-slate-500 block text-[11px]">Energía Bifásica Recomendada:</span>
                  <span className="font-bold text-base text-amber-700 font-mono">
                    {currentArrhythmia.cardioversion.joulesBifasico}
                  </span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-amber-200">
                  <span className="text-slate-500 block text-[11px]">Sincronización Obligatoria:</span>
                  <span className="font-bold text-sm text-slate-800">
                    {currentArrhythmia.cardioversion.requiereSincronizacion ? 'Modo SYNC Activo (Evita R sobre T)' : 'Asincrónico (Desfibrilación)'}
                  </span>
                </div>
              </div>
              <p className="text-[11px] text-amber-800 pt-1">
                <strong>Pseudoanalgesia:</strong> {currentArrhythmia.cardioversion.pseudoanalgesiaRecomendada}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* 3. CALCULADORA DE PSEUDOANALGESIA PARA CARDIOVERSIÓN */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-600 font-bold">
              <Syringe className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">
                Calculadora de Pseudoanalgesia Previa a Cardioversión / Marcapasos
              </h3>
              <p className="text-xs text-slate-500">
                Sedación y analgesia consciente para procedimientos eléctricos dolorosos en pacientes con pulso
              </p>
            </div>
          </div>
          <span className="text-xs font-mono font-bold px-2.5 py-1 bg-red-50 text-red-700 rounded-full border border-red-200 self-start sm:self-auto">
            Dosis por Peso Real
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls */}
          <div className="lg:col-span-5 space-y-4">
            {/* Weight Slider */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
              <div className="flex justify-between items-center text-xs mb-2">
                <span className="text-slate-700 font-bold">Peso del Paciente:</span>
                <span className="font-mono text-red-600 font-black bg-white px-2.5 py-0.5 rounded border border-slate-200 text-sm">
                  {patientWeightKg} kg
                </span>
              </div>
              <input
                type="range"
                min="30"
                max="140"
                value={patientWeightKg}
                onChange={(e) => setPatientWeightKg(Number(e.target.value))}
                className="w-full accent-red-600 cursor-pointer"
              />
            </div>

            {/* Sedative Selection */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Fármaco Sedoanalgésico
              </span>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'midazolam', label: 'Midazolam', sub: '0.05 mg/kg (Amnesia)' },
                  { id: 'fentanilo', label: 'Fentanilo', sub: '1 mcg/kg (Analgesia)' },
                  { id: 'ketamina', label: 'Ketamina', sub: '0.75 mg/kg (Preserva PA)' },
                  { id: 'etomidato', label: 'Etomidato', sub: '0.15 mg/kg (Cardiopatía)' },
                ].map(item => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSelectedSedative(item.id as any)}
                    className={`p-2.5 rounded-lg text-left transition-all border ${
                      selectedSedative === item.id
                        ? 'bg-red-600 border-red-600 text-white shadow-2xs font-bold'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div className="text-xs font-bold">{item.label}</div>
                    <div className={`text-[10px] ${selectedSedative === item.id ? 'text-red-100' : 'text-slate-400'}`}>
                      {item.sub}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Results Output */}
          <div className="lg:col-span-7 space-y-3">
            <div className="bg-red-50/50 border border-red-200 rounded-xl p-5 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-wider text-red-700 font-mono font-bold">
                  Dosis Exacta para Preparación
                </span>
                <span className="text-xs font-mono font-bold text-slate-600">{pseudoCalc.nombre}</span>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-xl border border-red-100 shadow-2xs">
                  <span className="text-xs text-slate-500 font-medium">Dosis Prescrita</span>
                  <div className="text-2xl font-black font-mono text-red-600 mt-1">
                    {pseudoCalc.dosisCalculada}
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-red-100 shadow-2xs">
                  <span className="text-xs text-slate-500 font-medium">Volumen a Extraer</span>
                  <div className="text-sm font-bold font-mono text-slate-900 mt-1 leading-snug">
                    {pseudoCalc.volumen}
                  </div>
                </div>
              </div>

              <div className="p-3 bg-white rounded-lg border border-red-100 text-xs text-slate-700 leading-relaxed">
                <strong className="text-slate-900 font-bold block mb-0.5">Indicaciones de Infusión y Seguridad:</strong>
                {pseudoCalc.notas}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4. SECCIÓN DE CUIDADOS POST PARO (ROSC) */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex items-center gap-2.5 pb-3 border-b border-slate-200">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 font-bold">
            <Heart className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Protocolo de Cuidados Post-Paro Cardíaco (Retorno de Circulación Espontánea - ROSC)
            </h3>
            <p className="text-xs text-slate-500">
              Estrategia sistemática de estabilización prehospitalaria tras recuperar pulso espontáneo
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* 1. Hemodinámica */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
              1. Optimización Hemodinámica
            </span>
            <ul className="text-xs text-slate-700 space-y-1.5">
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span><strong>Objetivo PAM:</strong> ≥ 65 mmHg (PAS ≥ 90 mmHg).</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span><strong>Líquidos:</strong> Cristaloides tibios 1 a 2 L en bolo si hipotenso.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span><strong>Vasopresor:</strong> Noradrenalina 0.1 - 0.5 mcg/kg/min o Adrenalina infusión continua si refractario a volumen.</span>
              </li>
            </ul>
          </div>

          {/* 2. Ventilación y Oxigenación */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
              2. Ventilación Protectora
            </span>
            <ul className="text-xs text-slate-700 space-y-1.5">
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span><strong>Oxigenación:</strong> Titular FiO2 para SpO2 92% - 98% (evitar hiperoxia 100%).</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span><strong>Capnografía:</strong> Mantener PaCO2 35 - 45 mmHg (EtCO2 35 - 40 mmHg).</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span><strong>¡PELIGRO!:</strong> Evitar hiperventilación (reduce drásticamente el flujo sanguíneo cerebral).</span>
              </li>
            </ul>
          </div>

          {/* 3. ECG y Cateterismo */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
              3. ECG 12D & Código Infarto
            </span>
            <ul className="text-xs text-slate-700 space-y-1.5">
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span><strong>ECG de 12 derivaciones inmediato</strong> en la escena apenas haya pulso estable.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span>Si hay <strong>elevación del ST (IAMCEST)</strong> o shock cardiogénico: activar Hemodinamia para ICP primaria directa.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span>Traslado prioritario a centro con laboratorio de cateterismo 24/7.</span>
              </li>
            </ul>
          </div>

          {/* 4. Manejo de Temperatura */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
              4. Control Térmico (TTM)
            </span>
            <ul className="text-xs text-slate-700 space-y-1.5">
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span>Si el paciente <strong>no obedece órdenes verbales</strong>: iniciar Control de Temperatura Dirigido (TTM 32°C a 36°C).</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span><strong>Evitar y tratar activamente la fiebre (&gt; 37.5°C)</strong> con antipiréticos o medios físicos (la fiebre empeora drásticamente el daño cerebral).</span>
              </li>
            </ul>
          </div>

          {/* 5. Neuroprotección y Glucemia */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
              5. Neuroprotección & Metabolismo
            </span>
            <ul className="text-xs text-slate-700 space-y-1.5">
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span><strong>Glucosa:</strong> Mantener glicemia entre 140 y 180 mg/dL. Tratar hipoglucemia severa de inmediato.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span><strong>Convulsiones:</strong> Tratar de inmediato con Midazolam 5-10 mg IV o Diazepam; considerar Fenitoína/Levetiracetam.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span>Cabecera elevada a 30° para optimizar drenaje venoso cerebral.</span>
              </li>
            </ul>
          </div>

          {/* 6. Diagnóstico y Traslado */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
              6. Causas Reversibles y Traslado
            </span>
            <ul className="text-xs text-slate-700 space-y-1.5">
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span>Revisar causas persistentes: Hipoxia, Hipovolemia, Hiperkalemia, Neumotórax a tensión, Trombosis coronaria.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-red-500 font-bold">•</span>
                <span>Coordinación prealerta con la Unidad de Cuidados Intensivos del hospital receptor.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
