import React, { useState } from 'react';
import { 
  Shield, AlertTriangle, CheckCircle, ChevronDown, ChevronRight, 
  Clock, Scissors, HelpCircle, Layers, CheckSquare, Square, 
  Sparkles, CheckCircle2, User, Eye, Activity, Wind, Pill, Stethoscope 
} from 'lucide-react';
import { 
  SRI_7P_PROTOCOL, DIFFICULT_AIRWAY_SCALES, SUPRAGLOTTIC_DEVICES, 
  CRICOTHYROIDOTOMY_PROTOCOL 
} from '../../data/airwayData';
import { 
  INDICACIONES_VENTILACION_AVENTHO, 
  SEDANTES_AVENTHO, 
  RELAJANTES_AVENTHO 
} from '../../data/aventhoVentilationData';

interface AirwayProtocolsProps {
  initialTab?: 'sri' | 'indicaciones' | 'farmacos_sri' | 'lemon' | 'soapme' | 'supragloticos' | 'crico';
}

export default function AirwayProtocols({ initialTab }: AirwayProtocolsProps) {
  const [activeTab, setActiveTab] = useState<
    'sri' | 'indicaciones' | 'farmacos_sri' | 'lemon' | 'soapme' | 'supragloticos' | 'crico'
  >(initialTab || 'sri');

  React.useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  const [openPhaseIdx, setOpenPhaseIdx] = useState<number>(0);
  const [pesoIgel, setPesoIgel] = useState<number>(70);

  // LEMON Interactive Checklist State
  const [lemonState, setLemonState] = useState({
    lookTrauma: false,
    lookBarba: false,
    lookCuelloCorto: false,
    eval3dedosBoca: false,
    eval3dedosMenton: false,
    eval2dedosTiro: false,
    mallampatiAlto: false,
    obstruccionEstridor: false,
    cuelloCollarin: false,
  });

  const hasL = lemonState.lookTrauma || lemonState.lookBarba || lemonState.lookCuelloCorto;
  const hasE = lemonState.eval3dedosBoca || lemonState.eval3dedosMenton || lemonState.eval2dedosTiro;
  const hasM = lemonState.mallampatiAlto;
  const hasO = lemonState.obstruccionEstridor;
  const hasN = lemonState.cuelloCollarin;

  const lemonScore = [hasL, hasE, hasM, hasO, hasN].filter(Boolean).length;

  const getLemonDifficulty = (score: number) => {
    if (score === 0) return { label: 'Baja probabilidad de dificultad', color: 'text-emerald-700 bg-emerald-50 border-emerald-200', advice: 'Proceder con SRI estándar.' };
    if (score <= 2) return { label: 'Dificultad moderada', color: 'text-amber-700 bg-amber-50 border-amber-200', advice: 'Tener Bougie elástico preparado y videolaringoscopio listo.' };
    return { label: 'ALTA PROBABILIDAD DE VÍA AÉREA DIFÍCIL (Score ≥ 3)', color: 'text-red-700 bg-red-50 border-red-200 font-bold', advice: '¡ALERTA!: Preparar supraglótico de rescate (i-gel), videolaringoscopio en primera línea y kit de cricotiroidotomía abierto.' };
  };

  const lemonDiff = getLemonDifficulty(lemonScore);

  // SOAPME Checklist
  const [soapmeState, setSoapmeState] = useState<{ [key: string]: boolean }>({
    's_succion_probada': false,
    's_yankauer_mano': false,
    'o_fuente_15l': false,
    'o_bvm_peep': false,
    'o_canula_apneica': false,
    'a_tet_probado': false,
    'a_bougie_mano': false,
    'a_videolaringo': false,
    'a_supraglotico': false,
    'p_inductor_rotulado': false,
    'p_paralizante_rotulado': false,
    'p_vasopresor_empuje': false,
    'm_ecg_conectado': false,
    'm_pani_ciclo': false,
    'm_spo2_onda': false,
    'm_capnografo_etco2': false,
    'e_kit_crico_abierto': false,
    'e_fijador_tubo': false,
  });

  const totalSoapmeItems = Object.keys(soapmeState).length;
  const checkedSoapmeItems = Object.values(soapmeState).filter(Boolean).length;
  const soapmeProgress = Math.round((checkedSoapmeItems / totalSoapmeItems) * 100);

  const toggleSoapme = (key: string) => {
    setSoapmeState(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const resetSoapme = () => {
    const fresh: { [key: string]: boolean } = {};
    Object.keys(soapmeState).forEach(k => { fresh[k] = false; });
    setSoapmeState(fresh);
  };

  // i-gel size
  const getIgelSize = (w: number) => {
    if (w < 5) return { size: 'Tamaño 1', color: 'Rosa', text: 'Neonato (< 5 kg)' };
    if (w < 12) return { size: 'Tamaño 1.5', color: 'Azul', text: 'Lactante (5 - 12 kg)' };
    if (w < 25) return { size: 'Tamaño 2', color: 'Gris', text: 'Pediátrico pequeño (10 - 25 kg)' };
    if (w < 35) return { size: 'Tamaño 2.5', color: 'Blanco', text: 'Pediátrico grande (25 - 35 kg)' };
    if (w < 60) return { size: 'Tamaño 3', color: 'Amarillo', text: 'Adulto pequeño (30 - 60 kg)' };
    if (w < 90) return { size: 'Tamaño 4', color: 'Verde', text: 'Adulto estándar (50 - 90 kg)' };
    return { size: 'Tamaño 5', color: 'Naranja', text: 'Adulto grande (> 90 kg)' };
  };

  const igelRecomendado = getIgelSize(pesoIgel);

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-600 font-bold">
            <Shield className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
              Manejo Avanzado de la Vía Aérea & SRI (AVENTHO)
              <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200 hidden sm:inline">
                Guía Oficial 2019
              </span>
            </h2>
            <p className="text-xs text-slate-500">
              Protocolo de Secuencia de Intubación Rápida, Fármacos, LEMON, 3-3-2, SOAPME e Indicaciones
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200 overflow-x-auto">
          {[
            { id: 'sri', label: 'Protocolo SRI (AVENTHO)' },
            { id: 'indicaciones', label: 'Indicaciones Intubación' },
            { id: 'farmacos_sri', label: 'Sedantes & Relajantes' },
            { id: 'lemon', label: 'LEMON & Regla 3-3-2' },
            { id: 'soapme', label: 'Checklist SOAPME' },
            { id: 'supragloticos', label: 'Supraglóticos (i-gel)' },
            { id: 'crico', label: 'Cricotiroidotomía' },
          ].map(tab => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-md text-xs font-bold whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-white text-red-600 shadow-xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: PROTOCOLO SRI AVENTHO (Página 3) */}
      {activeTab === 'sri' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Secuencia de Intubación Rápida (SRI / SIR) según Manual AVENTHO
              </h3>
              <p className="text-xs text-slate-500">Página 3: Revista Chilena de Medicina Intensiva & AVENTHO Áreas Críticas</p>
            </div>
            <span className="text-[11px] font-mono px-2.5 py-1 bg-red-50 text-red-700 rounded-full border border-red-200 font-bold">
              TET #7-7.5 (Mujeres) / #7.5-8 (Hombres)
            </span>
          </div>

          {/* NOTA DE PACIENTE INESTABLE AVENTHO (DESTACADO ROJO) */}
          <div className="p-4 bg-red-50 border-2 border-red-400 rounded-xl text-xs space-y-1.5 shadow-2xs">
            <div className="flex items-center gap-2 text-red-900 font-bold">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              <span>NOTA CLAVE AVENTHO PARA PACIENTE HEMODINÁMICAMENTE INESTABLE (ISSN 2049-9752):</span>
            </div>
            <p className="text-red-800 leading-relaxed">
              En paciente con hipotensión, shock o inestabilidad hemodinámica, la secuencia de inducción farmacológica recomendada es: 
              <strong className="text-red-950 font-black ml-1">Fentanil 20 - 40 mcg + Etomidato 0.2 mg/kg</strong>, seguido inmediatamente de <strong className="text-red-950 font-black">Rocuronio 1 mg/kg</strong>.
            </p>
            <p className="text-[11px] text-red-700 font-mono">
              *En medida de lo posible coloque tubo orotraqueal #8, #8.5 o #9 si la anatomía lo tolera para facilitar fibrobroncoscopía y reducir resistencia.
            </p>
          </div>

          {/* SRI Phases List */}
          <div className="space-y-3">
            {SRI_7P_PROTOCOL.map((phase, idx) => {
              const isOpen = openPhaseIdx === idx;
              return (
                <div
                  key={phase.fase}
                  className={`rounded-xl border transition-all ${
                    isOpen ? 'bg-red-50/30 border-red-300 shadow-xs' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => setOpenPhaseIdx(isOpen ? -1 : idx)}
                    className="w-full p-4 text-left flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-md bg-white border border-slate-200 text-red-600 shadow-2xs">
                        {phase.tiempo}
                      </span>
                      <div>
                        <span className="text-sm font-bold text-slate-900 block">{phase.fase}</span>
                        <span className="text-xs text-slate-500">{phase.titulo}</span>
                      </div>
                    </div>
                    {isOpen ? <ChevronDown className="w-4 h-4 text-red-600" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
                  </button>

                  {isOpen && (
                    <div className="px-4 pb-4 pt-1 border-t border-slate-200/60 space-y-3">
                      <div className="bg-white p-3 rounded-lg border border-slate-200 text-xs">
                        <strong className="text-slate-800 block mb-1">Objetivo Primario:</strong>
                        <p className="text-slate-600 leading-relaxed">{phase.objetivo}</p>
                      </div>

                      <div>
                        <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-1.5">
                          Acciones Clave en Campo:
                        </span>
                        <ul className="space-y-1.5">
                          {phase.accionesClave.map((act, i) => (
                            <li key={i} className="text-xs text-slate-700 flex items-start gap-2">
                              <span className="w-1.5 h-1.5 rounded-full bg-red-600 mt-1.5 shrink-0" />
                              <span className="leading-snug">{act}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {phase.farmacosYDispositivos && (
                        <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs">
                          <strong className="text-slate-800 block mb-1">Dispositivos y Fármacos Involucrados:</strong>
                          <div className="flex flex-wrap gap-1.5">
                            {phase.farmacosYDispositivos.map((fd, i) => (
                              <span key={i} className="px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-700 font-mono text-[11px]">
                                {fd}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="bg-amber-50 border border-amber-200 p-3 rounded-lg text-xs text-amber-800">
                        <strong className="block mb-1 text-amber-900 font-bold">Perlas Clínicas del Reanimador:</strong>
                        <ul className="space-y-1">
                          {phase.perlasClinicas.map((pc, i) => (
                            <li key={i} className="flex items-start gap-1.5">
                              <span className="text-amber-600 font-bold">•</span>
                              <span>{pc}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Cuádruple Comprobación AVENTHO (Página 3) */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
              Cuádruple Comprobación de Posición de Tubo (AVENTHO Pág. 3)
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs">
              <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                <strong className="text-red-700 block mb-0.5">1. Auscultación</strong>
                <p className="text-slate-600">Ventilación bilateral simétrica en ambos hemitórax y silencio epigástrico.</p>
              </div>
              <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                <strong className="text-red-700 block mb-0.5">2. Capnografía</strong>
                <p className="text-slate-600">Capnografía de onda continua (patrón oro) o capnometría colorimétrica.</p>
              </div>
              <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                <strong className="text-red-700 block mb-0.5">3. Ultrasonido</strong>
                <p className="text-slate-600">Deslizamiento pleural bilateral (*lung sliding*) y ausencia de signo del doble tracto esofágico.</p>
              </div>
              <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                <strong className="text-red-700 block mb-0.5">4. Rx de Tórax</strong>
                <p className="text-slate-600">Punta del tubo orotraqueal localizada a exactamente <strong>2 cm por arriba de la carina</strong>.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: INDICACIONES PARA INICIAR VENTILACIÓN MECÁNICA (Página 2 de AVENTHO) */}
      {activeTab === 'indicaciones' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Indicaciones Clínicas para Iniciar Ventilación Mecánica (AVENTHO Pág. 2)
              </h3>
              <p className="text-xs text-slate-500">Criterios diagnósticos y de protección de vía aérea en áreas críticas y ambulancia</p>
            </div>
            <span className="text-xs font-mono font-bold px-2.5 py-1 bg-red-50 text-red-700 rounded-full border border-red-200">
              Manual AVENTHO 2019
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {INDICACIONES_VENTILACION_AVENTHO.map((ind, idx) => (
              <div key={idx} className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2.5">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-md bg-red-600 text-white font-bold text-xs flex items-center justify-center">
                    {idx + 1}
                  </span>
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    {ind.titulo}
                  </h4>
                </div>
                <ul className="space-y-1.5 pt-1">
                  {ind.items.map((it, iIdx) => (
                    <li key={iIdx} className="text-xs text-slate-700 flex items-start gap-2">
                      <span className="text-red-500 font-bold shrink-0">•</span>
                      <span className="leading-snug">{it}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800">
            <strong>Perla AVENTHO:</strong> En sospecha de inhalación de humo con quemaduras faciales o estridor laríngeo, intubar tempranamente antes de que el edema masivo ocluya la glotis y obligue a una cricotiroidotomía quirúrgica.
          </div>
        </div>
      )}

      {/* TAB 3: SEDANTES Y RELAJANTES MUSCULARES EN SIR (Páginas 4 y 5 de AVENTHO) */}
      {activeTab === 'farmacos_sri' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Sedantes y Relajantes Musculares más Utilizados en SIR (AVENTHO Páginas 4 y 5)
              </h3>
              <p className="text-xs text-slate-500">Dosis de inducción, mantenimiento, latencia, duración y observaciones clínicas</p>
            </div>
            <span className="text-xs font-mono font-bold px-2.5 py-1 bg-red-50 text-red-700 rounded-full border border-red-200">
              Farmacología de Inducción
            </span>
          </div>

          {/* Sedantes */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
              1. Sedantes e Inductores (Página 4)
            </span>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-700 uppercase font-mono text-[10px]">
                    <th className="p-3">Fármaco</th>
                    <th className="p-3">Dosis Inducción</th>
                    <th className="p-3">Inicio y Duración</th>
                    <th className="p-3">Observaciones y Precauciones</th>
                    <th className="p-3">Embarazo</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {SEDANTES_AVENTHO.map(s => (
                    <tr key={s.farmaco} className="hover:bg-slate-50/80">
                      <td className="p-3 font-bold text-slate-900 whitespace-nowrap">
                        {s.farmaco}
                        <span className="block text-[10px] text-slate-400 font-normal">{s.tipo}</span>
                      </td>
                      <td className="p-3 font-mono font-bold text-red-600 whitespace-nowrap">{s.dosisInduccion}</td>
                      <td className="p-3 font-mono text-slate-700 whitespace-nowrap">
                        <div>{s.inicio}</div>
                        <div className="text-[10px] text-slate-400">Dura: {s.duracion}</div>
                      </td>
                      <td className="p-3 text-slate-600">
                        <ul className="space-y-0.5">
                          {s.observaciones.map((obs, oIdx) => (
                            <li key={oIdx} className="leading-snug">• {obs}</li>
                          ))}
                        </ul>
                      </td>
                      <td className="p-3 font-mono font-bold text-slate-700 whitespace-nowrap">{s.embarazo}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Relajantes Musculares */}
          <div className="space-y-3 pt-2 border-t border-slate-200">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
              2. Relajantes Musculares (Página 5)
            </span>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-700 uppercase font-mono text-[10px]">
                    <th className="p-3">Relajante Muscular</th>
                    <th className="p-3">Tipo</th>
                    <th className="p-3">Dosis IV (mg/kg)</th>
                    <th className="p-3">Inicio Efecto</th>
                    <th className="p-3">Recuperación</th>
                    <th className="p-3">Perlas y Precauciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs font-mono">
                  {RELAJANTES_AVENTHO.map(r => (
                    <tr key={r.farmaco} className="hover:bg-slate-50/80">
                      <td className="p-3 font-bold text-slate-900 font-sans">{r.farmaco}</td>
                      <td className="p-3 text-slate-600 font-sans">{r.tipo}</td>
                      <td className="p-3 font-bold text-red-600">{r.dosisIv}</td>
                      <td className="p-3 text-slate-700">{r.inicioEfecto}</td>
                      <td className="p-3 text-slate-700">{r.recuperacion}</td>
                      <td className="p-3 font-sans text-slate-600">{r.perlas}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: LEMON & REGLA 3-3-2 */}
      {activeTab === 'lemon' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
              <div>
                <h3 className="text-base font-bold text-slate-900 tracking-tight">
                  Escala LEMON Interactiva para Predicción de Vía Aérea Difícil
                </h3>
                <p className="text-xs text-slate-500">
                  Marque los hallazgos identificados en la evaluación rápida del paciente
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 font-mono">Puntaje LEMON:</span>
                <span className="text-xl font-black font-mono px-3 py-1 bg-red-600 text-white rounded-lg shadow-xs">
                  {lemonScore} / 5
                </span>
              </div>
            </div>

            <div className={`p-3.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${lemonDiff.color}`}>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider block">{lemonDiff.label}</span>
                <p className="text-xs mt-0.5 leading-relaxed">{lemonDiff.advice}</p>
              </div>
              <span className="text-[11px] font-mono px-2 py-1 rounded bg-white/80 border border-current shrink-0">
                {lemonScore >= 3 ? 'PREPARAR RESCATE' : 'RIESGO ESTÁNDAR'}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* L */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2.5">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-md bg-red-600 text-white font-black text-xs flex items-center justify-center">L</span>
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">Look Externally (Mirar Externamente)</span>
                </div>
                <div className="space-y-1.5 pt-1">
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={lemonState.lookTrauma}
                      onChange={(e) => setLemonState(prev => ({ ...prev, lookTrauma: e.target.checked }))}
                      className="rounded text-red-600"
                    />
                    <span>Trauma facial severo o sangrado profuso</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={lemonState.lookBarba}
                      onChange={(e) => setLemonState(prev => ({ ...prev, lookBarba: e.target.checked }))}
                      className="rounded text-red-600"
                    />
                    <span>Barba espesa (dificulta sello de mascarilla)</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={lemonState.lookCuelloCorto}
                      onChange={(e) => setLemonState(prev => ({ ...prev, lookCuelloCorto: e.target.checked }))}
                      className="rounded text-red-600"
                    />
                    <span>Cuello muy corto, obesidad mórbida o micrognatia</span>
                  </label>
                </div>
              </div>

              {/* E */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2.5">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-md bg-red-600 text-white font-black text-xs flex items-center justify-center">E</span>
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">Evaluate 3-3-2 (Evaluar Regla 3-3-2)</span>
                </div>
                <div className="space-y-1.5 pt-1">
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={lemonState.eval3dedosBoca}
                      onChange={(e) => setLemonState(prev => ({ ...prev, eval3dedosBoca: e.target.checked }))}
                      className="rounded text-red-600"
                    />
                    <span><strong>Apertura bucal &lt; 3 dedos</strong> (dificultad para introducir pala)</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={lemonState.eval3dedosMenton}
                      onChange={(e) => setLemonState(prev => ({ ...prev, eval3dedosMenton: e.target.checked }))}
                      className="rounded text-red-600"
                    />
                    <span><strong>Distancia hioideo-mentoniana &lt; 3 dedos</strong></span>
                  </label>
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={lemonState.eval2dedosTiro}
                      onChange={(e) => setLemonState(prev => ({ ...prev, eval2dedosTiro: e.target.checked }))}
                      className="rounded text-red-600"
                    />
                    <span><strong>Distancia tiro-hioidea &lt; 2 dedos</strong> (laringe alta/anterior)</span>
                  </label>
                </div>
              </div>

              {/* M */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2.5">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-md bg-red-600 text-white font-black text-xs flex items-center justify-center">M</span>
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">Mallampati Score</span>
                </div>
                <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={lemonState.mallampatiAlto}
                    onChange={(e) => setLemonState(prev => ({ ...prev, mallampatiAlto: e.target.checked }))}
                    className="rounded text-red-600"
                  />
                  <span><strong>Clase III o IV:</strong> solo se ve base de úvula o únicamente paladar duro</span>
                </label>
              </div>

              {/* O / N */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2.5">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-md bg-red-600 text-white font-black text-xs flex items-center justify-center">O/N</span>
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">Obstrucción & Movilidad Cervical</span>
                </div>
                <div className="space-y-1.5">
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={lemonState.obstruccionEstridor}
                      onChange={(e) => setLemonState(prev => ({ ...prev, obstruccionEstridor: e.target.checked }))}
                      className="rounded text-red-600"
                    />
                    <span><strong>Obstrucción:</strong> estridor, sialorrea masiva o quemadura glótica</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={lemonState.cuelloCollarin}
                      onChange={(e) => setLemonState(prev => ({ ...prev, cuelloCollarin: e.target.checked }))}
                      className="rounded text-red-600"
                    />
                    <span><strong>Movilidad:</strong> collarín cervical o sospecha de trauma espinal</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: SOAPME CHECKLIST */}
      {activeTab === 'soapme' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">
                Checklist Pre-Intubación SOAPME
              </h3>
              <p className="text-xs text-slate-500">
                Verifique todo el equipo antes de empujar el primer fármaco sedante o paralizante
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-xs text-slate-500 font-mono">Preparación:</span>
                <span className="text-sm font-black font-mono text-red-600 ml-1">{soapmeProgress}%</span>
              </div>
              <button
                type="button"
                onClick={resetSoapme}
                className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              >
                Reiniciar
              </button>
            </div>
          </div>

          <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden border border-slate-200">
            <div
              className={`h-full transition-all duration-300 ${
                soapmeProgress === 100 ? 'bg-emerald-500' : 'bg-red-600'
              }`}
              style={{ width: `${soapmeProgress}%` }}
            />
          </div>

          {soapmeProgress === 100 && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span className="font-bold">
                ¡Checklist SOAPME Completo! El equipo, la farmacología y las vías de rescate están verificadas. Puede proceder con la inducción segura.
              </span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
              <span className="text-xs font-bold text-slate-900 uppercase">S: Suction (Succión)</span>
              {[
                { id: 's_succion_probada', label: 'Aspirador eléctrico encendido y con presión negativa probada' },
                { id: 's_yankauer_mano', label: 'Cánula rígida Yankauer colocada junto a la cabeza' },
              ].map(item => (
                <label key={item.id} className="flex items-start gap-2 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!soapmeState[item.id]}
                    onChange={() => toggleSoapme(item.id)}
                    className="rounded text-red-600 mt-0.5"
                  />
                  <span>{item.label}</span>
                </label>
              ))}
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
              <span className="text-xs font-bold text-slate-900 uppercase">O: Oxygen (Oxígeno)</span>
              {[
                { id: 'o_fuente_15l', label: 'Cilindro con manómetro > 1000 PSI a 15 L/min' },
                { id: 'o_bvm_peep', label: 'BVM con reservorio y válvula PEEP' },
                { id: 'o_canula_apneica', label: 'Cánula nasal a 15 L/min (oxigenación apneica)' },
              ].map(item => (
                <label key={item.id} className="flex items-start gap-2 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!soapmeState[item.id]}
                    onChange={() => toggleSoapme(item.id)}
                    className="rounded text-red-600 mt-0.5"
                  />
                  <span>{item.label}</span>
                </label>
              ))}
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
              <span className="text-xs font-bold text-slate-900 uppercase">A: Airway (Vía Aérea)</span>
              {[
                { id: 'a_tet_probado', label: 'TET comprobado (#7.5-8 hombre / #7-7.5 mujer)' },
                { id: 'a_bougie_mano', label: 'Bougie elástico lubricado en la mano' },
                { id: 'a_videolaringo', label: 'Videolaringoscopio o laringoscopio probado' },
                { id: 'a_supraglotico', label: 'Dispositivo supraglótico i-gel desempaquetado' },
              ].map(item => (
                <label key={item.id} className="flex items-start gap-2 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!soapmeState[item.id]}
                    onChange={() => toggleSoapme(item.id)}
                    className="rounded text-red-600 mt-0.5"
                  />
                  <span>{item.label}</span>
                </label>
              ))}
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
              <span className="text-xs font-bold text-slate-900 uppercase">P: Pharmacy (Fármacos)</span>
              {[
                { id: 'p_inductor_rotulado', label: 'Inductor (Ketamina / Etomidato) cargado y rotulado' },
                { id: 'p_paralizante_rotulado', label: 'Paralizante (Rocuronio / Succinilcolina) rotulado' },
                { id: 'p_vasopresor_empuje', label: 'Push-dose Norepinefrina en mano si TAS < 90' },
              ].map(item => (
                <label key={item.id} className="flex items-start gap-2 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!soapmeState[item.id]}
                    onChange={() => toggleSoapme(item.id)}
                    className="rounded text-red-600 mt-0.5"
                  />
                  <span>{item.label}</span>
                </label>
              ))}
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
              <span className="text-xs font-bold text-slate-900 uppercase">M: Monitoring (Monitores)</span>
              {[
                { id: 'm_ecg_conectado', label: 'ECG continuo en derivación II' },
                { id: 'm_pani_ciclo', label: 'PANI ciclado cada 3 min en brazo libre' },
                { id: 'm_spo2_onda', label: 'Pulsioxímetro con pletismografía fiable' },
                { id: 'm_capnografo_etco2', label: 'Capnógrafo cuantitativo de onda calibrado' },
              ].map(item => (
                <label key={item.id} className="flex items-start gap-2 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!soapmeState[item.id]}
                    onChange={() => toggleSoapme(item.id)}
                    className="rounded text-red-600 mt-0.5"
                  />
                  <span>{item.label}</span>
                </label>
              ))}
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
              <span className="text-xs font-bold text-slate-900 uppercase">E: Equipment / Escape</span>
              {[
                { id: 'e_kit_crico_abierto', label: 'Kit de cricotiroidotomía quirúrgica (bisturí + Bougie)' },
                { id: 'e_fijador_tubo', label: 'Fijador de tubo endotraqueal preparado' },
              ].map(item => (
                <label key={item.id} className="flex items-start gap-2 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!soapmeState[item.id]}
                    onChange={() => toggleSoapme(item.id)}
                    className="rounded text-red-600 mt-0.5"
                  />
                  <span>{item.label}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: SUPRAGLÓTICOS */}
      {activeTab === 'supragloticos' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">
                Dispositivo Supraglótico de Elección: Máscara i-gel
              </h3>
              <p className="text-xs text-slate-500">
                Rescate inmediato ante intubación fallida y primera línea en paro cardíaco
              </p>
            </div>
            <span className="text-xs font-mono font-bold px-2.5 py-1 bg-red-50 text-red-700 rounded-full border border-red-200">
              Sellado elastomérico no inflable
            </span>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
            <div className="flex justify-between items-center text-xs mb-2">
              <span className="text-slate-600 font-medium">Peso del Paciente:</span>
              <span className="font-mono text-red-600 font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
                {pesoIgel} kg
              </span>
            </div>
            <input
              type="range"
              min="2"
              max="120"
              value={pesoIgel}
              onChange={(e) => setPesoIgel(Number(e.target.value))}
              className="w-full accent-red-600 cursor-pointer mb-3"
            />

            <div className="p-3 bg-white rounded-lg border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500 block">Tamaño Recomendado de i-gel:</span>
                <span className="text-lg font-black text-slate-900">{igelRecomendado.size} ({igelRecomendado.color})</span>
              </div>
              <span className="text-xs font-mono font-bold px-3 py-1 rounded-md bg-red-50 text-red-700 border border-red-200">
                {igelRecomendado.text}
              </span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-700 uppercase font-mono text-[10px]">
                  <th className="p-3">Tamaño</th>
                  <th className="p-3">Rango de Peso</th>
                  <th className="p-3">Color de Código</th>
                  <th className="p-3">Sonda Gástrica Máx</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {SUPRAGLOTTIC_DEVICES[0].tamanos.map(t => (
                  <tr key={t.num} className="hover:bg-slate-50/80">
                    <td className="p-3 font-bold text-slate-900">{t.num}</td>
                    <td className="p-3 text-slate-600">{t.peso}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded bg-slate-100 border border-slate-200 text-slate-800 text-[11px]">
                        {t.color}
                      </span>
                    </td>
                    <td className="p-3 text-slate-500">12 Fr (T3-T4) / 14 Fr (T5)</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 7: CRICOTIROIDOTOMÍA */}
      {activeTab === 'crico' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">
                Cricotiroidotomía Quirúrgica de Emergencia (CICO)
              </h3>
              <p className="text-xs text-slate-500">
                Técnica quirúrgica cuando No Se Puede Intubar y No Se Puede Oxigenar (CICO)
              </p>
            </div>
            <span className="text-xs font-mono font-bold px-2.5 py-1 bg-red-100 text-red-800 rounded-full border border-red-300">
              Vía Quirúrgica In extremis
            </span>
          </div>

          <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-xs text-red-900 space-y-1">
            <strong className="block font-bold">Indicación Absoluta:</strong>
            <p>{CRICOTHYROIDOTOMY_PROTOCOL.indicacion}</p>
          </div>

          <div className="space-y-2.5">
            {CRICOTHYROIDOTOMY_PROTOCOL.tecnicaQuirurgica.map((step, idx) => (
              <div key={idx} className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-red-600 text-white font-bold flex items-center justify-center shrink-0 text-[11px]">
                  {idx + 1}
                </span>
                <span className="text-slate-800 leading-snug font-medium">{step.replace(/^\d+\.\s*/, '')}</span>
              </div>
            ))}
          </div>

          <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl text-xs text-amber-900">
            <strong className="block font-bold mb-1">Perlas Salvavidas de Cruz Roja APH:</strong>
            <ul className="space-y-1">
              {CRICOTHYROIDOTOMY_PROTOCOL.perlasSalvavidas.map((ps, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <span className="text-amber-600 font-bold">•</span>
                  <span>{ps}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
