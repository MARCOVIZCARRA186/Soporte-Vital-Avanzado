import React, { useState, useEffect } from 'react';
import { 
  Package, Plus, Trash2, Edit2, Check, AlertCircle, 
  Search, ShieldCheck, RefreshCw, Box 
} from 'lucide-react';
import { PHARMACOLOGY_DATABASE } from '../../data/pharmacologyData';
import { InventoryItem } from '../../types/clinical';

const STORAGE_KEY = 'cruz_roja_ambulance_inventory';

// Default standard Cruz Roja ambulance kit presets
const DEFAULT_INVENTORY: InventoryItem[] = [
  { id: 'inv-1', drugId: 'epinefrina', nombre: 'Epinefrina (Adrenalina)', presentacion: 'Ampolla 1 mg / 1 mL', cantidad: 10, ubicacion: 'Botiquín Paro / Maletín Rojo' },
  { id: 'inv-2', drugId: 'amiodarona', nombre: 'Amiodarona', presentacion: 'Ampolla 150 mg / 3 mL', cantidad: 6, ubicacion: 'Botiquín Paro / Maletín Rojo' },
  { id: 'inv-3', drugId: 'atropina', nombre: 'Atropina Sulfato', presentacion: 'Ampolla 1 mg / 1 mL', cantidad: 5, ubicacion: 'Botiquín Paro / Maletín Rojo' },
  { id: 'inv-4', drugId: 'midazolam', nombre: 'Midazolam', presentacion: 'Ampolla 15 mg / 3 mL (5 mg/mL)', cantidad: 4, ubicacion: 'Cajón de Controlados' },
  { id: 'inv-5', drugId: 'fentanilo', nombre: 'Fentanilo', presentacion: 'Ampolla 150 mcg / 3 mL', cantidad: 4, ubicacion: 'Cajón de Controlados' },
  { id: 'inv-6', drugId: 'ketamina', nombre: 'Ketamina', presentacion: 'Vial 500 mg / 10 mL', cantidad: 2, ubicacion: 'Mochila Vía Aérea SRI' },
  { id: 'inv-7', drugId: 'rocuronio', nombre: 'Bromuro de Rocuronio', presentacion: 'Vial 50 mg / 5 mL', cantidad: 3, ubicacion: 'Refrigerador / Mochila SRI' },
  { id: 'inv-8', drugId: 'atx', nombre: 'ATX (Ácido Tranexámico)', presentacion: 'Ampolla 1.000 mg / 10 mL', cantidad: 4, ubicacion: 'Mochila Trauma' },
  { id: 'inv-9', drugId: 'asa', nombre: 'ASA (Aspirina)', presentacion: 'Comprimidos masticables 100 mg', cantidad: 20, ubicacion: 'Mochila Primaria' },
  { id: 'inv-10', drugId: 'salbutamol', nombre: 'Salbutamol', presentacion: 'Solución 5 mg/mL (Gotas)', cantidad: 3, ubicacion: 'Mochila Respiratoria' },
  { id: 'inv-11', drugId: 'glucosa', nombre: 'Glucosa al 50%', presentacion: 'Ampolla 10 g / 20 mL', cantidad: 5, ubicacion: 'Botiquín Metabólico' },
  { id: 'inv-12', drugId: 'naloxona', nombre: 'Naloxona', presentacion: 'Ampolla 0.4 mg / 1 mL', cantidad: 4, ubicacion: 'Botiquín Toxicológico' },
  { id: 'inv-13', drugId: 'paracetamol', nombre: 'Paracetamol', presentacion: 'Frasco 1 g / 100 mL IV', cantidad: 4, ubicacion: 'Cajón Soluciones' },
];

export default function AmbulanceInventory() {
  const [inventory, setInventory] = useState<InventoryItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : DEFAULT_INVENTORY;
    } catch {
      return DEFAULT_INVENTORY;
    }
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedPresetDrugId, setSelectedPresetDrugId] = useState('');

  // Form states
  const [formNombre, setFormNombre] = useState('');
  const [formPresentacion, setFormPresentacion] = useState('');
  const [formCantidad, setFormCantidad] = useState(1);
  const [formUbicacion, setFormUbicacion] = useState('Botiquín Central');
  const [formCaducidad, setFormCaducidad] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(inventory));
    } catch {
      // localStorage may fail if quota exceeded
    }
  }, [inventory]);

  const handleSelectPresetDrug = (drugId: string) => {
    setSelectedPresetDrugId(drugId);
    if (drugId === 'custom') {
      setFormNombre('');
      setFormPresentacion('');
      return;
    }
    const drug = PHARMACOLOGY_DATABASE.find(d => d.id === drugId);
    if (drug) {
      setFormNombre(drug.nombre);
      setFormPresentacion(drug.presentacion);
    }
  };

  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNombre.trim()) return;

    if (editingId) {
      setInventory(prev => prev.map(item => {
        if (item.id === editingId) {
          return {
            ...item,
            nombre: formNombre.trim(),
            presentacion: formPresentacion.trim() || 'Estándar',
            cantidad: Number(formCantidad),
            ubicacion: formUbicacion.trim(),
            fechaCaducidad: formCaducidad.trim() || undefined,
          };
        }
        return item;
      }));
      setEditingId(null);
    } else {
      const newItem: InventoryItem = {
        id: 'inv-' + Date.now().toString(36),
        drugId: selectedPresetDrugId !== 'custom' ? selectedPresetDrugId : undefined,
        nombre: formNombre.trim(),
        presentacion: formPresentacion.trim() || 'Estándar',
        cantidad: Math.max(0, Number(formCantidad)),
        ubicacion: formUbicacion.trim(),
        fechaCaducidad: formCaducidad.trim() || undefined,
      };
      setInventory(prev => [newItem, ...prev]);
    }

    // Reset form
    setFormNombre('');
    setFormPresentacion('');
    setFormCantidad(1);
    setFormCaducidad('');
    setShowAddForm(false);
  };

  const handleEdit = (item: InventoryItem) => {
    setEditingId(item.id);
    setFormNombre(item.nombre);
    setFormPresentacion(item.presentacion);
    setFormCantidad(item.cantidad);
    setFormUbicacion(item.ubicacion || 'Botiquín Central');
    setFormCaducidad(item.fechaCaducidad || '');
    setShowAddForm(true);
  };

  const handleDelete = (id: string) => {
    setInventory(prev => prev.filter(item => item.id !== id));
  };

  const handleUpdateQty = (id: string, delta: number) => {
    setInventory(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, cantidad: Math.max(0, item.cantidad + delta) };
      }
      return item;
    }));
  };

  const handleResetToDefault = () => {
    if (window.confirm('¿Restablecer el botiquín de la ambulancia al inventario estándar predeterminado?')) {
      setInventory(DEFAULT_INVENTORY);
    }
  };

  const filteredInventory = inventory.filter(item => 
    item.nombre.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.presentacion.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (item.ubicacion && item.ubicacion.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const totalUnidades = inventory.reduce((sum, item) => sum + item.cantidad, 0);
  const itemsAgotados = inventory.filter(item => item.cantidad === 0).length;

  return (
    <div className="space-y-6">
      {/* Header card with Cruz Roja styling */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-600 font-bold">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">Botiquín de Ambulancia Cruz Roja</h2>
              <p className="text-xs text-slate-500">Gestión de disponibilidad y stock de medicamentos en la unidad</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setEditingId(null);
                setFormNombre('');
                setFormPresentacion('');
                setFormCantidad(1);
                setShowAddForm(!showAddForm);
              }}
              className="py-1.5 px-3 rounded-lg text-xs font-semibold bg-red-600 hover:bg-red-700 text-white transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Agregar Medicamento</span>
            </button>

            <button
              type="button"
              onClick={handleResetToDefault}
              title="Restablecer botiquín estándar"
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-500 text-xs"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick KPI stats bar */}
        <div className="grid grid-cols-3 gap-3 my-4">
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
            <span className="text-[11px] text-slate-500 font-medium">Tipos de Fármacos</span>
            <div className="text-xl font-bold font-mono text-slate-900 mt-0.5">{inventory.length}</div>
          </div>
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
            <span className="text-[11px] text-slate-500 font-medium">Unidades Totales</span>
            <div className="text-xl font-bold font-mono text-emerald-600 mt-0.5">{totalUnidades}</div>
          </div>
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
            <span className="text-[11px] text-slate-500 font-medium">Fármacos Agotados</span>
            <div className={`text-xl font-bold font-mono mt-0.5 ${itemsAgotados > 0 ? 'text-red-600' : 'text-slate-400'}`}>
              {itemsAgotados}
            </div>
          </div>
        </div>

        {/* Add/Edit Modal/Form Inline */}
        {showAddForm && (
          <form onSubmit={handleSaveItem} className="my-4 p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <span className="text-xs font-bold text-slate-900">
                {editingId ? 'Editar Medicamento del Botiquín' : 'Nuevo Medicamento en Botiquín'}
              </span>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="text-xs text-slate-400 hover:text-slate-600"
              >
                Cancelar
              </button>
            </div>

            {!editingId && (
              <div>
                <label className="block text-[11px] text-slate-600 font-medium mb-1">Cargar de lista oficial (opcional)</label>
                <select
                  value={selectedPresetDrugId}
                  onChange={(e) => handleSelectPresetDrug(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:border-red-500"
                >
                  <option value="">-- Seleccionar de los 42 fármacos o escribir manual --</option>
                  {PHARMACOLOGY_DATABASE.map(d => (
                    <option key={d.id} value={d.id}>{d.nombre} ({d.presentacion})</option>
                  ))}
                  <option value="custom">Otro medicamento personalizado...</option>
                </select>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-slate-600 font-medium mb-1">Nombre del Medicamento *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Adrenalina, Ketamina..."
                  value={formNombre}
                  onChange={(e) => setFormNombre(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-600 font-medium mb-1">Presentación *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Ampolla 1 mg / 1 mL, Comprimidos 100 mg..."
                  value={formPresentacion}
                  onChange={(e) => setFormPresentacion(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] text-slate-600 font-medium mb-1">Cantidad / Stock actual *</label>
                <input
                  type="number"
                  min="0"
                  required
                  value={formCantidad}
                  onChange={(e) => setFormCantidad(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs text-slate-800 font-mono focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-600 font-medium mb-1">Ubicación en Unidad</label>
                <input
                  type="text"
                  placeholder="Ej. Mochila Roja, Maletín Vía Aérea..."
                  value={formUbicacion}
                  onChange={(e) => setFormUbicacion(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-600 font-medium mb-1">Fecha de Caducidad (opcional)</label>
                <input
                  type="text"
                  placeholder="Ej. 12/2026"
                  value={formCaducidad}
                  onChange={(e) => setFormCaducidad(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="submit"
                className="py-1.5 px-4 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg text-xs transition-colors shadow-sm"
              >
                {editingId ? 'Guardar Cambios' : 'Registrar Medicamento'}
              </button>
            </div>
          </form>
        )}

        {/* Search bar */}
        <div className="relative my-3">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Buscar medicamento en el botiquín por nombre o ubicación..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-red-500 focus:bg-white transition-colors"
          />
        </div>

        {/* Inventory Items List */}
        <div className="space-y-2 mt-4">
          {filteredInventory.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
              No se encontraron medicamentos en el botiquín con ese criterio de búsqueda.
            </div>
          ) : (
            filteredInventory.map(item => {
              const isLow = item.cantidad > 0 && item.cantidad <= 2;
              const isOut = item.cantidad === 0;

              return (
                <div
                  key={item.id}
                  className="bg-white border border-slate-200 hover:border-slate-300 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors"
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-2.5 h-2.5 rounded-full mt-1.5 shrink-0 ${
                      isOut ? 'bg-red-500' : isLow ? 'bg-amber-400' : 'bg-emerald-500'
                    }`} />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{item.nombre}</span>
                        {isOut ? (
                          <span className="text-[10px] font-mono font-semibold px-1.5 py-0.2 rounded bg-red-50 text-red-600 border border-red-200">
                            Agotado
                          </span>
                        ) : isLow ? (
                          <span className="text-[10px] font-mono font-semibold px-1.5 py-0.2 rounded bg-amber-50 text-amber-700 border border-amber-200">
                            Stock Bajo
                          </span>
                        ) : null}
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                        {item.presentacion}
                        {item.ubicacion && <span> · <span className="text-slate-600 font-sans">{item.ubicacion}</span></span>}
                        {item.fechaCaducidad && <span> · Cad: {item.fechaCaducidad}</span>}
                      </div>
                    </div>
                  </div>

                  {/* Quantity and actions */}
                  <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                    <div className="flex items-center gap-1.5 bg-slate-50 p-1 rounded-lg border border-slate-200">
                      <button
                        type="button"
                        onClick={() => handleUpdateQty(item.id, -1)}
                        className="w-6 h-6 rounded bg-white hover:bg-slate-200 text-slate-700 font-mono font-bold text-xs flex items-center justify-center border border-slate-200"
                        title="Restar 1 unidad"
                      >
                        -
                      </button>
                      <span className="min-w-8 text-center font-mono font-bold text-slate-900 text-xs">
                        {item.cantidad}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleUpdateQty(item.id, 1)}
                        className="w-6 h-6 rounded bg-white hover:bg-slate-200 text-slate-700 font-mono font-bold text-xs flex items-center justify-center border border-slate-200"
                        title="Sumar 1 unidad"
                      >
                        +
                      </button>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleEdit(item)}
                        className="p-1.5 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-100"
                        title="Editar datos"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDelete(item.id)}
                        className="p-1.5 text-slate-400 hover:text-red-600 rounded hover:bg-red-50"
                        title="Eliminar de botiquín"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
