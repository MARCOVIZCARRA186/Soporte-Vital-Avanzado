import React, { useState, useEffect } from 'react';
import { 
  Search, Pill, ShieldAlert, Heart, Activity, Check, 
  RotateCcw, Eye, ArrowLeft, ArrowRight, Shuffle, 
  AlertTriangle, CheckCircle2, Bookmark, Package, Layers 
} from 'lucide-react';
import { PHARMACOLOGY_DATABASE } from '../../data/pharmacologyData';
import { DrugItem } from '../../types/clinical';
import AmbulanceInventory from './AmbulanceInventory';

const INVENTORY_STORAGE_KEY = 'cruz_roja_ambulance_inventory';

export default function DrugFlashcards() {
  const [activeMainTab, setActiveMainTab] = useState<'buscador' | 'botiquin'>('buscador');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [onlyAvailableInKit, setOnlyAvailableInKit] = useState(false);
  const [activeDrugId, setActiveDrugId] = useState<string>('epinefrina');
  const [viewMode, setViewMode] = useState<'tarjeta_detallada' | 'flashcard_pregunta'>('tarjeta_detallada');
  const [isFlipped, setIsFlipped] = useState(false);
  const [availableDrugIds, setAvailableDrugIds] = useState<Set<string>>(new Set());

  // Load available drugs from inventory in localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem(INVENTORY_STORAGE_KEY);
      if (saved) {
        const items = JSON.parse(saved);
        const ids = new Set<string>();
        items.forEach((it: any) => {
          if (it.drugId && it.cantidad > 0) ids.add(it.drugId);
          // Also match by partial name
          const match = PHARMACOLOGY_DATABASE.find(d => 
            d.nombre.toLowerCase().includes(it.nombre.toLowerCase()) ||
            it.nombre.toLowerCase().includes(d.nombre.toLowerCase())
          );
          if (match && it.cantidad > 0) ids.add(match.id);
        });
        setAvailableDrugIds(ids);
      }
    } catch {
      // Ignore
    }
  }, [activeMainTab]);

  const filteredDrugs = PHARMACOLOGY_DATABASE.filter(drug => {
    const matchesCat = selectedCategory === 'all' || drug.categoria === selectedCategory;
    const matchesSearch = 
      drug.nombre.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (drug.nombreComercial && drug.nombreComercial.toLowerCase().includes(searchQuery.toLowerCase())) ||
      drug.clasificacion.toLowerCase().includes(searchQuery.toLowerCase()) ||
      drug.indicaciones.some(ind => ind.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesKit = !onlyAvailableInKit || availableDrugIds.has(drug.id);

    return matchesCat && matchesSearch && matchesKit;
  });

  const currentDrug = PHARMACOLOGY_DATABASE.find(d => d.id === activeDrugId) || filteredDrugs[0] || PHARMACOLOGY_DATABASE[0];
  const currentIndex = filteredDrugs.findIndex(d => d.id === currentDrug.id);

  const handleNext = () => {
    setIsFlipped(false);
    if (filteredDrugs.length === 0) return;
    const nextIdx = (currentIndex + 1) % filteredDrugs.length;
    setActiveDrugId(filteredDrugs[nextIdx].id);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    if (filteredDrugs.length === 0) return;
    const prevIdx = (currentIndex - 1 + filteredDrugs.length) % filteredDrugs.length;
    setActiveDrugId(filteredDrugs[prevIdx].id);
  };

  const handleRandom = () => {
    setIsFlipped(false);
    if (filteredDrugs.length === 0) return;
    const randIdx = Math.floor(Math.random() * filteredDrugs.length);
    setActiveDrugId(filteredDrugs[randIdx].id);
  };

  const getPregnancyBadgeColor = (risk: string) => {
    switch (risk) {
      case 'A': return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'B': return 'bg-sky-50 text-sky-700 border-sky-200';
      case 'C': return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'D': return 'bg-orange-50 text-orange-700 border-orange-200';
      case 'X': return 'bg-red-50 text-red-700 border-red-200 font-bold';
      default: return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Red Cross Minimalist Sub-Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-600 font-bold">
            <Pill className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 tracking-tight">Farmacología Prehospitalaria Cruz Roja</h2>
            <p className="text-xs text-slate-500">42 Fármacos Esenciales de Emergencia y Cuidados Críticos</p>
          </div>
        </div>

        {/* View Switcher: Flashcards vs Botiquín */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg border border-slate-200">
          <button
            type="button"
            onClick={() => setActiveMainTab('buscador')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              activeMainTab === 'buscador'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Pill className="w-3.5 h-3.5 text-red-600" />
            <span>Tarjetas de Farmacología</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveMainTab('botiquin')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              activeMainTab === 'botiquin'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Package className="w-3.5 h-3.5 text-red-600" />
            <span>Mi Botiquín de Ambulancia</span>
          </button>
        </div>
      </div>

      {activeMainTab === 'botiquin' ? (
        <AmbulanceInventory />
      ) : (
        /* BUSCADOR DE TARJETAS DE FARMACOLOGIA */
        <div className="space-y-4">
          {/* Search, Filter by Category, and Kit Availability Filter */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Buscar entre los 42 fármacos (ej. ASA, ATX, Norepinefrina, Midazolam, Fentanilo...)"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-red-500 focus:bg-white transition-colors"
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setOnlyAvailableInKit(!onlyAvailableInKit)}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold border flex items-center gap-1.5 transition-colors ${
                    onlyAvailableInKit
                      ? 'bg-red-50 text-red-700 border-red-300 font-bold'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <Package className="w-3.5 h-3.5 text-red-600" />
                  <span>Solo con stock en botiquín</span>
                </button>

                <div className="flex items-center gap-1 p-0.5 bg-slate-100 rounded-lg border border-slate-200">
                  <button
                    type="button"
                    onClick={() => { setViewMode('tarjeta_detallada'); setIsFlipped(false); }}
                    className={`px-2.5 py-1 rounded text-xs font-medium ${
                      viewMode === 'tarjeta_detallada' ? 'bg-white text-slate-900 shadow-sm font-semibold' : 'text-slate-600'
                    }`}
                  >
                    Ficha Completa
                  </button>
                  <button
                    type="button"
                    onClick={() => { setViewMode('flashcard_pregunta'); setIsFlipped(false); }}
                    className={`px-2.5 py-1 rounded text-xs font-medium ${
                      viewMode === 'flashcard_pregunta' ? 'bg-white text-slate-900 shadow-sm font-semibold' : 'text-slate-600'
                    }`}
                  >
                    Flashcard Pregunta
                  </button>
                </div>
              </div>
            </div>

            {/* Category Quick Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto pt-1 pb-1">
              {[
                { id: 'all', label: 'Todos (42)' },
                { id: 'resucitacion', label: 'Resucitación' },
                { id: 'sedacion_analgesia', label: 'Sedación & Dolor' },
                { id: 'via_aerea', label: 'Vía Aérea SRI' },
                { id: 'vasoactivos', label: 'Vasoactivos' },
                { id: 'antiarritmicos', label: 'Antiarrítmicos' },
                { id: 'cardiovascular', label: 'Cardiovascular' },
                { id: 'respiratorio', label: 'Respiratorio' },
                { id: 'antidotos', label: 'Antídotos' },
                { id: 'electrolitos', label: 'Electrólitos' },
                { id: 'antiinflamatorios', label: 'Antiinflamatorios' },
              ].map(cat => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                    selectedCategory === cat.id
                      ? 'bg-slate-900 text-white font-semibold'
                      : 'text-slate-600 hover:text-slate-900 bg-slate-50 border border-slate-200'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Master-Detail Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Drug Picker Sidebar */}
            <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-3 shadow-sm max-h-[720px] overflow-y-auto space-y-1">
              <div className="text-[11px] font-mono text-slate-400 px-2 py-1 flex justify-between">
                <span>Resultados: {filteredDrugs.length} fármacos</span>
                <span>42 en base de datos</span>
              </div>

              {filteredDrugs.length === 0 ? (
                <div className="p-4 text-center text-xs text-slate-400">
                  No se encontraron medicamentos coincidentes.
                </div>
              ) : (
                filteredDrugs.map(drug => {
                  const isSelected = drug.id === currentDrug.id;
                  const inKit = availableDrugIds.has(drug.id);

                  return (
                    <button
                      key={drug.id}
                      type="button"
                      onClick={() => {
                        setActiveDrugId(drug.id);
                        setIsFlipped(false);
                      }}
                      className={`w-full text-left p-2.5 rounded-lg border transition-all flex items-start justify-between gap-2 ${
                        isSelected
                          ? 'bg-red-50/80 border-red-300 text-slate-900 shadow-sm'
                          : 'bg-white border-slate-100 hover:border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className={`text-xs font-bold ${isSelected ? 'text-red-700' : 'text-slate-900'}`}>
                            {drug.nombre}
                          </span>
                          {inKit && (
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" title="Disponible en tu botiquín" />
                          )}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono mt-0.5 truncate max-w-[210px]">
                          {drug.presentacion}
                        </div>
                      </div>

                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200 whitespace-nowrap">
                        FDA {drug.riesgoEmbarazo}
                      </span>
                    </button>
                  );
                })
              )}
            </div>

            {/* Active Drug Card Detailed View */}
            <div className="lg:col-span-8 space-y-4">
              {/* Navigation Header for active drug */}
              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold text-slate-900">{currentDrug.nombre}</h3>
                    {currentDrug.nombreComercial && (
                      <span className="text-xs text-slate-500">({currentDrug.nombreComercial})</span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                    <span className="font-medium text-red-600">{currentDrug.clasificacion}</span>
                    <span>·</span>
                    <span className="font-mono text-slate-600">{currentDrug.presentacion}</span>
                  </div>
                </div>

                {/* Next / Prev / Shuffle Controls */}
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={handlePrev}
                    className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs"
                    title="Fármaco anterior"
                  >
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={handleRandom}
                    className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs"
                    title="Fármaco aleatorio"
                  >
                    <Shuffle className="w-4 h-4 text-red-600" />
                  </button>
                  <button
                    type="button"
                    onClick={handleNext}
                    className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs"
                    title="Siguiente fármaco"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* CARD MODE: DETAILED CLINICAL MONOGRAPH */}
              {viewMode === 'tarjeta_detallada' ? (
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-5">
                  {/* Top Metadata Badges */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-[10px] text-slate-500 font-medium block">Presentación</span>
                      <span className="text-xs font-bold text-slate-900 font-mono mt-0.5 block">{currentDrug.presentacion}</span>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-[10px] text-slate-500 font-medium block">Vías de Administración</span>
                      <span className="text-xs font-bold text-red-700 font-mono mt-0.5 block">
                        {currentDrug.viasAdministracion.join(', ')}
                      </span>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-[10px] text-slate-500 font-medium block">Riesgo en Embarazo</span>
                      <span className={`text-xs font-bold font-mono px-2 py-0.5 rounded border inline-block mt-0.5 ${getPregnancyBadgeColor(currentDrug.riesgoEmbarazo)}`}>
                        Categoría FDA: {currentDrug.riesgoEmbarazo}
                      </span>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-[10px] text-slate-500 font-medium block">Disponibilidad en Unidad</span>
                      <span className={`text-xs font-bold font-mono mt-0.5 block ${
                        availableDrugIds.has(currentDrug.id) ? 'text-emerald-600' : 'text-slate-400'
                      }`}>
                        {availableDrugIds.has(currentDrug.id) ? '✓ En Botiquín' : 'No registrado'}
                      </span>
                    </div>
                  </div>

                  {/* 1. Dosis Indicada */}
                  <div className="bg-red-50/40 border border-red-100 rounded-xl p-4 space-y-2">
                    <span className="text-xs font-bold text-red-800 uppercase tracking-wider block">
                      Dosis Indicada Según Cada Indicación
                    </span>
                    <div className="text-xs text-slate-800 leading-relaxed">
                      <strong className="text-slate-900">Dosis Adulto: </strong>{currentDrug.dosis.adulto}
                    </div>
                    {currentDrug.dosis.pediatrico && (
                      <div className="text-xs text-slate-800 leading-relaxed">
                        <strong className="text-slate-900">Dosis Pediátrica: </strong>{currentDrug.dosis.pediatrico}
                      </div>
                    )}
                    {currentDrug.dosis.dilucionSugerida && (
                      <div className="text-xs text-slate-600 font-mono bg-white p-2 rounded-lg border border-red-100 mt-2">
                        <strong className="text-red-700">Dilución / Preparación: </strong>{currentDrug.dosis.dilucionSugerida}
                      </div>
                    )}
                  </div>

                  {/* 2. Indicaciones & Contraindicaciones */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                      <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
                        Para qué está indicado:
                      </span>
                      <ul className="space-y-1.5 text-xs text-slate-700">
                        {currentDrug.indicaciones.map((ind, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="text-emerald-600 font-bold">•</span>
                            <span>{ind}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                      <span className="text-xs font-bold text-red-700 uppercase tracking-wider block">
                        Contraindicaciones:
                      </span>
                      <ul className="space-y-1.5 text-xs text-slate-700">
                        {currentDrug.contraindicaciones.map((contra, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="text-red-600 font-bold">•</span>
                            <span>{contra}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* 3. Mecanismo de Acción (Farmacodinamia y Farmacocinética) */}
                  <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3">
                    <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
                      Mecanismo de Acción Completo
                    </span>
                    <div className="text-xs text-slate-700 leading-relaxed">
                      <strong className="text-slate-900">Farmacodinamia: </strong>
                      {currentDrug.mecanismoAccion.farmacodinamia}
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-100">
                      <div className="bg-slate-50 p-2 rounded text-[11px]">
                        <span className="text-slate-400 block font-medium">Inicio</span>
                        <span className="font-bold font-mono text-slate-900">{currentDrug.mecanismoAccion.farmacocinetica.inicio}</span>
                      </div>
                      <div className="bg-slate-50 p-2 rounded text-[11px]">
                        <span className="text-slate-400 block font-medium">Pico</span>
                        <span className="font-bold font-mono text-slate-900">{currentDrug.mecanismoAccion.farmacocinetica.pico}</span>
                      </div>
                      <div className="bg-slate-50 p-2 rounded text-[11px]">
                        <span className="text-slate-400 block font-medium">Duración</span>
                        <span className="font-bold font-mono text-slate-900">{currentDrug.mecanismoAccion.farmacocinetica.duracion}</span>
                      </div>
                      <div className="bg-slate-50 p-2 rounded text-[11px]">
                        <span className="text-slate-400 block font-medium">Semivida</span>
                        <span className="font-bold font-mono text-slate-900">{currentDrug.mecanismoAccion.farmacocinetica.metabolismoSemivida.split('.')[0]}</span>
                      </div>
                    </div>
                  </div>

                  {/* 4. Efectos Secundarios, Efectos Adversos y Tx de Sobredosis */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                      <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
                        Efectos Secundarios y Adversos:
                      </span>
                      <div className="text-xs text-slate-700">
                        <strong className="text-slate-800">Secundarios habituales: </strong>
                        {currentDrug.efectosSecundarios.join(' ')}
                      </div>
                      <div className="text-xs text-red-700 pt-1">
                        <strong>Efectos adversos graves: </strong>
                        {currentDrug.efectosAdversos.join(' ')}
                      </div>
                    </div>

                    <div className="bg-red-50/30 p-4 rounded-xl border border-red-100 space-y-2">
                      <span className="text-xs font-bold text-red-800 uppercase tracking-wider block">
                        Tratamiento de Sobredosis / Antídoto:
                      </span>
                      <p className="text-xs text-slate-800 leading-relaxed font-medium">
                        {currentDrug.txSobredosis}
                      </p>
                    </div>
                  </div>

                  {/* 5. Puntos Importantes de la Administración */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                    <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-amber-500" />
                      <span>Puntos Importantes de la Administración y Perlas Clínicas</span>
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-700">
                      {currentDrug.puntosImportantes.map((punto, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <Check className="w-3.5 h-3.5 text-red-600 shrink-0 mt-0.5" />
                          <span>{punto}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ) : (
                /* FLASHCARD PREGUNTA/RESPUESTA MODE */
                <div
                  onClick={() => setIsFlipped(!isFlipped)}
                  className="bg-white border border-slate-200 hover:border-red-400 rounded-2xl p-6 min-h-[380px] flex flex-col justify-between cursor-pointer shadow-sm transition-all select-none"
                >
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <span className="text-xs font-bold text-red-600 font-mono">
                      {currentDrug.nombre} ({currentDrug.clasificacion})
                    </span>
                    <span className="text-xs text-slate-400 font-mono flex items-center gap-1">
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>{isFlipped ? 'Volver a la Pregunta' : 'Girar para Ver Respuesta'}</span>
                    </span>
                  </div>

                  <div className="my-auto py-6">
                    {!isFlipped ? (
                      <div className="space-y-3">
                        <span className="text-xs uppercase tracking-wider text-slate-400 font-mono font-semibold block">Pregunta Clínica Cruz Roja:</span>
                        <h4 className="text-lg font-bold text-slate-900 leading-relaxed">
                          {currentDrug.flashcard.pregunta}
                        </h4>
                        <div className="pt-3 text-xs text-slate-500">
                          Presentación: <strong className="text-slate-800">{currentDrug.presentacion}</strong> · Vías: <strong className="text-red-700">{currentDrug.viasAdministracion.join(', ')}</strong>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <span className="text-xs uppercase tracking-wider text-red-600 font-mono font-bold block">Respuesta y Protocolo de Administración:</span>
                        <p className="text-sm font-medium text-slate-900 leading-relaxed bg-red-50/50 p-4 rounded-xl border border-red-100">
                          {currentDrug.flashcard.respuesta}
                        </p>
                        <div className="pt-2 space-y-1">
                          <strong className="text-xs text-slate-700 block">Puntos Clave del Fármaco:</strong>
                          {currentDrug.flashcard.puntosClave.map((pk, i) => (
                            <div key={i} className="text-xs text-slate-700 flex items-start gap-1.5">
                              <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                              <span>{pk}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400 font-mono">
                    <span>Riesgo Embarazo: Categoría {currentDrug.riesgoEmbarazo}</span>
                    <span className="text-red-600 font-medium">Toque cualquier parte para voltear</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
