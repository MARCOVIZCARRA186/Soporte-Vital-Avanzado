import React, { useState } from 'react';
import { 
  Heart, Activity, Wind, Gauge, AlertCircle, Thermometer, 
  Brain, CheckCircle2, Shield, Zap 
} from 'lucide-react';

export default function PostArrestCare() {
  const [tamTarget, setTamTarget] = useState(true);
  const [spo2Target, setSpo2Target] = useState(true);
  const [ecgDone, setEcgDone] = useState(false);
  const [tempControl, setTempControl] = useState(false);
  const [glucometryDone, setGlucometryDone] = useState(false);

  return (
    <div className="space-y-6">
      {/* Header with Cruz Roja minimalist styling */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 font-bold">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Protocolo de Cuidados Post Paro Cardíaco (ROSC)
              </h2>
              <p className="text-xs text-slate-500">
                Retorno de la Circulación Espontánea · Metas de Estabilización y Neuroprotección Prehospitalaria
              </p>
            </div>
          </div>
          <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold">
            ROSC Confirmado
          </span>
        </div>

        {/* 5 Critical Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          {/* 1. Vía Aérea y Ventilación */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2.5">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-xs">
              <Wind className="w-4 h-4 text-emerald-600" />
              <span>1. Vía Aérea y Oxigenación Controlada</span>
            </div>
            <ul className="text-xs text-slate-700 space-y-1.5 pl-1">
              <li>• <strong>Meta SpO2: 92% a 98%</strong> (evitar hiperoxia tóxica con SpO2 100% que produce radicales libres).</li>
              <li>• <strong>Meta Capnografía ETCO2: 35 a 40 mmHg</strong> (PaCO2 35-45 mmHg).</li>
              <li>• <strong>¡Evitar la hiperventilación!</strong> La hiperventilación eleva la presión intratorácica y disminuye el retorno venoso y el flujo sanguíneo cerebral.</li>
              <li>• Ventilar a 10 a 12 respiraciones por minuto con volumen corriente protector (6-7 mL/kg PBW).</li>
            </ul>
          </div>

          {/* 2. Optimización Hemodinámica */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2.5">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-xs">
              <Gauge className="w-4 h-4 text-red-600" />
              <span>2. Perfusión y Presión Arterial</span>
            </div>
            <ul className="text-xs text-slate-700 space-y-1.5 pl-1">
              <li>• <strong>Meta hemodinámica: TAM ≥ 65 mmHg</strong> o TAS ≥ 90 mmHg.</li>
              <li>• Carga inicial de cristaloides tibios: 1 a 2 Litros de Solución Ringer Lactato o SF 0.9%.</li>
              <li>• Si la hipotensión persiste tras volumen: iniciar de inmediato <strong>Norepinefrina (0.1 a 0.5 mcg/kg/min)</strong> o Epinefrina en infusión continua (2 a 10 mcg/min).</li>
            </ul>
          </div>

          {/* 3. ECG 12 Derivaciones y Código Infarto */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2.5">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-xs">
              <Heart className="w-4 h-4 text-red-600" />
              <span>3. Descartar IAMCEST / Código Infarto</span>
            </div>
            <ul className="text-xs text-slate-700 space-y-1.5 pl-1">
              <li>• <strong>ECG de 12 derivaciones inmediato</strong> en los primeros 10 minutos tras el ROSC.</li>
              <li>• Si hay elevación del ST (IAMCEST) o sospecha de choque cardiogénico: <strong>activar Código Infarto y trasladar a centro con Hemodinamia / Cateterismo urgente (ICP)</strong>.</li>
              <li>• Derivaciones derechas si hay infarto de cara inferior.</li>
            </ul>
          </div>

          {/* 4. Manejo de Temperatura (MTD / TTM) */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2.5">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-xs">
              <Thermometer className="w-4 h-4 text-sky-600" />
              <span>4. Manejo de Temperatura Dirigido</span>
            </div>
            <ul className="text-xs text-slate-700 space-y-1.5 pl-1">
              <li>• <strong>PREVENIR ACTIVAMENTE LA FIEBRE:</strong> La temperatura corporal &gt; 37.5 °C duplica el daño cerebral isquémico secundario.</li>
              <li>• Mantener normotermia estricta o rango de 32 a 36 °C en hospital.</li>
              <li>• En la ambulancia: desabrigar si hay fiebre, compresas frías en cuello/axilas si T &gt; 38 °C.</li>
            </ul>
          </div>

          {/* 5. Neuroprotección y Glucemia */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2.5">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-xs">
              <Brain className="w-4 h-4 text-indigo-600" />
              <span>5. Neuroprotección y Metabolismo</span>
            </div>
            <ul className="text-xs text-slate-700 space-y-1.5 pl-1">
              <li>• <strong>Meta de Glucemia: 140 a 180 mg/dL</strong> (evitar rigurosamente la hipoglucemia &lt; 70 mg/dL).</li>
              <li>• <strong>Tratar convulsiones de inmediato:</strong> Midazolam 0.1 mg/kg IV o Levetiracetam 60 mg/kg IV (el mioclono posparo consume O2 cerebral masivo).</li>
              <li>• <strong>Posición: Cabecero a 30°</strong> para favorecer el drenaje venoso cerebral y reducir la presión intracraneal.</li>
            </ul>
          </div>

          {/* 6. Prealerta Hospitalaria */}
          <div className="bg-red-50/40 border border-red-200 rounded-xl p-4 space-y-2.5">
            <div className="flex items-center gap-2 text-red-800 font-bold text-xs">
              <Shield className="w-4 h-4 text-red-600" />
              <span>6. Prealerta de Unidad Crítica</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed">
              Comunicar al centro receptor: tiempo total de paro, ritmo inicial (desfibrilable vs no), número de descargas, fármacos administrados, hallazgos en ECG de 12 derivaciones y estado de conciencia actual.
            </p>
          </div>
        </div>

        {/* Quick interactive ROSC Checklist */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
          <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
            Lista de Verificación de Metas Post-Paro en la Ambulancia:
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
            {[
              { id: 'tam', label: 'TAM ≥ 65 mmHg (Vasopresor si es necesario)', checked: tamTarget, set: setTamTarget },
              { id: 'spo2', label: 'SpO2 92-98% y ETCO2 35-40 mmHg', checked: spo2Target, set: setSpo2Target },
              { id: 'ecg', label: 'ECG de 12 derivaciones realizado', checked: ecgDone, set: setEcgDone },
              { id: 'temp', label: 'Temperatura controlada (< 37.5 °C)', checked: tempControl, set: setTempControl },
              { id: 'gluc', label: 'Glucemia controlada (140-180 mg/dL)', checked: glucometryDone, set: setGlucometryDone },
            ].map(item => (
              <button
                key={item.id}
                type="button"
                onClick={() => item.set(!item.checked)}
                className={`p-2.5 rounded-lg border text-left text-xs font-medium flex items-center gap-2 transition-colors ${
                  item.checked
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-800 font-semibold'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <CheckCircle2 className={`w-4 h-4 shrink-0 ${item.checked ? 'text-emerald-600' : 'text-slate-300'}`} />
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
