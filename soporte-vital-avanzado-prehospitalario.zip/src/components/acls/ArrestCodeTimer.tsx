import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, Pause, RotateCcw, Zap, Syringe, Clock, Volume2, VolumeX, 
  CheckSquare, Square, Clipboard, Check, Activity, AlertCircle, Heart,
  Thermometer, Gauge, Wind, Stethoscope, CheckCircle2, AlertTriangle, 
  Radio, ChevronRight, ShieldCheck, Droplet, Sparkles
} from 'lucide-react';
import { playMetronomeBeep, playCycleAlertSound, playShockDischargedSound } from '../../utils/audioMetronome';

interface CodeLogEntry {
  id: string;
  tiempo: string;
  tipo: 'descarga' | 'adrenalina' | 'amiodarona' | 'ritmo' | 'via_aerea' | 'rosc' | 'post_paro' | 'nota';
  texto: string;
}

interface ArrestCodeTimerProps {
  initialTab?: 'reanimacion' | 'post_paro';
}

export default function ArrestCodeTimer({ initialTab = 'reanimacion' }: ArrestCodeTimerProps) {
  const [activeTab, setActiveTab] = useState<'reanimacion' | 'post_paro'>(initialTab);

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [totalSeconds, setTotalSeconds] = useState<number>(0);
  const [cycleSeconds, setCycleSeconds] = useState<number>(120); // 2-min countdown
  const [cprCycleCount, setCprCycleCount] = useState<number>(1);
  const [metronomeActive, setMetronomeActive] = useState<boolean>(false);
  const [shockJoules, setShockJoules] = useState<number>(200);
  const [shockCount, setShockCount] = useState<number>(0);
  const [adrenalinaCount, setAdrenalinaCount] = useState<number>(0);
  const [amiodaronaDosis, setAmiodaronaDosis] = useState<number>(0); // 0, 1 (300mg), 2 (150mg)
  const [adrenalinaTimerSecs, setAdrenalinaTimerSecs] = useState<number>(0); // countdown from 180s (3min)
  const [currentRhythm, setCurrentRhythm] = useState<'fv_tvsp' | 'asistolia_aesp' | 'rosc' | 'desconocido'>('fv_tvsp');
  const [log, setLog] = useState<CodeLogEntry[]>([]);
  const [copied, setCopied] = useState<boolean>(false);
  const [hasROSC, setHasROSC] = useState<boolean>(false);

  // 5H and 5T interactive checklist
  const [checklist5H, setChecklist5H] = useState<Record<string, boolean>>({
    hipovolemia: false,
    hipoxia: false,
    hidrogeniones: false,
    hipo_hiperpotasemia: false,
    hipotermia: false,
  });

  const [checklist5T, setChecklist5T] = useState<Record<string, boolean>>({
    tension_neumotorax: false,
    taponamiento: false,
    toxicos: false,
    trombosis_pulmonar: false,
    trombosis_coronaria: false,
  });

  // Post-ROSC Interactive Checklist State
  const [postRoscChecklist, setPostRoscChecklist] = useState<Record<string, boolean>>({
    via_aerea_capno: false,
    normocapnia_spo2: false,
    presion_arterial_pam: false,
    ecg_12_derivaciones: false,
    control_temperatura: false,
    glucosa_controlada: false,
    alerta_hospitalaria: false,
  });

  // Post-ROSC Hemodynamic calculator state
  const [postTas, setPostTas] = useState<number>(95);
  const [postTad, setPostTad] = useState<number>(55);
  const [postSpo2, setPostSpo2] = useState<number>(94);
  const [postEtco2, setPostEtco2] = useState<number>(38);
  const [postGlucemia, setPostGlucemia] = useState<number>(145);
  const [postTemperatura, setPostTemperatura] = useState<number>(36.2);
  const [patientComatose, setPatientComatose] = useState<boolean>(true);

  // MAP Calculation: (2*PAD + PAS) / 3
  const calculatedPam = Math.round((2 * postTad + postTas) / 3);

  const metronomeIntervalRef = useRef<number | null>(null);

  // Format seconds to MM:SS
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  // Main timer tick
  useEffect(() => {
    let interval: number | null = null;
    if (isRunning) {
      interval = window.setInterval(() => {
        setTotalSeconds(prev => prev + 1);

        setCycleSeconds(prev => {
          if (prev <= 1) {
            playCycleAlertSound();
            setCprCycleCount(c => c + 1);
            addLogEntry('ritmo', `¡Fin de ciclo de 2 min! Evaluar ritmo y rotar compresor.`);
            return 120; // reset to 2 minutes
          }
          return prev - 1;
        });

        // Adrenaline timer countdown
        setAdrenalinaTimerSecs(prev => {
          if (prev <= 1 && prev > 0) {
            playCycleAlertSound();
            addLogEntry('adrenalina', `ALERTA: Dosis de Adrenalina 1 mg indicada (transcurrieron 3 min).`);
            return 0;
          }
          return prev > 0 ? prev - 1 : 0;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning]);

  // CPR Metronome at 110 BPM
  useEffect(() => {
    if (metronomeActive && isRunning) {
      let beat = 0;
      metronomeIntervalRef.current = window.setInterval(() => {
        playMetronomeBeep(beat % 4 === 0);
        beat++;
      }, Math.round(60000 / 110));
    } else {
      if (metronomeIntervalRef.current) {
        clearInterval(metronomeIntervalRef.current);
        metronomeIntervalRef.current = null;
      }
    }
    return () => {
      if (metronomeIntervalRef.current) {
        clearInterval(metronomeIntervalRef.current);
      }
    };
  }, [metronomeActive, isRunning]);

  const addLogEntry = (tipo: CodeLogEntry['tipo'], texto: string) => {
    const newEntry: CodeLogEntry = {
      id: Math.random().toString(36).substring(2, 9),
      tiempo: formatTime(totalSeconds),
      tipo,
      texto,
    };
    setLog(prev => [newEntry, ...prev]);
  };

  // Timer controls
  const handleStartStop = () => {
    if (!isRunning) {
      setIsRunning(true);
      if (totalSeconds === 0) {
        addLogEntry('ritmo', `Inicio de reanimación cardiopulmonar (RCP) y cronómetro.`);
      }
    } else {
      setIsRunning(false);
      addLogEntry('nota', `Cronómetro pausado.`);
    }
  };

  const handleReset = () => {
    setIsRunning(false);
    setTotalSeconds(0);
    setCycleSeconds(120);
    setCprCycleCount(1);
    setShockCount(0);
    setAdrenalinaCount(0);
    setAmiodaronaDosis(0);
    setAdrenalinaTimerSecs(0);
    setHasROSC(false);
    setLog([]);
  };

  // Shock handler
  const handleDeliverShock = () => {
    const nextCount = shockCount + 1;
    setShockCount(nextCount);
    playShockDischargedSound();
    addLogEntry('descarga', `Descarga #${nextCount} administrada (${shockJoules} J). Reanudar compresiones inmediatamente.`);
    setCycleSeconds(120);
  };

  // Adrenaline handler
  const handleAdrenalina = () => {
    const newCount = adrenalinaCount + 1;
    setAdrenalinaCount(newCount);
    setAdrenalinaTimerSecs(180); // 3-minute timer
    addLogEntry('adrenalina', `Adrenalina 1 mg IV/IO administrada (Dosis #${newCount}). Próxima dosis en 3-5 min.`);
  };

  // Amiodarone handler
  const handleAmiodarona = () => {
    if (amiodaronaDosis === 0) {
      setAmiodaronaDosis(1);
      addLogEntry('amiodarona', `Amiodarona 300 mg IV/IO administrada (1ª dosis tras 3ª descarga).`);
    } else if (amiodaronaDosis === 1) {
      setAmiodaronaDosis(2);
      addLogEntry('amiodarona', `Amiodarona 150 mg IV/IO administrada (2ª dosis tras 5ª descarga).`);
    } else {
      addLogEntry('amiodarona', `Dosis extra de Amiodarona/Lidocaína consultada.`);
    }
  };

  // ROSC handler
  const handleROSC = () => {
    setCurrentRhythm('rosc');
    setHasROSC(true);
    addLogEntry('rosc', `¡RETORNO DE LA CIRCULACIÓN ESPONTÁNEA (ROSC) DETECTADO! Activando protocolo de cuidados post-paro.`);
    setActiveTab('post_paro');
  };

  const handleAddPostRoscNote = (nota: string) => {
    addLogEntry('post_paro', `[Post-Paro] ${nota}`);
  };

  const copyLogToClipboard = () => {
    const text = log.map(l => `[${l.tiempo}] ${l.texto}`).reverse().join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Primary Code Navigation Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-red-600 flex items-center justify-center text-white font-bold shadow-xs">
            <Heart className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Código Paro ACLS & Cuidados Post-Paro
              </h2>
              {hasROSC && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 uppercase tracking-wider animate-pulse">
                  ROSC Activo
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500">
              Soporte Vital Cardiovascular Avanzado y Protocolo Integral de Cuidados Posreanimación
            </p>
          </div>
        </div>

        {/* Section Switcher Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg border border-slate-200 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setActiveTab('reanimacion')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'reanimacion'
                ? 'bg-white text-slate-900 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-red-600" />
            <span>Reanimación Activa</span>
            {isRunning && (
              <span className="w-2 h-2 rounded-full bg-red-600 animate-ping inline-block ml-0.5" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('post_paro')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'post_paro'
                ? 'bg-emerald-600 text-white shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Activity className="w-3.5 h-3.5 text-emerald-500" />
            <span>Cuidados Post-Paro (ROSC)</span>
            {hasROSC && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block ml-0.5" />
            )}
          </button>
        </div>
      </div>

      {/* Persistent ROSC Alert Banner when active in reanimacion tab */}
      {hasROSC && activeTab === 'reanimacion' && (
        <div className="bg-emerald-50 border border-emerald-300 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-emerald-950">
                ¡Retorno de la Circulación Espontánea (ROSC) Detectado!
              </h4>
              <p className="text-xs text-emerald-800">
                Presión palpable y onda de capnografía confirmadas. Optimizar oxigenación, presión arterial PAM ≥ 65 y preparar traslado.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setActiveTab('post_paro')}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-xs flex items-center justify-center gap-2 transition-colors shrink-0"
          >
            <span>Ir a Cuidados Post-Paro</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* VIEW 1: REANIMACIÓN ACTIVA (Cronómetro, 2-min, descargas, adrenalina, amiodarona, 5H/5T) */}
      {activeTab === 'reanimacion' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-red-600">
                Monitor Táctico de Paro Cardiorrespiratorio
              </span>
              <span className="text-xs text-slate-400 font-mono">• 2026 ACLS Guidelines</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setMetronomeActive(!metronomeActive)}
                className={`py-1.5 px-3 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 transition-all border ${
                  metronomeActive
                    ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                {metronomeActive ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                <span>Metrónomo 110 cpm {metronomeActive ? 'ACTIVO' : ''}</span>
              </button>

              <button
                type="button"
                onClick={handleReset}
                title="Reiniciar código"
                className="p-2 bg-slate-50 border border-slate-200 hover:bg-slate-100 text-slate-600 rounded-lg text-xs transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Timers Grid */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            {/* 2-Min CPR Cycle Countdown */}
            <div className="md:col-span-6 bg-slate-50 border border-slate-200 rounded-xl p-5 flex flex-col justify-between shadow-xs">
              <div className="flex justify-between items-center">
                <span className="text-xs uppercase tracking-wider text-red-700 font-mono font-bold">
                  Ciclo de RCP #{cprCycleCount} (2 Minutos)
                </span>
                <span className="text-xs font-mono text-slate-500">Rotar compresores a 00:00</span>
              </div>

              <div className="my-4 text-center">
                <div className="text-6xl font-black font-mono tracking-tight text-slate-900 tabular-nums">
                  {formatTime(cycleSeconds)}
                </div>
                <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden mt-3">
                  <div
                    className="bg-red-600 h-full transition-all duration-1000 ease-linear"
                    style={{ width: `${(cycleSeconds / 120) * 100}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 text-xs font-mono text-slate-500 border-t border-slate-200">
                <span>Tiempo Total de Paro:</span>
                <span className="text-slate-900 font-black text-sm">{formatTime(totalSeconds)}</span>
              </div>
            </div>

            {/* Quick Intervention Dashboard */}
            <div className="md:col-span-6 flex flex-col justify-between gap-3">
              {/* Start / Pause Button */}
              <button
                type="button"
                onClick={handleStartStop}
                className={`w-full py-4 rounded-xl font-bold text-base flex items-center justify-center gap-2 transition-all shadow-sm ${
                  isRunning
                    ? 'bg-amber-500 hover:bg-amber-600 text-white'
                    : 'bg-red-600 hover:bg-red-700 text-white'
                }`}
              >
                {isRunning ? (
                  <>
                    <Pause className="w-5 h-5" />
                    <span>Pausar Código</span>
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 fill-current" />
                    <span>Iniciar Reanimación (RCP)</span>
                  </>
                )}
              </button>

              {/* Quick Metrics */}
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
                  <span className="text-[11px] text-slate-500 font-medium block">Descargas</span>
                  <span className="text-2xl font-black font-mono text-red-600">{shockCount}</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
                  <span className="text-[11px] text-slate-500 font-medium block">Adrenalina (1 mg)</span>
                  <span className="text-2xl font-black font-mono text-red-600">{adrenalinaCount}</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
                  <span className="text-[11px] text-slate-500 font-medium block">Amiodarona</span>
                  <span className="text-sm font-bold font-mono text-slate-800 mt-1 block">
                    {amiodaronaDosis === 0 ? '0 mg' : amiodaronaDosis === 1 ? '300 mg' : '450 mg'}
                  </span>
                </div>
              </div>

              {/* Adrenaline interval tracker */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Syringe className="w-4 h-4 text-red-600" />
                  <span className="text-slate-700 font-medium">Ventana de Adrenalina (cada 3-5 min):</span>
                </div>
                <span className={`font-mono font-bold ${adrenalinaTimerSecs === 0 ? 'text-red-600 animate-pulse' : 'text-slate-700'}`}>
                  {adrenalinaTimerSecs === 0 ? 'LISTA PARA ADMINISTRAR' : `Siguiente en: ${formatTime(adrenalinaTimerSecs)}`}
                </span>
              </div>
            </div>
          </div>

          {/* Action Buttons: Shock, Adrenaline, Amiodarone, ROSC */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* Shock Button */}
            <div className="space-y-1.5">
              <button
                type="button"
                onClick={handleDeliverShock}
                className="w-full py-3 px-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors"
              >
                <Zap className="w-4 h-4 fill-current" />
                <span>Descarga {shockJoules} J</span>
              </button>
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 px-1">
                <span>Energía:</span>
                <select
                  value={shockJoules}
                  onChange={(e) => setShockJoules(Number(e.target.value))}
                  className="bg-slate-50 border border-slate-200 rounded px-1.5 py-0.5 text-slate-700 text-[11px]"
                >
                  <option value={120}>120 J</option>
                  <option value={150}>150 J</option>
                  <option value={200}>200 J</option>
                  <option value={300}>300 J</option>
                  <option value={360}>360 J</option>
                </select>
              </div>
            </div>

            {/* Adrenaline Button */}
            <button
              type="button"
              onClick={handleAdrenalina}
              className="w-full py-3 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors"
            >
              <Syringe className="w-4 h-4 text-red-400" />
              <span>Adrenalina 1 mg IV</span>
            </button>

            {/* Amiodarone Button */}
            <button
              type="button"
              onClick={handleAmiodarona}
              className="w-full py-3 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Heart className="w-4 h-4 text-red-600" />
              <span>
                {amiodaronaDosis === 0 ? 'Amiodarona 300 mg' : amiodaronaDosis === 1 ? 'Amiodarona 150 mg' : 'Amiodarona (Máx)'}
              </span>
            </button>

            {/* ROSC Button */}
            <button
              type="button"
              onClick={handleROSC}
              className="w-full py-3 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors"
            >
              <Activity className="w-4 h-4" />
              <span>¡ROSC Detectado!</span>
            </button>
          </div>

          {/* 5H and 5T Reversible Causes Checklist */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Causas Reversibles de Paro (Las 5 H y Las 5 T)
              </span>
              <span className="text-[11px] text-slate-500 font-mono">Buscar y tratar la causa de base</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* 5 H */}
              <div className="bg-white p-3 rounded-lg border border-slate-200 space-y-1.5">
                <span className="text-[11px] font-bold text-red-600 block uppercase font-mono">Las 5 H:</span>
                {[
                  { k: 'hipovolemia', l: 'Hipovolemia (Sangrado / Deshidratación severa)' },
                  { k: 'hipoxia', l: 'Hipoxia (Vía aérea ocluida / PaO2 baja)' },
                  { k: 'hidrogeniones', l: 'Hidrogeniones / Acidosis metabólica' },
                  { k: 'hipo_hiperpotasemia', l: 'Hipo / Hiperpotasemia (K+ alterado)' },
                  { k: 'hipotermia', l: 'Hipotermia (< 35°C)' },
                ].map(h => (
                  <label key={h.k} className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer hover:text-slate-900">
                    <input
                      type="checkbox"
                      checked={checklist5H[h.k]}
                      onChange={() => setChecklist5H(prev => ({ ...prev, [h.k]: !prev[h.k] }))}
                      className="rounded text-red-600 focus:ring-red-500"
                    />
                    <span>{h.l}</span>
                  </label>
                ))}
              </div>

              {/* 5 T */}
              <div className="bg-white p-3 rounded-lg border border-slate-200 space-y-1.5">
                <span className="text-[11px] font-bold text-red-600 block uppercase font-mono">Las 5 T:</span>
                {[
                  { k: 'tension_neumotorax', l: 'Tensión (Neumotórax a tensión)' },
                  { k: 'taponamiento', l: 'Taponamiento cardíaco' },
                  { k: 'toxicos', l: 'Tóxicos / Sobredosis farmacológica' },
                  { k: 'trombosis_pulmonar', l: 'Trombosis pulmonar (TEP masivo)' },
                  { k: 'trombosis_coronaria', l: 'Trombosis coronaria (IAMCEST)' },
                ].map(t => (
                  <label key={t.k} className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer hover:text-slate-900">
                    <input
                      type="checkbox"
                      checked={checklist5T[t.k]}
                      onChange={() => setChecklist5T(prev => ({ ...prev, [t.k]: !prev[t.k] }))}
                      className="rounded text-red-600 focus:ring-red-500"
                    />
                    <span>{t.l}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Code Event Log */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Registro Cronológico del Código (Bitácora de Reanimación)
              </span>
              <button
                type="button"
                onClick={copyLogToClipboard}
                disabled={log.length === 0}
                className="text-xs flex items-center gap-1 text-slate-600 hover:text-slate-900 font-mono disabled:opacity-40"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Clipboard className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copiado' : 'Copiar Registro'}</span>
              </button>
            </div>

            <div className="max-h-48 overflow-y-auto space-y-1.5 font-mono text-xs">
              {log.length === 0 ? (
                <div className="text-slate-400 py-3 text-center text-[11px]">
                  Presione "Iniciar Reanimación" para comenzar a registrar eventos.
                </div>
              ) : (
                log.map(entry => (
                  <div key={entry.id} className="bg-white p-2 rounded-lg border border-slate-200 flex items-start gap-2.5">
                    <span className="text-red-600 font-bold shrink-0">[{entry.tiempo}]</span>
                    <span className="text-slate-700 leading-snug">{entry.texto}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: CUIDADOS POST-PARO (ROSC) COMPLETO */}
      {activeTab === 'post_paro' && (
        <div className="space-y-6">
          {/* Main ROSC Objectives Banner */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-bold shadow-xs">
                  <Activity className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 tracking-tight">
                    Protocolo de Cuidados Post-Paro Cardíaco (ROSC)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Algoritmo y metas fisiológicas prioritarias para optimización hemodinámica, neuroprotección y traslado
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-3 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-bold font-mono">
                  Guías AHA / ERC 2025-2026
                </span>
                <button
                  type="button"
                  onClick={() => setActiveTab('reanimacion')}
                  className="px-3 py-1 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-medium"
                >
                  Volver a Cronómetro
                </button>
              </div>
            </div>

            {/* Quick Goals Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-[11px] text-slate-500 font-medium block">PAM Objetivo</span>
                <span className="text-lg font-black font-mono text-emerald-700">≥ 65 mmHg</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">o TAS ≥ 90 mmHg</span>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-[11px] text-slate-500 font-medium block">Saturación SpO2</span>
                <span className="text-lg font-black font-mono text-emerald-700">92% – 98%</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">Evitar hiperoxia (100%)</span>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-[11px] text-slate-500 font-medium block">Capnografía EtCO2</span>
                <span className="text-lg font-black font-mono text-emerald-700">35 – 45 mmHg</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">10-12 rpm normocapnia</span>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-[11px] text-slate-500 font-medium block">Temperatura (CTE)</span>
                <span className="text-lg font-black font-mono text-emerald-700">32°C – 36°C</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">Evitar fiebre (&gt;37.7°C)</span>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 col-span-2 sm:col-span-1">
                <span className="text-[11px] text-slate-500 font-medium block">Glucemia Capilar</span>
                <span className="text-lg font-black font-mono text-emerald-700">140 – 180</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">mg/dL (evitar &lt;70)</span>
              </div>
            </div>
          </div>

          {/* Interactive Hemodynamic & Ventilatory Assessment */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Column: Hemodynamics & Vasopressors */}
            <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                <Gauge className="w-4 h-4 text-red-600" />
                <h4 className="text-sm font-bold text-slate-900">1. Optimización Hemodinámica y Presión Arterial</h4>
              </div>

              {/* Calculator Inputs */}
              <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div>
                  <label className="text-[11px] text-slate-600 font-medium block mb-1">
                    TAS (Presión Sistólica)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={postTas}
                      onChange={(e) => setPostTas(Number(e.target.value))}
                      className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm font-mono font-bold text-slate-900 focus:outline-none focus:border-red-500"
                    />
                    <span className="text-xs text-slate-500 font-mono">mmHg</span>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] text-slate-600 font-medium block mb-1">
                    TAD (Presión Diastólica)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={postTad}
                      onChange={(e) => setPostTad(Number(e.target.value))}
                      className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm font-mono font-bold text-slate-900 focus:outline-none focus:border-red-500"
                    />
                    <span className="text-xs text-slate-500 font-mono">mmHg</span>
                  </div>
                </div>

                {/* Result of MAP */}
                <div className="col-span-2 pt-2 border-t border-slate-200 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-slate-700">Presión Arterial Media (PAM):</span>
                    <span className={`text-base font-black font-mono ${calculatedPam >= 65 ? 'text-emerald-600' : 'text-red-600'}`}>
                      {calculatedPam} mmHg
                    </span>
                  </div>

                  <span className={`px-2 py-0.5 rounded text-[11px] font-bold font-mono ${
                    calculatedPam >= 65 
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
                      : 'bg-red-100 text-red-800 border border-red-200'
                  }`}>
                    {calculatedPam >= 65 ? '✓ Meta Adecuada (≥65)' : '⚠ Hipotensión (<65)'}
                  </span>
                </div>
              </div>

              {/* Action according to MAP */}
              {calculatedPam < 65 ? (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl space-y-2 text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-red-800">
                    <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                    <span>Hipotensión Persistente Post-Paro: Iniciar Tratamiento</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-red-700 text-[11px]">
                    <li><strong>Bolo de Cristaloides:</strong> 1 a 2 L de solución Salina 0.9% o Ringer Lactato IV/IO rápido si no hay edema pulmonar franco.</li>
                    <li><strong>Norepinefrina (Elección):</strong> 0.1 a 0.5 mcg/kg/min (o 2 a 12 mcg/min) en infusión continua titulada a PAM ≥ 65 mmHg.</li>
                    <li><strong>Epinefrina (Alternativa):</strong> 2 a 10 mcg/min si se sospecha disfunción miocárdica post-paro.</li>
                    <li><strong>Dopamina:</strong> 5 a 20 mcg/kg/min si no hay norepinefrina disponible.</li>
                  </ul>
                  <button
                    type="button"
                    onClick={() => handleAddPostRoscNote(`Hipotensión PAM=${calculatedPam} mmHg: Bolo cristaloide e infusión vasopresora iniciada.`)}
                    className="w-full mt-1 py-1.5 bg-red-600 text-white rounded-lg text-xs font-bold hover:bg-red-700 transition-colors"
                  >
                    + Registrar Vasopresor en Bitácora
                  </button>
                </div>
              ) : (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl space-y-1 text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-emerald-800">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Perfusión de Órganos Diana Asegurada (PAM ≥ 65 mmHg)</span>
                  </div>
                  <p className="text-emerald-700 text-[11px]">
                    Monitorear la presión arterial cada 2 a 3 minutos para detectar recaídas de hipotensión o bradicardias reflejas.
                  </p>
                </div>
              )}

              {/* Vasoactive Reference Table */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <span className="text-xs font-bold text-slate-800 block">Guía de Infusión Vasopresora Post-Paro</span>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                    <span className="font-bold text-slate-900 block">Norepinefrina (1ª Línea)</span>
                    <span className="text-red-600 font-mono font-bold">0.1 - 0.5 mcg/kg/min</span>
                    <p className="text-slate-500 text-[10px] mt-0.5">4 mg en 250 mL Dextrosa 5% (16 mcg/mL)</p>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                    <span className="font-bold text-slate-900 block">Epinefrina Infusión</span>
                    <span className="text-red-600 font-mono font-bold">2 - 10 mcg/min</span>
                    <p className="text-slate-500 text-[10px] mt-0.5">1 mg en 250 mL Sol. Fisiológica (4 mcg/mL)</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Vía Aérea, Ventilación & Neuroprotección */}
            <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                <Wind className="w-4 h-4 text-red-600" />
                <h4 className="text-sm font-bold text-slate-900">2. Vía Aérea, Ventilación & Neuroprotección</h4>
              </div>

              {/* Respiratory Targets */}
              <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div>
                  <label className="text-[11px] text-slate-600 font-medium block mb-1">
                    SpO2 Monitorizada (%)
                  </label>
                  <input
                    type="number"
                    value={postSpo2}
                    onChange={(e) => setPostSpo2(Number(e.target.value))}
                    className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm font-mono font-bold text-slate-900 focus:outline-none focus:border-red-500"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">Meta: 92% – 98%</span>
                </div>

                <div>
                  <label className="text-[11px] text-slate-600 font-medium block mb-1">
                    EtCO2 Capnografía (mmHg)
                  </label>
                  <input
                    type="number"
                    value={postEtco2}
                    onChange={(e) => setPostEtco2(Number(e.target.value))}
                    className="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm font-mono font-bold text-slate-900 focus:outline-none focus:border-red-500"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">Meta: 35 – 45 mmHg</span>
                </div>

                {/* Respiratory Warning */}
                <div className="col-span-2 pt-1">
                  {postSpo2 > 98 && (
                    <div className="p-2 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-800 flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span>Alerta de Hiperoxia: Titular FiO2 a la baja para mantener SpO2 entre 92-98% y prevenir toxicidad por radicales libres.</span>
                    </div>
                  )}
                  {postEtco2 < 35 && (
                    <div className="p-2 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-800 flex items-center gap-1.5 mt-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span>Alerta de Hiperventilación: Disminuir FR (10-12 rpm). La hipocapnia produce vasoconstricción cerebral e isquemia.</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Temperature & Coma Status */}
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Thermometer className="w-4 h-4 text-sky-600" />
                    <span className="text-xs font-bold text-slate-900">Control Térmico Específico (CTE)</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">Neuroprotección</span>
                </div>

                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="radio"
                      checked={patientComatose}
                      onChange={() => setPatientComatose(true)}
                      className="text-red-600 focus:ring-red-500"
                    />
                    <span>Paciente No Reactivo (Coma)</span>
                  </label>
                  <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="radio"
                      checked={!patientComatose}
                      onChange={() => setPatientComatose(false)}
                      className="text-red-600 focus:ring-red-500"
                    />
                    <span>Responde a Órdenes</span>
                  </label>
                </div>

                <div className="text-[11px] text-slate-600 bg-white p-2.5 rounded-lg border border-slate-200 space-y-1">
                  {patientComatose ? (
                    <>
                      <p className="font-bold text-slate-900">
                        • Protocolo de Control de Temperatura Seleccionado (32°C a 36°C constante):
                      </p>
                      <p>
                        Mantener temperatura objetivo por al menos 24 horas. Evitar temblores con sedación/analgesia (Fentanilo + Midazolam/Propofol).
                      </p>
                      <p className="text-red-600 font-semibold">
                        • ¡Prohibido permitir hipertermia (&gt; 37.7°C)! Tratar activamente cualquier elevación de temperatura.
                      </p>
                    </>
                  ) : (
                    <>
                      <p className="font-bold text-slate-900">
                        • Paciente Reactivo / Despierto:
                      </p>
                      <p>
                        Mantener normotermia estricta (&lt; 37.5°C). Monitorear estado neurológico y evitar hipertermia de rebote.
                      </p>
                    </>
                  )}
                </div>
              </div>

              {/* 12-Lead ECG Evaluation */}
              <div className="bg-red-50 border border-red-200 p-3.5 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 font-bold text-xs text-red-900">
                    <Radio className="w-4 h-4 text-red-600" />
                    <span>ECG de 12 Derivaciones Inmediato</span>
                  </div>
                  <span className="text-[10px] font-mono text-red-700 font-bold uppercase">Emergencia Coronaria</span>
                </div>
                <p className="text-[11px] text-red-800 leading-relaxed">
                  Realizar y transmitir ECG de 12 derivaciones tan pronto como se estabilice el paciente. Si hay elevación del segmento ST (IAMCEST) o shock cardiogénico, trasladar inmediatamente a sala de hemodinámica (ICP Primaria) sin demora.
                </p>
                <button
                  type="button"
                  onClick={() => handleAddPostRoscNote('ECG 12 derivaciones realizado: Evaluación de IAMCEST y activación de código infarto.')}
                  className="w-full py-1.5 bg-red-600 text-white rounded-lg text-xs font-bold hover:bg-red-700 transition-colors"
                >
                  + Registrar ECG 12 Derivaciones en Bitácora
                </button>
              </div>
            </div>
          </div>

          {/* Interactive Prehospital Post-ROSC Protocol Checklist */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <h4 className="text-sm font-bold text-slate-900">
                  Lista de Verificación Táctica de Cuidados Post-Paro (ROSC)
                </h4>
              </div>
              <span className="text-xs font-mono text-slate-500">
                {Object.values(postRoscChecklist).filter(Boolean).length} de {Object.keys(postRoscChecklist).length} Verificados
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {[
                {
                  id: 'via_aerea_capno',
                  titulo: 'Vía Aérea Avanzada Confirmada con Capnografía Continua',
                  desc: 'Tubo endotraqueal o dispositivo supraglótico fijado; verificar simetría torácica y onda cuadrada de EtCO2.',
                },
                {
                  id: 'normocapnia_spo2',
                  titulo: 'Ventilación Normocápnica y Oxigenación Titulada',
                  desc: '10 a 12 respiraciones/min, SpO2 92-98%, EtCO2 35-45 mmHg. Evitar estrictamente hiperventilación.',
                },
                {
                  id: 'presion_arterial_pam',
                  titulo: 'Presión Arterial Media (PAM) ≥ 65 mmHg Asegurada',
                  desc: 'Bolo de cristaloides 1-2L e inicio inmediato de Norepinefrina (0.1-0.5 mcg/kg/min) si PAM < 65 mmHg.',
                },
                {
                  id: 'ecg_12_derivaciones',
                  titulo: 'ECG de 12 Derivaciones Realizado y Transmitido',
                  desc: 'Descartar IAMCEST; activar alerta hemodinámica para intervención coronaria percutánea inmediata.',
                },
                {
                  id: 'control_temperatura',
                  titulo: 'Control de Temperatura Iniciado / Evitar Hipertermia',
                  desc: 'Si en coma: iniciar CTE a 32-36°C con medidas físicas o suero frío. En todos: prohibir fiebre (>37.7°C).',
                },
                {
                  id: 'glucosa_controlada',
                  titulo: 'Glucemia Monitorizada (Meta: 140 - 180 mg/dL)',
                  desc: 'Corregir inmediatamente hipoglucemia (< 70 mg/dL con Dextrosa al 10% o 50%); evitar hiperglucemia extrema.',
                },
                {
                  id: 'alerta_hospitalaria',
                  titulo: 'Notificación Previa de Llegada (Alerta Post-Paro ROSC)',
                  desc: 'Comunicar al centro receptor: tiempo de paro, ritmo inicial, descargas administradas, PAM actual y estado neurológico.',
                },
              ].map(item => (
                <div
                  key={item.id}
                  onClick={() => setPostRoscChecklist(prev => ({ ...prev, [item.id]: !prev[item.id] }))}
                  className={`p-3 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                    postRoscChecklist[item.id]
                      ? 'bg-emerald-50/70 border-emerald-300'
                      : 'bg-slate-50 border-slate-200 hover:bg-slate-100/70'
                  }`}
                >
                  <div className="pt-0.5 shrink-0">
                    {postRoscChecklist[item.id] ? (
                      <CheckSquare className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-400" />
                    )}
                  </div>
                  <div>
                    <h5 className={`text-xs font-bold leading-tight ${postRoscChecklist[item.id] ? 'text-emerald-950' : 'text-slate-900'}`}>
                      {item.titulo}
                    </h5>
                    <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Quick action buttons for checklist */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => {
                  const allDone = Object.keys(postRoscChecklist).reduce((acc, k) => ({ ...acc, [k]: true }), {});
                  setPostRoscChecklist(allDone);
                  handleAddPostRoscNote('Todos los criterios de cuidados post-paro completados exitosamente.');
                }}
                className="text-xs text-emerald-700 hover:text-emerald-900 font-bold flex items-center gap-1"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Marcar Todo como Cumplido</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const allReset = Object.keys(postRoscChecklist).reduce((acc, k) => ({ ...acc, [k]: false }), {});
                  setPostRoscChecklist(allReset);
                }}
                className="text-xs text-slate-500 hover:text-slate-700 font-medium"
              >
                Limpiar Checklist
              </button>
            </div>
          </div>

          {/* Integrated ROSC Event Log */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Bitácora de Reanimación & Cuidados Posparo
              </span>
              <button
                type="button"
                onClick={copyLogToClipboard}
                disabled={log.length === 0}
                className="text-xs flex items-center gap-1 text-slate-600 hover:text-slate-900 font-mono disabled:opacity-40"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Clipboard className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copiado' : 'Copiar Registro Completo'}</span>
              </button>
            </div>

            <div className="max-h-48 overflow-y-auto space-y-1.5 font-mono text-xs">
              {log.length === 0 ? (
                <div className="text-slate-400 py-3 text-center text-[11px]">
                  No hay registros de eventos en esta sesión de paro.
                </div>
              ) : (
                log.map(entry => (
                  <div key={entry.id} className="bg-white p-2 rounded-lg border border-slate-200 flex items-start gap-2.5">
                    <span className="text-red-600 font-bold shrink-0">[{entry.tiempo}]</span>
                    <span className="text-slate-700 leading-snug">{entry.texto}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
