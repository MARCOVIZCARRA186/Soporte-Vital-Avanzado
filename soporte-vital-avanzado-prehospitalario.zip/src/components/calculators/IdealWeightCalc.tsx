import React, { useState } from 'react';
import { Scale, Info, CheckCircle2 } from 'lucide-react';

export default function IdealWeightCalc() {
  const [genero, setGenero] = useState<'hombre' | 'mujer'>('hombre');
  const [alturaCm, setAlturaCm] = useState<number>(175);
  const [pesoRealKg, setPesoRealKg] = useState<number>(80);

  // PBW / Devine Formula (ARDSNet / Ventilación Mecánica)
  // Devine: Hombre = 50 + 0.91 * (altura - 152.4)
  // Devine: Mujer  = 45.5 + 0.91 * (altura - 152.4)
  const pbw = genero === 'hombre'
    ? Math.max(30, 50 + 0.91 * (alturaCm - 152.4))
    : Math.max(25, 45.5 + 0.91 * (alturaCm - 152.4));

  // Robinson Formula
  const pulgadasSobre60 = (alturaCm / 2.54) - 60;
  const robinson = genero === 'hombre'
    ? 52 + 1.9 * pulgadasSobre60
    : 49 + 1.7 * pulgadasSobre60;

  // Adjusted Body Weight (ABW) for obese patients: IBW + 0.4 * (TBW - IBW)
  const pesoAjustado = pesoRealKg > pbw ? pbw + 0.4 * (pesoRealKg - pbw) : pbw;

  // BMI
  const alturaM = alturaCm / 100;
  const imc = pesoRealKg / (alturaM * alturaM);

  const getIMCCategoria = (val: number) => {
    if (val < 18.5) return { label: 'Bajo peso', color: 'text-sky-700 bg-sky-50 border-sky-200' };
    if (val < 25) return { label: 'Normopeso', color: 'text-emerald-700 bg-emerald-50 border-emerald-200' };
    if (val < 30) return { label: 'Sobrepeso', color: 'text-amber-700 bg-amber-50 border-amber-200' };
    if (val < 35) return { label: 'Obesidad Grado I', color: 'text-orange-700 bg-orange-50 border-orange-200' };
    if (val < 40) return { label: 'Obesidad Grado II', color: 'text-rose-700 bg-rose-50 border-rose-200' };
    return { label: 'Obesidad Mórbida (Grado III)', color: 'text-red-700 bg-red-50 border-red-200 font-bold' };
  };

  const imcInfo = getIMCCategoria(imc);

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-600 font-bold">
              <Scale className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Formulador de Peso Ideal y Predicho (PBW)
              </h2>
              <p className="text-xs text-slate-500">
                Fórmulas de Devine, Robinson y Peso Ajustado para Ventilación y Fármacos
              </p>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-400">Guías ARDSNet & Devine</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Controls */}
          <div className="space-y-4">
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
              <label className="block text-xs uppercase tracking-wider text-slate-700 font-bold mb-2">
                Sexo Biológico
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setGenero('hombre')}
                  className={`py-2 px-3 rounded-lg text-xs font-bold transition-all border ${
                    genero === 'hombre'
                      ? 'bg-red-600 border-red-600 text-white shadow-xs'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Hombre
                </button>
                <button
                  type="button"
                  onClick={() => setGenero('mujer')}
                  className={`py-2 px-3 rounded-lg text-xs font-bold transition-all border ${
                    genero === 'mujer'
                      ? 'bg-red-600 border-red-600 text-white shadow-xs'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Mujer
                </button>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
              <div className="flex justify-between items-center text-xs mb-1.5">
                <span className="text-slate-600 font-medium">Talla / Estatura</span>
                <span className="font-mono text-red-600 font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
                  {alturaCm} cm
                </span>
              </div>
              <input
                type="range"
                min="135"
                max="210"
                value={alturaCm}
                onChange={(e) => setAlturaCm(Number(e.target.value))}
                className="w-full accent-red-600 cursor-pointer"
              />
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
              <div className="flex justify-between items-center text-xs mb-1.5">
                <span className="text-slate-600 font-medium">Peso Real Actual</span>
                <span className="font-mono text-slate-900 font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
                  {pesoRealKg} kg
                </span>
              </div>
              <input
                type="range"
                min="35"
                max="180"
                value={pesoRealKg}
                onChange={(e) => setPesoRealKg(Number(e.target.value))}
                className="w-full accent-slate-600 cursor-pointer"
              />
            </div>
          </div>

          {/* Results: Devine PBW, Robinson, ABW */}
          <div className="md:col-span-2 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* PBW Devine Primary Card */}
              <div className="bg-red-50/50 border border-red-200 rounded-xl p-5 shadow-xs">
                <span className="text-xs uppercase tracking-wider text-red-700 font-mono font-bold block">
                  Peso Corporal Predicho (PBW - Devine)
                </span>
                <div className="text-4xl font-black font-mono text-slate-900 mt-2">
                  {pbw.toFixed(1)} <span className="text-lg text-slate-500 font-normal">kg</span>
                </div>
                <p className="text-[11px] text-slate-600 mt-2 leading-relaxed">
                  <strong>Uso crítico:</strong> Base obligatoria para programar el volumen corriente en ventilación mecánica protectora (6-8 mL/kg).
                </p>
              </div>

              {/* Robinson Formula */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
                <span className="text-xs uppercase tracking-wider text-slate-500 font-mono font-bold block">
                  Fórmula de Robinson (1983)
                </span>
                <div className="text-4xl font-black font-mono text-slate-900 mt-2">
                  {robinson.toFixed(1)} <span className="text-lg text-slate-500 font-normal">kg</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-2">
                  Ampliamente utilizada en soporte nutricional y farmacología clínica general.
                </p>
              </div>
            </div>

            {/* Adjusted Body Weight & BMI */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-1">
                  Peso Ajustado (ABW en Obesidad)
                </span>
                <div className="text-2xl font-black font-mono text-slate-900">
                  {pesoAjustado.toFixed(1)} <span className="text-xs text-slate-500">kg</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Recomendado para calcular dosis de fármacos hidrofílicos en pacientes con sobrepeso u obesidad.
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Índice de Masa Corporal (IMC)
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${imcInfo.color}`}>
                    {imcInfo.label}
                  </span>
                </div>
                <div className="text-2xl font-black font-mono text-slate-900">
                  {imc.toFixed(1)} <span className="text-xs text-slate-500">kg/m²</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  {pesoRealKg > pbw ? `Exceso: +${(pesoRealKg - pbw).toFixed(1)} kg sobre PBW` : 'Dentro de rango normativo'}
                </p>
              </div>
            </div>

            {/* Tidal Volume Targets by PBW */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs space-y-2">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                Volúmenes Corrientes (Vt) Basados en PBW ({pbw.toFixed(1)} kg):
              </span>
              <div className="grid grid-cols-4 gap-2 text-center">
                <div className="bg-slate-50 p-2 rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-500 block font-mono">4 mL/kg</span>
                  <span className="font-mono font-bold text-slate-900 text-xs">{Math.round(pbw * 4)} mL</span>
                </div>
                <div className="bg-slate-50 p-2 rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-500 block font-mono">6 mL/kg (SDRA)</span>
                  <span className="font-mono font-bold text-red-600 text-xs">{Math.round(pbw * 6)} mL</span>
                </div>
                <div className="bg-slate-50 p-2 rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-500 block font-mono">7 mL/kg (Norma)</span>
                  <span className="font-mono font-bold text-slate-900 text-xs">{Math.round(pbw * 7)} mL</span>
                </div>
                <div className="bg-slate-50 p-2 rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-500 block font-mono">8 mL/kg (Máx)</span>
                  <span className="font-mono font-bold text-slate-900 text-xs">{Math.round(pbw * 8)} mL</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
