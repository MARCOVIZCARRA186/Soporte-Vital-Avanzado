import React, { useState } from 'react';
import { HeartPulse, AlertTriangle, ShieldAlert, CheckCircle } from 'lucide-react';

export default function ShockIndexCalc() {
  const [fc, setFc] = useState<number>(115); // bpm
  const [tas, setTas] = useState<number>(95); // mmHg
  const [tad, setTad] = useState<number>(60); // mmHg
  const [grupoEtario, setGrupoEtario] = useState<'adulto' | 'pedia_4_6' | 'pedia_7_12' | 'pedia_13_16'>('adulto');

  // Mean Arterial Pressure (TAM)
  const tam = (2 * tad + tas) / 3;

  // Shock Index (SI = FC / TAS)
  const shockIndex = tas > 0 ? fc / tas : 0;

  // Modified Shock Index (MSI = FC / TAM)
  const modifiedShockIndex = tam > 0 ? fc / tam : 0;

  // SIPA limits
  const getSipaLimit = () => {
    switch (grupoEtario) {
      case 'pedia_4_6': return 1.22;
      case 'pedia_7_12': return 1.0;
      case 'pedia_13_16': return 0.9;
      default: return 0.9;
    }
  };

  const sipaThreshold = getSipaLimit();
  const isSipaElevated = grupoEtario !== 'adulto' && shockIndex > sipaThreshold;

  // Adult SI interpretation
  const getAdultSiInterpretation = (si: number) => {
    if (si < 0.6) {
      return {
        nivel: 'Normal / Fisiológico',
        color: 'text-emerald-700 bg-emerald-50 border-emerald-200',
        badge: 'text-emerald-700',
        riesgo: 'Bajo riesgo de hipoperfusión',
        conducta: 'Constantes normales. Monitorización de rutina.'
      };
    }
    if (si < 0.9) {
      return {
        nivel: 'Rango Limítrofe / Alerta Temprana',
        color: 'text-yellow-700 bg-yellow-50 border-yellow-200',
        badge: 'text-yellow-700',
        riesgo: 'Sospecha de hipoperfusión oculta en fase compensada',
        conducta: 'Evaluar sangrado oculto, lactato/perfusión periférica, llenado capilar. Precaución con sedación que suprima el tono simpático.'
      };
    }
    if (si < 1.3) {
      return {
        nivel: 'Shock Moderado a Severo',
        color: 'text-amber-700 bg-amber-50 border-amber-200',
        badge: 'text-amber-700',
        riesgo: 'Alto riesgo de transfusión masiva y descompensación hemodinámica',
        conducta: 'Activar Protocolo de Hemorragia Masiva / Trauma. Canalizar accesos venosos de grueso calibre, Ácido Tranexámico (TXA 1g), cristaloide restrictivo.'
      };
    }
    return {
      nivel: 'Shock Profundo / Colapso Inminente (SI ≥ 1.3)',
      color: 'text-red-700 bg-red-50 border-red-200 font-bold',
      badge: 'text-red-700',
      riesgo: 'Mortalidad extrema (> 40%), fallo de bomba o exsanguinación crítica',
      conducta: '¡CÓDIGO ROJO! Detener sangrado externo (torniquete/empaquetamiento), hipotensión permisiva (TAS 80-90), traslado emergente con preaviso hospitalario.'
    };
  };

  const interp = getAdultSiInterpretation(shockIndex);

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-600 font-bold">
              <HeartPulse className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Calculador de Índice de Choque (SI, MSI y SIPA Pediátrico)
              </h2>
              <p className="text-xs text-slate-500">
                Detección precoz de shock oculto, hemorragia activa y necesidad de transfusión masiva
              </p>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-400">Guías ATLS & ITLS</span>
        </div>

        {/* Age Group Selector */}
        <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200">
          {[
            { id: 'adulto', label: 'Adulto (SI estándar)' },
            { id: 'pedia_4_6', label: 'Pediátrico 4 - 6 años (SIPA > 1.22)' },
            { id: 'pedia_7_12', label: 'Pediátrico 7 - 12 años (SIPA > 1.0)' },
            { id: 'pedia_13_16', label: 'Pediátrico 13 - 16 años (SIPA > 0.9)' },
          ].map(grp => (
            <button
              key={grp.id}
              type="button"
              onClick={() => setGrupoEtario(grp.id as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                grupoEtario === grp.id
                  ? 'bg-red-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {grp.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
              <div className="flex justify-between items-center text-xs mb-1.5">
                <span className="text-slate-600 font-medium">Frecuencia Cardíaca (FC)</span>
                <span className="font-mono text-red-600 font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
                  {fc} lpm
                </span>
              </div>
              <input
                type="range"
                min="40"
                max="210"
                value={fc}
                onChange={(e) => setFc(Number(e.target.value))}
                className="w-full accent-red-600 cursor-pointer"
              />
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
              <div className="flex justify-between items-center text-xs mb-1.5">
                <span className="text-slate-600 font-medium">Presión Arterial Sistólica (TAS)</span>
                <span className="font-mono text-slate-900 font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
                  {tas} mmHg
                </span>
              </div>
              <input
                type="range"
                min="40"
                max="220"
                value={tas}
                onChange={(e) => setTas(Number(e.target.value))}
                className="w-full accent-slate-700 cursor-pointer"
              />
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
              <div className="flex justify-between items-center text-xs mb-1.5">
                <span className="text-slate-600 font-medium">Presión Arterial Diastólica (TAD)</span>
                <span className="font-mono text-slate-900 font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
                  {tad} mmHg
                </span>
              </div>
              <input
                type="range"
                min="20"
                max="140"
                value={tad}
                onChange={(e) => setTad(Number(e.target.value))}
                className="w-full accent-slate-700 cursor-pointer"
              />
              <div className="mt-2 pt-2 border-t border-slate-200 flex justify-between items-center text-[11px] font-mono text-slate-500">
                <span>Presión Arterial Media (PAM):</span>
                <strong className="text-slate-800">{tam.toFixed(1)} mmHg</strong>
              </div>
            </div>
          </div>

          {/* Results: Shock Index, MSI, SIPA interpretation */}
          <div className="lg:col-span-7 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Classical Shock Index (SI = FC / TAS) */}
              <div className="bg-red-50/50 border border-red-200 rounded-xl p-5 shadow-xs">
                <span className="text-xs uppercase tracking-wider text-red-700 font-mono font-bold block">
                  Índice de Choque Clásico (SI = FC / TAS)
                </span>
                <div className="text-5xl font-black font-mono text-slate-900 mt-2">
                  {shockIndex.toFixed(2)}
                </div>
                <div className="mt-3 text-xs text-slate-600">
                  {shockIndex >= 1.0 ? (
                    <span className="text-red-700 font-bold">⚠️ FC supera la TAS: Shock descompensado severo</span>
                  ) : shockIndex >= 0.7 ? (
                    <span className="text-amber-700 font-medium">⚠️ Hipoperfusión oculta en curso</span>
                  ) : (
                    <span className="text-emerald-700 font-medium">✓ Rango normal (0.5 a 0.7)</span>
                  )}
                </div>
              </div>

              {/* Modified Shock Index (MSI = FC / TAM) */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
                <span className="text-xs uppercase tracking-wider text-slate-500 font-mono font-bold block">
                  Índice Modificado (MSI = FC / PAM)
                </span>
                <div className="text-5xl font-black font-mono text-slate-900 mt-2">
                  {modifiedShockIndex.toFixed(2)}
                </div>
                <div className="mt-3 text-xs text-slate-600">
                  {modifiedShockIndex > 1.3 ? (
                    <span className="text-red-700 font-bold">⚠️ Mortalidad y necesidad de transfusión elevadas</span>
                  ) : (
                    <span className="text-slate-500 font-mono">Normal: 0.7 a 1.3</span>
                  )}
                </div>
              </div>
            </div>

            {/* Detailed Clinical Interpretation Banner */}
            <div className={`p-4 rounded-xl border ${interp.color} space-y-2`}>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider">{interp.nivel}</span>
                <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded bg-white/80 border border-current">
                  {interp.riesgo}
                </span>
              </div>
              <p className="text-xs leading-relaxed">{interp.conducta}</p>
            </div>

            {/* Pediatric SIPA Alert if selected */}
            {grupoEtario !== 'adulto' && (
              <div className={`p-4 rounded-xl border ${isSipaElevated ? 'bg-red-50 border-red-300 text-red-900' : 'bg-emerald-50 border-emerald-300 text-emerald-900'}`}>
                <div className="flex items-center justify-between text-xs font-bold">
                  <span>Evaluación SIPA (Shock Index Pediatric Adjusted):</span>
                  <span className="font-mono">Umbral: &gt; {sipaThreshold}</span>
                </div>
                <p className="text-xs mt-1">
                  {isSipaElevated
                    ? `⚠️ ALERTA PEDIÁTRICA: El índice (${shockIndex.toFixed(2)}) supera el umbral SIPA (${sipaThreshold}). Alto riesgo de lesión intraabdominal y necesidad de transfusión en pediatría.`
                    : `✓ SIPA dentro de límites esperados para el grupo etario.`}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
