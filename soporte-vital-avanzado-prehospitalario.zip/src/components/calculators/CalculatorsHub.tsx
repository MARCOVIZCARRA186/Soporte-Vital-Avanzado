import React, { useState, useEffect } from 'react';
import { 
  Syringe, Scale, Droplets, Wind, Flame, HeartPulse, Brain 
} from 'lucide-react';
import DrugDosageCalc from './DrugDosageCalc';
import IdealWeightCalc from './IdealWeightCalc';
import InfusionCalculator from './InfusionCalculator';
import VentilationCalc from './VentilationCalc';
import ParklandBurnCalc from './ParklandBurnCalc';
import ShockIndexCalc from './ShockIndexCalc';
import GlasgowCalc from './GlasgowCalc';

export type SubCalcId = 'dosis' | 'peso_ideal' | 'infusiones' | 'ventilacion' | 'parkland' | 'shock' | 'glasgow';

interface CalculatorsHubProps {
  initialSubCalc?: SubCalcId;
  onSubCalcChange?: (calc: SubCalcId) => void;
}

export default function CalculatorsHub({ initialSubCalc, onSubCalcChange }: CalculatorsHubProps) {
  const [activeSubCalc, setActiveSubCalc] = useState<SubCalcId>(initialSubCalc || 'dosis');

  useEffect(() => {
    if (initialSubCalc) {
      setActiveSubCalc(initialSubCalc);
    }
  }, [initialSubCalc]);

  const handleSelectCalc = (id: SubCalcId) => {
    setActiveSubCalc(id);
    if (onSubCalcChange) onSubCalcChange(id);
  };

  const subCalculators = [
    { id: 'dosis', label: 'Dosis por Fármaco', icon: Syringe, desc: 'Bolo y volumen en mL (42 fármacos)' },
    { id: 'peso_ideal', label: 'Peso Ideal / PBW', icon: Scale, desc: 'Devine, Robinson, ventilación' },
    { id: 'infusiones', label: 'Bombas e Infusiones', icon: Droplets, desc: 'mL/h y microgotas/min' },
    { id: 'ventilacion', label: 'Ventilación & EtCO₂', icon: Wind, desc: 'Vt, VE, ΔP y Capnografía' },
    { id: 'parkland', label: 'Quemados (Parkland)', icon: Flame, desc: 'SCQ Regla de los 9 y horarios' },
    { id: 'shock', label: 'Índice de Choque', icon: HeartPulse, desc: 'SI, MSI, SIPA pediátrico' },
    { id: 'glasgow', label: 'Glasgow (GCS-P)', icon: Brain, desc: 'Ocular, verbal, motor, pupilar' },
  ];

  return (
    <div className="space-y-6">
      {/* Sub-calculator segmented bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
        {subCalculators.map(calc => {
          const Icon = calc.icon;
          const isActive = activeSubCalc === calc.id;
          return (
            <button
              key={calc.id}
              type="button"
              onClick={() => handleSelectCalc(calc.id as SubCalcId)}
              className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between ${
                isActive
                  ? 'bg-red-50/90 border-red-400 shadow-xs text-slate-900 ring-1 ring-red-300'
                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center justify-between w-full">
                <Icon className={`w-4 h-4 ${isActive ? 'text-red-600' : 'text-slate-400'}`} />
                {isActive && <span className="w-1.5 h-1.5 rounded-full bg-red-600" />}
              </div>
              <div className="mt-2">
                <span className={`text-xs font-bold block ${isActive ? 'text-red-700' : 'text-slate-800'}`}>
                  {calc.label}
                </span>
                <span className="text-[10px] text-slate-400 font-mono block truncate">
                  {calc.desc}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Render active subcalculator */}
      <div>
        {activeSubCalc === 'dosis' && <DrugDosageCalc />}
        {activeSubCalc === 'peso_ideal' && <IdealWeightCalc />}
        {activeSubCalc === 'infusiones' && <InfusionCalculator />}
        {activeSubCalc === 'ventilacion' && <VentilationCalc />}
        {activeSubCalc === 'parkland' && <ParklandBurnCalc />}
        {activeSubCalc === 'shock' && <ShockIndexCalc />}
        {activeSubCalc === 'glasgow' && <GlasgowCalc />}
      </div>
    </div>
  );
}
