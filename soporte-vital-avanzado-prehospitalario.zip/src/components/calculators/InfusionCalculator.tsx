import React, { useState } from 'react';
import { Droplet, Activity, Clock, Zap, AlertCircle } from 'lucide-react';
import { VASOACTIVE_PRESETS } from '../../data/pharmacologyData';

export default function InfusionCalculator() {
  const [selectedPresetId, setSelectedPresetId] = useState<string>('noradrenalina');
  const [pesoKg, setPesoKg] = useState<number>(70);
  const [farmacoMg, setFarmacoMg] = useState<number>(4);
  const [volumenTotalMl, setVolumenTotalMl] = useState<number>(250);
  const [dosisTarget, setDosisTarget] = useState<number>(0.1); // e.g. 0.1 mcg/kg/min
  const [unidadDosis, setUnidadDosis] = useState<'mcg/kg/min' | 'mcg/min' | 'mg/h'>('mcg/kg/min');
  const [factorGoteo, setFactorGoteo] = useState<number>(20); // 20 gtt/mL standard or 60 for micro

  const handleSelectPreset = (presetId: string) => {
    setSelectedPresetId(presetId);
    if (presetId === 'custom') return;
    const preset = VASOACTIVE_PRESETS.find(p => p.id === presetId);
    if (preset) {
      setFarmacoMg(preset.ampollaMg);
      setVolumenTotalMl(preset.dilucionEstandarMl);
      setDosisTarget(preset.rangoDosis.tipico);
      setUnidadDosis(preset.unidadDosis);
    }
  };

  // Calculations
  const totalMcg = farmacoMg * 1000;
  const concentracionMcgMl = volumenTotalMl > 0 ? totalMcg / volumenTotalMl : 0;
  const concentracionMgMl = volumenTotalMl > 0 ? farmacoMg / volumenTotalMl : 0;

  let dosisPorMinutoMcg = 0;
  let dosisPorHoraMg = 0;

  if (unidadDosis === 'mcg/kg/min') {
    dosisPorMinutoMcg = dosisTarget * pesoKg;
    dosisPorHoraMg = (dosisPorMinutoMcg * 60) / 1000;
  } else if (unidadDosis === 'mcg/min') {
    dosisPorMinutoMcg = dosisTarget;
    dosisPorHoraMg = (dosisPorMinutoMcg * 60) / 1000;
  } else {
    dosisPorHoraMg = dosisTarget;
    dosisPorMinutoMcg = (dosisTarget * 1000) / 60;
  }

  // Rate in mL/h = (dosis en mcg/h) / (concentracion en mcg/mL)
  const mlPorHora = concentracionMcgMl > 0 ? (dosisPorMinutoMcg * 60) / concentracionMcgMl : 0;

  // Microgotero: 1 mL = 60 microgotas -> microgotas/min = mL/h
  const microgotasPorMin = mlPorHora;

  // Normogotero: gotas/min = (mL/h * factorGoteo) / 60
  const gotasPorMin = (mlPorHora * factorGoteo) / 60;

  // Time remaining for bottle
  const horasRestantes = mlPorHora > 0 ? volumenTotalMl / mlPorHora : 0;

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-600 font-bold">
              <Droplet className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Calculador de Infusiones Continuas Prehospitalarias
              </h2>
              <p className="text-xs text-slate-500">
                Bombas de Infusión (mL/h) y Microgoteros / Macrogoteros (gotas/min)
              </p>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-400">Vasoactivos & Sedoanalgesia</span>
        </div>

        {/* Preset Selector */}
        <div className="space-y-2">
          <label className="block text-xs uppercase tracking-wider text-slate-700 font-bold">
            Fármacos y Diluciones Estándar
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
            {VASOACTIVE_PRESETS.map(preset => (
              <button
                key={preset.id}
                type="button"
                onClick={() => handleSelectPreset(preset.id)}
                className={`p-2.5 rounded-lg text-left transition-all border ${
                  selectedPresetId === preset.id
                    ? 'bg-red-50 border-red-500 text-slate-900 shadow-2xs font-bold'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span className={`text-xs block truncate ${selectedPresetId === preset.id ? 'text-red-700' : 'text-slate-900'}`}>
                  {preset.nombre.split(' ')[0]}
                </span>
                <span className="text-[10px] text-slate-500 font-mono block mt-0.5">
                  {preset.ampollaMg}mg en {preset.dilucionEstandarMl}mL
                </span>
              </button>
            ))}
            <button
              type="button"
              onClick={() => handleSelectPreset('custom')}
              className={`p-2.5 rounded-lg text-left transition-all border ${
                selectedPresetId === 'custom'
                  ? 'bg-red-50 border-red-500 text-slate-900 shadow-2xs font-bold'
                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <span className="text-xs font-bold block text-slate-900">Manual / Libre</span>
              <span className="text-[10px] text-slate-500 font-mono block mt-0.5">Cualquier dosis</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
              <div className="flex justify-between items-center text-xs mb-1.5">
                <span className="text-slate-600 font-medium">Peso del Paciente</span>
                <span className="font-mono text-red-600 font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
                  {pesoKg} kg
                </span>
              </div>
              <input
                type="range"
                min="10"
                max="140"
                value={pesoKg}
                onChange={(e) => setPesoKg(Number(e.target.value))}
                className="w-full accent-red-600 cursor-pointer"
              />
            </div>

            {/* Drug mg and Dilution */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Preparación de la Mezcla
              </span>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] text-slate-500 block mb-1">Fármaco Total (mg)</label>
                  <input
                    type="number"
                    value={farmacoMg}
                    onChange={(e) => setFarmacoMg(Math.max(0.1, Number(e.target.value)))}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-mono text-slate-900 focus:border-red-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-500 block mb-1">Volumen Solución (mL)</label>
                  <input
                    type="number"
                    value={volumenTotalMl}
                    onChange={(e) => setVolumenTotalMl(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-mono text-slate-900 focus:border-red-500 focus:outline-none"
                  />
                </div>
              </div>
              <div className="text-[11px] font-mono text-slate-500 pt-1">
                Concentración: <strong className="text-slate-900">{concentracionMcgMl.toFixed(1)} mcg/mL</strong> ({concentracionMgMl.toFixed(3)} mg/mL)
              </div>
            </div>

            {/* Target Dose */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Dosis Deseada
                </span>
                <div className="flex gap-1 text-[10px]">
                  {(['mcg/kg/min', 'mcg/min', 'mg/h'] as const).map(u => (
                    <button
                      key={u}
                      type="button"
                      onClick={() => setUnidadDosis(u)}
                      className={`px-1.5 py-0.5 rounded font-mono font-semibold ${
                        unidadDosis === u ? 'bg-red-600 text-white' : 'bg-white border border-slate-200 text-slate-600'
                      }`}
                    >
                      {u}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <input
                  type="number"
                  step="0.01"
                  value={dosisTarget}
                  onChange={(e) => setDosisTarget(Math.max(0, Number(e.target.value)))}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-base font-mono font-bold text-red-600 focus:border-red-500 focus:outline-none"
                />
              </div>

              {/* Drip factor selector */}
              <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-xs">
                <span className="text-slate-500">Sistema de Infusión:</span>
                <select
                  value={factorGoteo}
                  onChange={(e) => setFactorGoteo(Number(e.target.value))}
                  className="bg-white border border-slate-200 rounded px-2 py-1 text-slate-800 text-xs font-mono"
                >
                  <option value={60}>Microgotero (60 gtt/mL)</option>
                  <option value={20}>Normogotero Estándar (20 gtt/mL)</option>
                  <option value={15}>Macrogotero (15 gtt/mL)</option>
                  <option value={10}>Macrogotero Sangre (10 gtt/mL)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Results Display */}
          <div className="lg:col-span-7 space-y-4">
            {/* Primary Infusion Pump Rate (mL/h) */}
            <div className="bg-red-50/50 border border-red-200 rounded-xl p-5 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs uppercase tracking-wider text-red-700 font-mono font-bold">
                  Velocidad en Bomba de Infusión Continua
                </span>
                <span className="text-xs font-mono font-bold text-slate-500">BOMBA VOLUMÉTRICA</span>
              </div>

              <div className="bg-white p-5 rounded-xl border border-red-100 shadow-2xs flex items-baseline justify-between">
                <div>
                  <span className="text-xs text-slate-500 block">Flujo Programable:</span>
                  <div className="text-5xl font-black font-mono text-slate-900 mt-1 tabular-nums">
                    {mlPorHora.toFixed(1)} <span className="text-xl text-slate-500 font-normal">mL / h</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[11px] text-slate-400 font-mono block">Dosis Hora:</span>
                  <span className="text-lg font-bold font-mono text-slate-700">
                    {dosisPorHoraMg.toFixed(2)} mg/h
                  </span>
                </div>
              </div>
            </div>

            {/* Gravity Drips: Microdripper vs Macrodripper */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Microdrip Set (60 gtt/mL) */}
              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Microgotero (60 gtt/mL)
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                    1 mL = 60 μgtt
                  </span>
                </div>
                <div className="text-3xl font-black font-mono text-slate-900 mt-1">
                  {Math.round(microgotasPorMin)} <span className="text-sm text-slate-500 font-normal">μgtt / min</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-2 font-mono">
                  En microgotero: <strong>microgotas/min = mL/h</strong> exactamente ({mlPorHora.toFixed(1)}).
                </p>
              </div>

              {/* Selected Gravity Set */}
              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Gotero a Gravedad ({factorGoteo} gtt/mL)
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                    Factor {factorGoteo}
                  </span>
                </div>
                <div className="text-3xl font-black font-mono text-red-600 mt-1">
                  {Math.round(gotasPorMin)} <span className="text-sm text-slate-500 font-normal">gotas / min</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-2 font-mono">
                  Equivale a 1 gota cada <strong>{(60 / (gotasPorMin || 1)).toFixed(1)} segundos</strong>.
                </p>
              </div>
            </div>

            {/* Bottle duration alert */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-center justify-between text-xs font-mono">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-slate-500" />
                <span className="text-slate-700">Duración estimada del frasco ({volumenTotalMl} mL):</span>
              </div>
              <span className="font-bold text-slate-900">
                {horasRestantes > 24 ? '> 24 horas' : `${horasRestantes.toFixed(1)} horas (${Math.round(horasRestantes * 60)} min)`}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
