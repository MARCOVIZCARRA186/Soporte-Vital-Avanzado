import React, { useState } from 'react';
import { Brain, AlertCircle, Eye, MessageSquare, Hand, ShieldAlert, CheckCircle2 } from 'lucide-react';

export default function GlasgowCalc() {
  const [ocular, setOcular] = useState<number>(4);
  const [verbal, setVerbal] = useState<number>(5);
  const [isVerbalNt, setIsVerbalNt] = useState<boolean>(false);
  const [motor, setMotor] = useState<number>(6);
  const [pupilasNoReactivas, setPupilasNoReactivas] = useState<number>(0); // 0, 1, or 2

  // Total GCS
  const gcsTotal = isVerbalNt ? ocular + motor : ocular + verbal + motor;
  
  // GCS-Pupil (GCS-P = GCS - pupilas que no reaccionan)
  const gcsP = Math.max(1, gcsTotal - pupilasNoReactivas);

  const getSeveridad = (score: number) => {
    if (score >= 13) {
      return {
        label: 'TCE Leve (GCS 13 - 15)',
        color: 'text-emerald-700 bg-emerald-50 border-emerald-200',
        alertaViaAerea: false,
        desc: 'Bajo riesgo de deterioro inmediato. Observación clínica neurológica seriada.'
      };
    }
    if (score >= 9) {
      return {
        label: 'TCE Moderado (GCS 9 - 12)',
        color: 'text-amber-700 bg-amber-50 border-amber-200',
        alertaViaAerea: false,
        desc: 'Riesgo significativo de deterioro neurológico. Traslado urgente con TAC cerebral prioritario.'
      };
    }
    return {
      label: 'TCE Grave / Severo (GCS ≤ 8)',
      color: 'text-red-700 bg-red-50 border-red-200 font-bold',
      alertaViaAerea: true,
      desc: 'Coma profundo. Pérdida inminente de los reflejos protectores de la vía aérea. Riesgo crítico de hipoxia cerebral y broncoaspiración.'
    };
  };

  const severidad = getSeveridad(gcsTotal);

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-600 font-bold">
              <Brain className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Escala de Coma de Glasgow y Reactividad Pupilar (GCS-P)
              </h2>
              <p className="text-xs text-slate-500">
                Evaluación neurológica objetiva, clasificación de TCE y umbral crítico de intubación (≤ 8)
              </p>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-400">Teasdale & Jennett (Actualizado GCS-P)</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Subscales Selection */}
          <div className="lg:col-span-7 space-y-4">
            {/* Ocular */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Eye className="w-4 h-4 text-red-600" />
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Apertura Ocular (O)
                  </span>
                </div>
                <span className="font-mono text-xs font-bold text-red-600">{ocular} / 4 pts</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { pts: 4, l: '4. Espontánea' },
                  { pts: 3, l: '3. A la orden verbal' },
                  { pts: 2, l: '2. Al estímulo de presión' },
                  { pts: 1, l: '1. Ninguna' },
                ].map(opt => (
                  <button
                    key={opt.pts}
                    type="button"
                    onClick={() => setOcular(opt.pts)}
                    className={`p-2 rounded-lg text-xs font-medium text-left border transition-all ${
                      ocular === opt.pts
                        ? 'bg-red-50 border-red-500 text-red-900 font-bold shadow-2xs'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {opt.l}
                  </button>
                ))}
              </div>
            </div>

            {/* Verbal */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-red-600" />
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Respuesta Verbal (V)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <label className="flex items-center gap-1.5 text-[11px] text-slate-500 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isVerbalNt}
                      onChange={(e) => setIsVerbalNt(e.target.checked)}
                      className="rounded text-red-600"
                    />
                    <span>NT (Intubado / Afasia)</span>
                  </label>
                  <span className="font-mono text-xs font-bold text-red-600">{isVerbalNt ? 'NT' : `${verbal} / 5 pts`}</span>
                </div>
              </div>
              {!isVerbalNt ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {[
                    { pts: 5, l: '5. Orientada y conversando' },
                    { pts: 4, l: '4. Desorientada / Confusa' },
                    { pts: 3, l: '3. Palabras inapropiadas' },
                    { pts: 2, l: '2. Sonidos incomprensibles' },
                    { pts: 1, l: '1. Ninguna respuesta' },
                  ].map(opt => (
                    <button
                      key={opt.pts}
                      type="button"
                      onClick={() => setVerbal(opt.pts)}
                      className={`p-2 rounded-lg text-xs font-medium text-left border transition-all ${
                        verbal === opt.pts
                          ? 'bg-red-50 border-red-500 text-red-900 font-bold shadow-2xs'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {opt.l}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="p-2.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-500 italic">
                  Componente verbal no testeable (NT) por intubación endotraqueal previa o traqueostomía.
                </div>
              )}
            </div>

            {/* Motor */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Hand className="w-4 h-4 text-red-600" />
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Respuesta Motora (M)
                  </span>
                </div>
                <span className="font-mono text-xs font-bold text-red-600">{motor} / 6 pts</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                {[
                  { pts: 6, l: '6. Obedece órdenes' },
                  { pts: 5, l: '5. Localiza el dolor' },
                  { pts: 4, l: '4. Flexión normal / Retirada' },
                  { pts: 3, l: '3. Flexión anormal (Decorticación)' },
                  { pts: 2, l: '2. Extensión anormal (Descerebración)' },
                  { pts: 1, l: '1. Ninguna respuesta motora' },
                ].map(opt => (
                  <button
                    key={opt.pts}
                    type="button"
                    onClick={() => setMotor(opt.pts)}
                    className={`p-2 rounded-lg text-xs font-medium text-left border transition-all ${
                      motor === opt.pts
                        ? 'bg-red-50 border-red-500 text-red-900 font-bold shadow-2xs'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {opt.l}
                  </button>
                ))}
              </div>
            </div>

            {/* Pupillary Reactivity (GCS-P) */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                Reactividad Pupilar a la Luz (Pérdida Pupilar para GCS-P)
              </span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { val: 0, l: 'Ambas reactivas', sub: '-0 pts (Normal)' },
                  { val: 1, l: '1 pupila no reactiva', sub: '-1 pt (Anisocoria)' },
                  { val: 2, l: 'Ninguna reactiva', sub: '-2 pts (Midriasis bilateral)' },
                ].map(p => (
                  <button
                    key={p.val}
                    type="button"
                    onClick={() => setPupilasNoReactivas(p.val)}
                    className={`p-2 rounded-lg text-left border transition-all ${
                      pupilasNoReactivas === p.val
                        ? 'bg-red-50 border-red-500 text-red-900 font-bold shadow-2xs'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div className="text-xs font-bold">{p.l}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{p.sub}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Results: Glasgow Total Score & Clinical Guidance */}
          <div className="lg:col-span-5 space-y-4">
            {/* Score Big Card */}
            <div className="bg-red-50/50 border border-red-200 rounded-xl p-5 shadow-xs text-center">
              <span className="text-xs font-mono uppercase tracking-wider text-red-700 font-bold block">
                Puntaje Total de Glasgow
              </span>
              <div className="text-6xl font-black font-mono text-slate-900 mt-2">
                {gcsTotal}
                <span className="text-2xl text-slate-400 font-normal"> / {isVerbalNt ? '10 (NT)' : '15'}</span>
              </div>
              <div className="text-xs font-mono text-slate-500 mt-2">
                O:{ocular} + V:{isVerbalNt ? 'NT' : verbal} + M:{motor}
              </div>

              {pupilasNoReactivas > 0 && (
                <div className="mt-3 pt-3 border-t border-red-100 flex items-center justify-between text-xs">
                  <span className="text-red-700 font-bold">Puntaje GCS-P (con pupilas):</span>
                  <span className="font-mono font-black text-red-700 text-lg">{gcsP}</span>
                </div>
              )}
            </div>

            {/* Severity Card */}
            <div className={`p-4 rounded-xl border ${severidad.color} space-y-1.5`}>
              <span className="text-xs font-bold uppercase tracking-wider block">{severidad.label}</span>
              <p className="text-xs leading-relaxed">{severidad.desc}</p>
            </div>

            {/* Intubation Alert if GCS <= 8 */}
            {severidad.alertaViaAerea ? (
              <div className="p-4 bg-red-600 text-white rounded-xl shadow-xs space-y-2">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 animate-pulse" />
                  <span className="font-black text-sm uppercase tracking-wide">
                    ¡INDICACIÓN FORMAL DE INTUBACIÓN (GCS ≤ 8)!
                  </span>
                </div>
                <p className="text-xs leading-relaxed text-red-100">
                  "Glasgow 8 o menos, intubación al momento". El paciente no puede proteger la vía aérea. Proceder con Secuencia Rápida de Intubación (SRI) y preoxigenación agresiva para evitar hipoxia cerebral secundaria (SpO2 &gt; 94% obligatoria).
                </p>
              </div>
            ) : (
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Reflejos de vía aérea preservados. Mantener reevaluación cada 5 minutos.</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
