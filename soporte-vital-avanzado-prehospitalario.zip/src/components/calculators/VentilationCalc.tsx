import React, { useState } from 'react';
import { 
  Wind, AlertTriangle, CheckCircle2, Activity, Gauge, 
  Flame, Layers, ChevronRight, HelpCircle, ShieldAlert, 
  Sparkles, Stethoscope, Clock, CheckCircle, Scale 
} from 'lucide-react';
import CapnographyViewer from './CapnographyViewer';
import { 
  INDICACIONES_VENTILACION_AVENTHO, 
  ESCALA_SEDACION_AVENTHO, 
  ACIDO_BASE_AVENTHO 
} from '../../data/aventhoVentilationData';

export default function VentilationCalc() {
  const [activeTab, setActiveTab] = useState<
    'programacion' | 'capnografia' | 'monitoreo' | 'co2_metabolico' | 'gases_aventho' | 'retiro_sedacion'
  >('programacion');

  // Anthropometrics
  const [genero, setGenero] = useState<'hombre' | 'mujer'>('hombre');
  const [alturaCm, setAlturaCm] = useState<number>(175);
  const [tieneSdra, setTieneSdra] = useState<boolean>(false);
  const [edadAnos, setEdadAnos] = useState<number>(45);

  // Ventilator Basic Setup
  const [mlPorKg, setMlPorKg] = useState<number>(6); // 6 mL/kg ARDSNet standard
  const [frProgramada, setFrProgramada] = useState<number>(16); // rpm
  const [peep, setPeep] = useState<number>(8); // cmH2O
  const [pmax, setPmax] = useState<number>(24); // cmH2O peak pressure
  const [pplat, setPplat] = useState<number>(20); // cmH2O plateau pressure
  const [pao2, setPao2] = useState<number>(85); // mmHg
  const [fio2Percent, setFio2Percent] = useState<number>(50); // %

  // Acid-Base & Metabolic CO2 Tuning (AVENTHO Page 7)
  const [trastornoMetabolico, setTrastornoMetabolico] = useState<'acidosis' | 'alcalosis'>('acidosis');
  const [hco3, setHco3] = useState<number>(14); // mEq/L
  const [paco2Actual, setPaco2Actual] = useState<number>(38); // mmHg
  const [frActual, setFrActual] = useState<number>(16); // rpm

  // Weaning / Tobin Index (RSBI)
  const [frEspontanea, setFrEspontanea] = useState<number>(22);
  const [vtExhaladoLitros, setVtExhaladoLitros] = useState<number>(0.35); // 350 mL = 0.35 L
  const [vtConManguito, setVtConManguito] = useState<number>(450);
  const [vtSinManguito, setVtSinManguito] = useState<number>(320);

  // --- AVENTHO Weight Formulas (Page 2) ---
  const alturaM = alturaCm / 100;
  // Sin SDRA: Talla(m)² * 23 (hombre) / 21.5 (mujer)
  const pesoIdealSinSdra = genero === 'hombre'
    ? alturaM * alturaM * 23
    : alturaM * alturaM * 21.5;

  // Con SDRA (PBW): [Talla (cm) - 152.4] * 0.91 + 50 (hombre) / + 45 (mujer)
  const pesoPredichoConSdra = genero === 'hombre'
    ? Math.max(30, (alturaCm - 152.4) * 0.91 + 50)
    : Math.max(25, (alturaCm - 152.4) * 0.91 + 45);

  const pesoCalculo = tieneSdra ? pesoPredichoConSdra : pesoIdealSinSdra;

  // Tidal volumes
  const vtRecomendado = Math.round(pesoCalculo * mlPorKg);
  const vt4 = Math.round(pesoCalculo * 4);
  const vt6 = Math.round(pesoCalculo * 6);
  const vt7 = Math.round(pesoCalculo * 7);
  const vt8 = Math.round(pesoCalculo * 8);

  // Minute Volume (VE = Vt * FR)
  const veLitros = (vtRecomendado * frProgramada) / 1000;

  // --- AVENTHO Mechanics (Pages 8-9) ---
  // Presión Transaérea = Pmax - Pplat (Normal < 2.5 - 3 cmH2O)
  const presionTransaerea = pmax - pplat;
  const isPresionTransaereaAlta = presionTransaerea > 3;

  // Driving Pressure = Pplat - PEEP (Meta < 14, ideal < 13 en SDRA)
  const drivingPressure = pplat - peep;
  const isDrivingPressureHigh = drivingPressure > 13;

  // Static Compliance = Vt / (Pplat - PEEP) (Normal 70 - 100 mL/cmH2O en intubados no SDRA)
  const cstat = drivingPressure > 0 ? vtRecomendado / drivingPressure : 0;

  // PaO2 / FiO2 Kirby Index
  const fio2Decimal = fio2Percent / 100;
  const kirbyIndex = fio2Decimal > 0 ? pao2 / fio2Decimal : 0;

  const getKirbyClassification = (val: number) => {
    if (val > 300) return { label: 'Normal / Sin SDRA', color: 'text-emerald-700 bg-emerald-50 border-emerald-200', desc: 'PaO2/FiO2 > 300' };
    if (val >= 200) return { label: 'SDRA Leve', color: 'text-yellow-700 bg-yellow-50 border-yellow-200', desc: '200 < PaO2/FiO2 ≤ 300' };
    if (val >= 100) return { label: 'SDRA Moderado', color: 'text-amber-700 bg-amber-50 border-amber-200', desc: '100 < PaO2/FiO2 ≤ 200 (Evaluar Prono)' };
    return { label: 'SDRA Grave', color: 'text-red-700 bg-red-50 border-red-200 font-bold', desc: 'PaO2/FiO2 ≤ 100 (Prono + BNM obligado)' };
  };

  const kirbyInfo = getKirbyClassification(kirbyIndex);

  // --- AVENTHO Metabolic CO2 Formulas (Page 7) ---
  // Acidosis metabólica (Winter): (HCO3 * 1.5) + 8 (rango +- 2)
  // Alcalosis metabólica: (HCO3 * 0.7) + 21 (rango +- 2)
  const co2Esperado = trastornoMetabolico === 'acidosis'
    ? Number(((hco3 * 1.5) + 8).toFixed(1))
    : Number(((hco3 * 0.7) + 21).toFixed(1));

  // Ajuste de FR = (FR act * CO2 act) / CO2e
  const frNueva = co2Esperado > 0 ? Number(((frActual * paco2Actual) / co2Esperado).toFixed(1)) : frActual;
  // Ajuste de Vt = (Vt act * CO2 act) / CO2e
  const vtNuevo = co2Esperado > 0 ? Math.round((vtRecomendado * paco2Actual) / co2Esperado) : vtRecomendado;

  // --- AVENTHO PaO2 expected by age (Page 17) ---
  // PaO2 = 104.2 - (0.27 * edad)
  const pao2EsperadaEdad = Number((104.2 - 0.27 * edadAnos).toFixed(1));

  // --- Weaning: Tobin / RSBI (Page 15) ---
  // RSBI = FR / Vt en litros (éxito < 105)
  const tobinIndex = vtExhaladoLitros > 0 ? Math.round(frEspontanea / vtExhaladoLitros) : 0;
  const isTobinExitoso = tobinIndex > 0 && tobinIndex < 105;

  // Cuff leak test (% de fuga = (Vt con cuff - Vt sin cuff) / Vt con cuff * 100)
  const pctFuga = vtConManguito > 0 ? Math.round(((vtConManguito - vtSinManguito) / vtConManguito) * 100) : 0;
  const isFugaAdecuada = pctFuga > 20;

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-600 font-bold">
            <Wind className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
              Ventilación Mecánica & Capnografía (Manual AVENTHO)
              <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200 hidden sm:inline">
                Áreas Críticas & APH
              </span>
            </h2>
            <p className="text-xs text-slate-500">
              Protocolos de Pérez Nieto, Zamarrón, Deloya, Soriano y Sánchez Díaz (2019)
            </p>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200 overflow-x-auto">
          {[
            { id: 'programacion', label: 'Programación & ACV' },
            { id: 'capnografia', label: 'Curvas EtCO₂' },
            { id: 'monitoreo', label: 'Mecánica & DP' },
            { id: 'co2_metabolico', label: 'Ajuste CO₂ (Winter)' },
            { id: 'gases_aventho', label: 'Taller de Gases' },
            { id: 'retiro_sedacion', label: 'Destete & Sedación' },
          ].map(tab => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-2.5 py-1.5 rounded-md text-xs font-bold whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-white text-red-600 shadow-xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* VIEW 1: PROGRAMACIÓN INICIAL ACV Y VNI */}
      {activeTab === 'programacion' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Input Controls */}
            <div className="lg:col-span-5 space-y-4">
              {/* SDRA Switch & Formulas AVENTHO (Page 2) */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                    1. Estado Pulmonar del Paciente
                  </label>
                  <span className="text-[10px] font-mono text-slate-400">AVENTHO Pág. 2</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setTieneSdra(false)}
                    className={`p-2 rounded-lg text-xs font-bold text-left border transition-all ${
                      !tieneSdra
                        ? 'bg-white border-red-500 text-red-700 shadow-2xs'
                        : 'bg-slate-100 border-slate-200 text-slate-600'
                    }`}
                  >
                    <div>Sin SDRA</div>
                    <div className="text-[10px] text-slate-400 font-mono font-normal">Talla(m)² × 23/21.5</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => setTieneSdra(true)}
                    className={`p-2 rounded-lg text-xs font-bold text-left border transition-all ${
                      tieneSdra
                        ? 'bg-white border-red-500 text-red-700 shadow-2xs'
                        : 'bg-slate-100 border-slate-200 text-slate-600'
                    }`}
                  >
                    <div>Con SDRA (Grave)</div>
                    <div className="text-[10px] text-slate-400 font-mono font-normal">PBW Devine / ARDSNet</div>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setGenero('hombre')}
                    className={`py-1.5 px-3 rounded-lg text-xs font-bold border transition-all ${
                      genero === 'hombre'
                        ? 'bg-red-600 border-red-600 text-white shadow-2xs'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    Hombre
                  </button>
                  <button
                    type="button"
                    onClick={() => setGenero('mujer')}
                    className={`py-1.5 px-3 rounded-lg text-xs font-bold border transition-all ${
                      genero === 'mujer'
                        ? 'bg-red-600 border-red-600 text-white shadow-2xs'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    Mujer
                  </button>
                </div>

                <div className="flex justify-between items-center text-xs pt-1">
                  <span className="text-slate-600 font-medium">Talla del Paciente</span>
                  <span className="font-mono text-red-600 font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
                    {alturaCm} cm
                  </span>
                </div>
                <input
                  type="range"
                  min="140"
                  max="205"
                  value={alturaCm}
                  onChange={(e) => setAlturaCm(Number(e.target.value))}
                  className="w-full accent-red-600 cursor-pointer"
                />

                <div className="p-2.5 bg-white rounded-lg border border-slate-200 flex items-center justify-between">
                  <span className="text-xs text-slate-500 font-medium">
                    {tieneSdra ? 'Peso Predicho (PW - SDRA):' : 'Peso Ideal (Sin SDRA):'}
                  </span>
                  <span className="text-xl font-black font-mono text-slate-900">
                    {pesoCalculo.toFixed(1)} kg
                  </span>
                </div>
              </div>

              {/* Protection Strategy mL/kg */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
                <label className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                  2. Meta de Protección Alveolar (mL / kg)
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {[
                    { val: 4, l: '4 mL/kg', sub: 'SDRA Severo' },
                    { val: 6, l: '6 mL/kg', sub: 'Recomendado' },
                    { val: 7, l: '7 mL/kg', sub: 'Sin SDRA' },
                    { val: 8, l: '8 mL/kg', sub: 'Máx Normal' },
                  ].map(item => (
                    <button
                      key={item.val}
                      type="button"
                      onClick={() => setMlPorKg(item.val)}
                      className={`p-2 rounded-lg text-left border transition-all ${
                        mlPorKg === item.val
                          ? 'bg-red-50 border-red-500 text-red-900 font-bold shadow-2xs'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <div className="text-xs">{item.l}</div>
                      <div className="text-[9px] text-slate-400 font-normal">{item.sub}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Respiratory Rate & PEEP */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-600 font-medium">Frecuencia Respiratoria (FR)</span>
                  <span className="font-mono text-red-600 font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
                    {frProgramada} rpm
                  </span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="35"
                  value={frProgramada}
                  onChange={(e) => setFrProgramada(Number(e.target.value))}
                  className="w-full accent-red-600 cursor-pointer"
                />

                <div className="flex justify-between items-center text-xs pt-1">
                  <span className="text-slate-600 font-medium">PEEP Inicial (cmH2O)</span>
                  <span className="font-mono text-slate-800 font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
                    {peep} cmH2O
                  </span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="16"
                  value={peep}
                  onChange={(e) => setPeep(Number(e.target.value))}
                  className="w-full accent-slate-700 cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 block">
                  AVENTHO: Mantener PEEP 5 a 8 cmH2O inicial; en SDRA moderado-severo considerar PEEP 10 cmH2O (evitar &gt; 15 sin insonación de VD).
                </span>
              </div>
            </div>

            {/* Results: Recommended Prescriptions (AVENTHO Pages 6 & 10) */}
            <div className="lg:col-span-7 space-y-4">
              <div className="bg-red-50/50 border border-red-200 rounded-xl p-5 shadow-xs space-y-3">
                <span className="text-xs uppercase tracking-wider text-red-700 font-mono font-bold block">
                  Parámetros Prescritos en Modo Asisto-Controlado por Volumen (ACV)
                </span>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white p-4 rounded-xl border border-red-100 shadow-2xs">
                    <span className="text-xs text-slate-500 font-medium">Volumen Corriente (Vt)</span>
                    <div className="text-4xl font-black font-mono text-slate-900 mt-1 tabular-nums">
                      {vtRecomendado} <span className="text-base text-slate-400 font-normal">mL</span>
                    </div>
                    <span className="text-[11px] font-mono text-red-600 font-medium">
                      Calculado a {mlPorKg} mL/kg de {pesoCalculo.toFixed(1)} kg
                    </span>
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-red-100 shadow-2xs">
                    <span className="text-xs text-slate-500 font-medium">Volumen Minuto (VE)</span>
                    <div className="text-4xl font-black font-mono text-slate-900 mt-1 tabular-nums">
                      {veLitros.toFixed(1)} <span className="text-base text-slate-400 font-normal">L / min</span>
                    </div>
                    <span className="text-[11px] font-mono text-slate-500">
                      Normal: 5 a 6 L/min (ajustar para PaCO2)
                    </span>
                  </div>
                </div>

                {/* Range table */}
                <div className="bg-white p-3 rounded-lg border border-red-100 grid grid-cols-4 text-center text-xs">
                  <div>
                    <span className="text-slate-400 block font-mono text-[10px]">4 mL/kg</span>
                    <span className="font-mono font-bold text-slate-700">{vt4} mL</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block font-mono text-[10px]">6 mL/kg (Inicio)</span>
                    <span className="font-mono font-bold text-red-600">{vt6} mL</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block font-mono text-[10px]">7 mL/kg</span>
                    <span className="font-mono font-bold text-slate-700">{vt7} mL</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block font-mono text-[10px]">8 mL/kg</span>
                    <span className="font-mono font-bold text-slate-700">{vt8} mL</span>
                  </div>
                </div>
              </div>

              {/* Guía Rápida de Ajustes AVENTHO */}
              <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                  Reglas de Oro de Programación Inicial AVENTHO (Página 6)
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <strong className="text-slate-900 block mb-1">Pausa Inspiratoria (PI):</strong>
                    <p className="text-slate-600">
                      Programar <strong>0.3 segundos</strong> para monitorizar continuamente la presión meseta (Pplat) o ajustar para relación I:E 1:2 a 1:3.
                    </p>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <strong className="text-slate-900 block mb-1">Flujo Inspiratorio:</strong>
                    <p className="text-slate-600">
                      30 a 60 L/min. En <strong>Asma o EPOC agudo</strong> subir hasta <strong>100 L/min</strong> para acortar la inspiración y dar tiempo espiratorio.
                    </p>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <strong className="text-slate-900 block mb-1">Sensibilidad / Disparo:</strong>
                    <p className="text-slate-600">
                      1 a 3 L/min (por flujo) o 0.5 a 2 cmH2O (por presión). Evita auto-disparo y reduce trabajo respiratorio.
                    </p>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <strong className="text-slate-900 block mb-1">VNI con Presión Soporte:</strong>
                    <p className="text-slate-600">
                      Presión soporte (PS) necesaria para Vt 6-8 mL/kg (<strong>máximo 12 cmH2O</strong>) + CPAP 5 a 8 cmH2O.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: CAPNOGRAFÍA (EtCO2) */}
      {activeTab === 'capnografia' && <CapnographyViewer />}

      {/* VIEW 3: MONITOREO PULMONAR, DP Y METAS EN SDRA (Páginas 8-9) */}
      {activeTab === 'monitoreo' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">
                Monitoreo Pulmonar de Mecánica Respiratoria (AVENTHO Páginas 8 y 9)
              </h3>
              <p className="text-xs text-slate-500">
                Presión de distensión (Driving Pressure), Presión transaérea, Compliancia y Metas de Protección
              </p>
            </div>
            <span className="text-xs font-mono font-bold px-2.5 py-1 bg-red-50 text-red-700 rounded-full border border-red-200">
              Curva P/T en Volumen
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Pressures inputs */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                  Presiones Registradas en el Monitor
                </span>

                <div>
                  <label className="text-xs text-slate-600 block mb-1">Presión Máxima / Pico (Pmax cmH2O)</label>
                  <input
                    type="number"
                    value={pmax}
                    onChange={(e) => setPmax(Number(e.target.value))}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-mono text-slate-900"
                  />
                  <span className="text-[10px] text-slate-400">Meta AVENTHO: &lt; 35 cmH2O (ideal &lt; 31)</span>
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1">Presión Meseta / Plateau (Pplat cmH2O con pausa 0.3s)</label>
                  <input
                    type="number"
                    value={pplat}
                    onChange={(e) => setPplat(Number(e.target.value))}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-mono text-slate-900"
                  />
                  <span className="text-[10px] text-slate-400">Meta AVENTHO: &lt; 28 cmH2O (ideal &lt; 24 en SDRA)</span>
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1">PEEP Total (cmH2O)</label>
                  <input
                    type="number"
                    value={peep}
                    onChange={(e) => setPeep(Number(e.target.value))}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-mono text-slate-900"
                  />
                </div>
              </div>
            </div>

            {/* Calculations & Interpretations */}
            <div className="lg:col-span-7 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Driving Pressure */}
                <div className={`p-4 rounded-xl border ${isDrivingPressureHigh ? 'bg-red-50 border-red-300 text-red-900' : 'bg-emerald-50 border-emerald-300 text-emerald-900'}`}>
                  <span className="text-[11px] font-mono uppercase font-bold block">
                    Presión de Distensión (Driving Pressure = Pplat - PEEP)
                  </span>
                  <div className="text-3xl font-black font-mono mt-1">
                    {drivingPressure} <span className="text-base font-normal">cmH2O</span>
                  </div>
                  <p className="text-xs mt-1">
                    {isDrivingPressureHigh
                      ? '⚠️ ALERTA: > 13 cmH2O lesiona el alvéolo. Reduzca Vt, optimice PEEP o considere pronación.'
                      : '✓ Protección alveolar lograda (DP ≤ 13 cmH2O).'}
                  </p>
                </div>

                {/* Presión Transaérea */}
                <div className={`p-4 rounded-xl border ${isPresionTransaereaAlta ? 'bg-amber-50 border-amber-300 text-amber-900' : 'bg-slate-50 border-slate-200 text-slate-800'}`}>
                  <span className="text-[11px] font-mono uppercase font-bold block">
                    Presión Transaérea (Pmax - Pplat)
                  </span>
                  <div className="text-3xl font-black font-mono mt-1">
                    {presionTransaerea} <span className="text-base font-normal">cmH2O</span>
                  </div>
                  <p className="text-xs mt-1">
                    {isPresionTransaereaAlta
                      ? '⚠️ ALERTA: > 3 cmH2O. Alta resistencia de vía aérea (broncoespasmo, secreciones, acodamiento).'
                      : '✓ Normal (< 2.5 a 3 cmH2O).'}
                  </p>
                </div>
              </div>

              {/* Compliance Estática */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-slate-800 block">
                    Distensibilidad Estática del Sistema Respiratorio (Crs = Vt / DP):
                  </span>
                  <span className="text-[11px] text-slate-500 font-mono">
                    Valor normal en áreas críticas: 70 a 100 mL/cmH2O
                  </span>
                </div>
                <div className="text-2xl font-black font-mono text-slate-900">
                  {cstat.toFixed(1)} <span className="text-xs text-slate-400 font-normal">mL/cmH2O</span>
                </div>
              </div>

              {/* Metas Oficiales de Protección Pulmonar en SDRA (Página 9) */}
              <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-2">
                <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
                  Metas Ventilatorias de Protección Pulmonar en SDRA (AVENTHO)
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
                  <div className="p-2 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-slate-400 block text-[10px]">P. Máxima</span>
                    <strong className="text-slate-800 font-mono">&lt; 35 (ideal &lt; 31)</strong>
                  </div>
                  <div className="p-2 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-slate-400 block text-[10px]">P. Meseta</span>
                    <strong className="text-slate-800 font-mono">&lt; 28 (ideal &lt; 24)</strong>
                  </div>
                  <div className="p-2 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-slate-400 block text-[10px]">Driving Pressure</span>
                    <strong className="text-red-600 font-mono">&lt; 14 (ideal &lt; 13)</strong>
                  </div>
                  <div className="p-2 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-slate-400 block text-[10px]">Auto-PEEP</span>
                    <strong className="text-slate-800 font-mono">&lt; 1 cmH2O</strong>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 4: CORRECCIÓN DE CO2 EN ACIDOSIS O ALCALOSIS METABÓLICA (Página 7) */}
      {activeTab === 'co2_metabolico' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">
                Programar el CO₂ en Acidosis o Alcalosis Metabólica (Fórmula de Winter & AVENTHO)
              </h3>
              <p className="text-xs text-slate-500">
                Ajuste del volumen minuto para compensación respiratoria idónea según el nivel de bicarbonato (HCO₃⁻)
              </p>
            </div>
            <span className="text-xs font-mono font-bold px-2.5 py-1 bg-red-50 text-red-700 rounded-full border border-red-200">
              AVENTHO Pág. 7
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                  Trastorno Metabólico Base
                </span>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setTrastornoMetabolico('acidosis')}
                    className={`p-2 rounded-lg text-xs font-bold border transition-all ${
                      trastornoMetabolico === 'acidosis'
                        ? 'bg-red-600 border-red-600 text-white shadow-2xs'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    Acidosis Metabólica (Winter)
                  </button>
                  <button
                    type="button"
                    onClick={() => setTrastornoMetabolico('alcalosis')}
                    className={`p-2 rounded-lg text-xs font-bold border transition-all ${
                      trastornoMetabolico === 'alcalosis'
                        ? 'bg-red-600 border-red-600 text-white shadow-2xs'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    Alcalosis Metabólica
                  </button>
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1">Bicarbonato Sérico (HCO3 mEq/L)</label>
                  <input
                    type="number"
                    value={hco3}
                    onChange={(e) => setHco3(Number(e.target.value))}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1">PaCO2 Actual de Gasometría (mmHg)</label>
                  <input
                    type="number"
                    value={paco2Actual}
                    onChange={(e) => setPaco2Actual(Number(e.target.value))}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-600 block mb-1">Frecuencia Respiratoria Actual (FR rpm)</label>
                  <input
                    type="number"
                    value={frActual}
                    onChange={(e) => setFrActual(Number(e.target.value))}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-mono text-slate-900"
                  />
                </div>
              </div>
            </div>

            {/* Calculations Output */}
            <div className="lg:col-span-7 space-y-4">
              <div className="bg-red-50/50 border border-red-200 rounded-xl p-5 shadow-xs space-y-3">
                <span className="text-xs uppercase tracking-wider text-red-700 font-mono font-bold block">
                  PaCO₂ Esperado (CO₂e)
                </span>
                <div className="text-4xl font-black font-mono text-slate-900">
                  {co2Esperado} <span className="text-base text-slate-500 font-normal">± 2 mmHg</span>
                </div>
                <p className="text-xs text-slate-600 font-mono">
                  {trastornoMetabolico === 'acidosis'
                    ? `Fórmula de Winter: (${hco3} × 1.5) + 8 = ${co2Esperado} mmHg`
                    : `Fórmula Alcalosis: (${hco3} × 0.7) + 21 = ${co2Esperado} mmHg`}
                </p>
              </div>

              {/* Adjustments */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
                  <span className="text-xs font-bold text-red-600 uppercase tracking-wider block">
                    Opción A: Nueva FR Recomendada
                  </span>
                  <div className="text-3xl font-black font-mono text-slate-900 mt-1">
                    {frNueva} <span className="text-sm text-slate-500 font-normal">rpm</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono block mt-1">
                    Fórmula: (FR act {frActual} × PaCO₂ act {paco2Actual}) / CO₂e {co2Esperado}
                  </span>
                </div>

                <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
                  <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                    Opción B: Nuevo Vt (si FR en límite)
                  </span>
                  <div className="text-3xl font-black font-mono text-slate-900 mt-1">
                    {vtNuevo} <span className="text-sm text-slate-500 font-normal">mL</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono block mt-1">
                    Mantener siempre dentro de rango de protección (4-8 mL/kg)
                  </span>
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600">
                <strong>Nota AVENTHO:</strong> Se recomienda ajustar inicialmente la Frecuencia Respiratoria (FR). De no alcanzarse el objetivo por taquipnea extrema, ajustar el Volumen Corriente cuidando estrictamente no superar 8 mL/kg de peso ideal.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 5: TALLER DE GASES Y ÁCIDO-BASE (Páginas 12 y 16-17) */}
      {activeTab === 'gases_aventho' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">
                Taller de Gases y Regla de Interpretación Ácido-Base AVENTHO
              </h3>
              <p className="text-xs text-slate-500">
                Sánchez Díaz, Salvador et al. (Med Crit 2018) & Fórmulas de Oxigenación
              </p>
            </div>
            <span className="text-xs font-mono font-bold px-2.5 py-1 bg-red-50 text-red-700 rounded-full border border-red-200">
              Páginas 12 y 16-17
            </span>
          </div>

          {/* Age calculator for expected PaO2 */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
                  PaO₂ Arterial Esperada según Edad
                </span>
                <span className="text-[11px] text-slate-500 font-mono">
                  Fórmula: PaO₂ = 104.2 - (0.27 × edad en años)
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-600">Edad: <strong>{edadAnos} años</strong></span>
                <input
                  type="range"
                  min="18"
                  max="95"
                  value={edadAnos}
                  onChange={(e) => setEdadAnos(Number(e.target.value))}
                  className="w-32 accent-red-600 cursor-pointer"
                />
                <span className="text-lg font-black font-mono text-red-600 bg-white px-2.5 py-0.5 rounded border border-slate-200">
                  {pao2EsperadaEdad} mmHg
                </span>
              </div>
            </div>
          </div>

          {/* Acid-Base 6 Disorders Table */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
              Tabla de Trastornos Ácido-Base AVENTHO
            </span>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-700 uppercase font-mono text-[10px]">
                    <th className="p-3">Trastorno Primario</th>
                    <th className="p-3 text-center">pH</th>
                    <th className="p-3 text-center">PCO₂</th>
                    <th className="p-3 text-center">Exceso Base (EB)</th>
                    <th className="p-3">Significado Clínico</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono text-xs">
                  {ACIDO_BASE_AVENTHO.map((t, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/80">
                      <td className="p-3 font-bold text-slate-900">{t.trastorno}</td>
                      <td className="p-3 text-center text-base">{t.ph}</td>
                      <td className="p-3 text-center text-base">{t.pco2}</td>
                      <td className="p-3 text-center font-bold">{t.eb}</td>
                      <td className="p-3 text-slate-600 font-sans">{t.interpretacion}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="text-[11px] font-mono text-slate-500 pt-1">
              Valores normales a nivel del mar: pH 7.35 - 7.45 (7.4), PCO₂ 35 - 45 mmHg, HCO₃⁻ 22 - 26 mEq/L.
            </div>
          </div>
        </div>
      )}

      {/* VIEW 6: RETIRO / DESTETE (WEANING) & ESCALA DE SEDACIÓN (Páginas 13-15) */}
      {activeTab === 'retiro_sedacion' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">
                Criterios de Retiro Ventilatorio, Índice de Tobin & Escala de Sedación AVENTHO
              </h3>
              <p className="text-xs text-slate-500">
                Páginas 13, 14 y 15 del Manual AVENTHO para Áreas Críticas
              </p>
            </div>
            <span className="text-xs font-mono font-bold px-2.5 py-1 bg-red-50 text-red-700 rounded-full border border-red-200">
              Weaning Protocol
            </span>
          </div>

          {/* Tobin Calculator (RSBI) */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Índice de Respiraciones Rápidas Superficiales (Tobin / RSBI = FR / Vt en Litros)
              </span>
              <span className={`text-xs font-bold px-2 py-0.5 rounded-full border ${isTobinExitoso ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-700 border-red-200'}`}>
                {isTobinExitoso ? '✓ Éxito al Retiro (< 105)' : '⚠️ Fracaso al Retiro (≥ 105)'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="text-xs text-slate-600 block mb-1">FR Espontánea en Prueba de Tubo en T (rpm)</label>
                <input
                  type="number"
                  value={frEspontanea}
                  onChange={(e) => setFrEspontanea(Number(e.target.value))}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-mono text-slate-900"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1">Vt Espontáneo Exhalado (Litros)</label>
                <input
                  type="number"
                  step="0.01"
                  value={vtExhaladoLitros}
                  onChange={(e) => setVtExhaladoLitros(Number(e.target.value))}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-mono text-slate-900"
                />
                <span className="text-[10px] text-slate-400 font-mono">Ej: 350 mL = 0.35 L</span>
              </div>

              <div className="bg-white p-3 rounded-lg border border-slate-200 flex flex-col justify-center text-center">
                <span className="text-xs text-slate-500 font-mono">Índice RSBI / Tobin:</span>
                <span className="text-3xl font-black font-mono text-slate-900 mt-0.5">
                  {tobinIndex}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">Meta: &lt; 105 resp/min/L</span>
              </div>
            </div>
          </div>

          {/* Prueba de Fuga del Manguito (Cuff Leak Test) */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Prueba de Fuga del Manguito para Prevenir Estridor Postextubación
              </span>
              <span className={`text-xs font-bold px-2 py-0.5 rounded-full border ${isFugaAdecuada ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-700 border-red-200'}`}>
                {isFugaAdecuada ? `✓ Fuga ${pctFuga}% (> 20%: Baja probabilidad de edema)` : `⚠️ Fuga ${pctFuga}% (≤ 20%: Riesgo de laringoespasmo/edema)`}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-slate-600 block mb-1">Vt con Balón Inflado (mL)</label>
                <input
                  type="number"
                  value={vtConManguito}
                  onChange={(e) => setVtConManguito(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-sm font-mono text-slate-900"
                />
              </div>
              <div>
                <label className="text-xs text-slate-600 block mb-1">Vt con Balón Desinflado (mL)</label>
                <input
                  type="number"
                  value={vtSinManguito}
                  onChange={(e) => setVtSinManguito(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-sm font-mono text-slate-900"
                />
              </div>
            </div>
          </div>

          {/* Escala AVENTHO de Sedación (Página 13) */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
              Escala AVENTHO para Ansiolisis, Sedación y Anestesia en el Paciente Crítico
            </span>
            <div className="space-y-2">
              {ESCALA_SEDACION_AVENTHO.map(s => (
                <div key={s.grado} className="bg-slate-50 border border-slate-200 p-3 rounded-xl flex items-start gap-3 text-xs">
                  <span className="w-6 h-6 rounded-md bg-red-600 text-white font-bold flex items-center justify-center shrink-0 text-xs">
                    G{s.grado}
                  </span>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <strong className="text-slate-900">{s.nombre}</strong>
                      <span className="text-[11px] font-mono text-red-600">{s.indicacionClinica}</span>
                    </div>
                    <p className="text-slate-600 mt-0.5 leading-snug">{s.descripcion}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
