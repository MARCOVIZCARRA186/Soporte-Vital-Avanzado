import React, { useState } from 'react';
import { Syringe, AlertTriangle, Check, RefreshCw, Scale, Pill } from 'lucide-react';
import { PHARMACOLOGY_DATABASE } from '../../data/pharmacologyData';

export default function DrugDosageCalc() {
  const [selectedDrugId, setSelectedDrugId] = useState<string>('epinefrina');
  const [pesoKg, setPesoKg] = useState<number>(70);
  const [indicacionIdx, setIndicacionIdx] = useState<number>(0);
  const [dosisPersonalizada, setDosisPersonalizada] = useState<number | null>(null);
  const [concentracionMgMl, setConcentracionMgMl] = useState<number>(1);

  const selectedDrug = PHARMACOLOGY_DATABASE.find(d => d.id === selectedDrugId) || PHARMACOLOGY_DATABASE[0];

  // Presets from drug or default fallback
  const presets = selectedDrug.dosisPresets && selectedDrug.dosisPresets.length > 0 
    ? selectedDrug.dosisPresets 
    : [
        { 
          label: selectedDrug.dosisPorDefecto?.etiqueta || 'Dosis Estándar', 
          doseVal: selectedDrug.dosisPorDefecto?.valor || selectedDrug.dosis.formulaMgKg || 1, 
          unit: selectedDrug.dosisPorDefecto?.tipo || 'mg/kg' 
        }
      ];

  const activePreset = presets[indicacionIdx] || presets[0];

  // Calculate dose
  const currentDosePerKg = dosisPersonalizada !== null ? dosisPersonalizada : activePreset.doseVal;
  
  let totalDoseMg = 0;
  let totalDoseDisplay = '';

  if (activePreset.unit === 'mg_fijo') {
    totalDoseMg = currentDosePerKg;
    totalDoseDisplay = `${totalDoseMg} mg`;
  } else if (activePreset.unit === 'mcg/kg') {
    const totalMcg = currentDosePerKg * pesoKg;
    totalDoseMg = totalMcg / 1000;
    totalDoseDisplay = `${totalMcg.toFixed(0)} mcg (${totalDoseMg.toFixed(3)} mg)`;
  } else {
    // mg/kg
    totalDoseMg = currentDosePerKg * pesoKg;
    totalDoseDisplay = `${totalDoseMg.toFixed(2)} mg`;
  }

  // Calculate volume in mL
  const effectiveMgPerMl = concentracionMgMl > 0 ? concentracionMgMl : selectedDrug.mgPorMl;
  const volumeMl = effectiveMgPerMl > 0 ? totalDoseMg / effectiveMgPerMl : 0;

  const handleSelectDrug = (drugId: string) => {
    setSelectedDrugId(drugId);
    setIndicacionIdx(0);
    setDosisPersonalizada(null);
    const drug = PHARMACOLOGY_DATABASE.find(d => d.id === drugId);
    if (drug) {
      setConcentracionMgMl(drug.mgPorMl);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-2 mb-5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-600 font-bold">
              <Syringe className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">Calculador de Dosis Prehospitalaria (42 Fármacos)</h2>
              <p className="text-xs text-slate-500">Cálculo de dosis por peso, concentración y volumen exacto en jeringa (mL)</p>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-400">Cruz Roja Mexicana / Internacional</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Drug Selection and Patient Weight */}
          <div className="lg:col-span-5 space-y-4">
            <div>
              <label className="block text-xs uppercase tracking-wider text-slate-500 mb-1.5 font-semibold">
                1. Seleccionar Fármaco ({PHARMACOLOGY_DATABASE.length} disponibles)
              </label>
              <select
                value={selectedDrugId}
                onChange={(e) => handleSelectDrug(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-900 font-semibold focus:border-red-500 focus:outline-none focus:bg-white transition-colors"
              >
                {PHARMACOLOGY_DATABASE.map(drug => (
                  <option key={drug.id} value={drug.id}>
                    {drug.nombre} ({drug.presentacion})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-600 font-medium">Peso del Paciente</span>
                <span className="font-mono text-red-600 font-bold">{pesoKg} kg</span>
              </div>
              <input
                type="range"
                min="3"
                max="140"
                value={pesoKg}
                onChange={(e) => setPesoKg(Number(e.target.value))}
                className="w-full accent-red-600 cursor-pointer"
              />
              <div className="flex gap-1.5 mt-2">
                {[10, 20, 50, 70, 85, 100].map(w => (
                  <button
                    key={w}
                    type="button"
                    onClick={() => setPesoKg(w)}
                    className={`text-xs py-1 px-2.5 rounded-md font-mono ${
                      pesoKg === w ? 'bg-red-600 text-white font-bold' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {w}kg
                  </button>
                ))}
              </div>
            </div>

            {/* Presets */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-slate-500 mb-1.5 font-semibold">
                2. Indicación / Esquema Clínico
              </label>
              <div className="space-y-1.5">
                {presets.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setIndicacionIdx(idx);
                      setDosisPersonalizada(null);
                    }}
                    className={`w-full text-left py-2 px-3 rounded-lg text-xs font-medium flex items-center justify-between transition-colors ${
                      indicacionIdx === idx && dosisPersonalizada === null
                        ? 'bg-red-50 border border-red-300 text-red-800'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>{preset.label}</span>
                    {indicacionIdx === idx && dosisPersonalizada === null && <Check className="w-3.5 h-3.5 text-red-600" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Manual Concentration check */}
            <div className="pt-2 bg-slate-50 p-3 rounded-lg border border-slate-200">
              <label className="block text-[11px] text-slate-600 mb-1 font-medium">Concentración de la ampolla / vial (mg/mL)</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={concentracionMgMl}
                  onChange={(e) => setConcentracionMgMl(Number(e.target.value))}
                  className="bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-900 w-28 focus:border-red-500 focus:outline-none"
                />
                <span className="text-xs text-slate-500">mg/mL</span>
                <button
                  type="button"
                  onClick={() => setConcentracionMgMl(selectedDrug.mgPorMl)}
                  title="Restablecer concentración de ampolla estándar"
                  className="p-1 px-2 bg-white hover:bg-slate-100 border border-slate-200 text-slate-600 rounded text-xs flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span className="text-[10px]">Estándar ({selectedDrug.mgPorMl} mg/mL)</span>
                </button>
              </div>
            </div>
          </div>

          {/* Results Hero */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-4">
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-inner">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-red-600 font-mono font-bold">
                    Resultado Clínico para {pesoKg} kg:
                  </span>
                  <h3 className="text-lg font-bold text-slate-900 mt-0.5">{selectedDrug.nombre}</h3>
                  <p className="text-xs text-slate-500">{activePreset.label}</p>
                </div>
                <div className="flex flex-wrap gap-1">
                  {selectedDrug.viasAdministracion.map(via => (
                    <span key={via} className="text-[11px] font-mono px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-700">
                      {via}
                    </span>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-5 pt-4 border-t border-slate-200">
                <div className="bg-white p-3.5 rounded-lg border border-slate-200">
                  <div className="text-xs text-slate-500 font-medium">Dosis total calculada:</div>
                  <div className="text-2xl font-black font-mono text-slate-900 mt-1 tabular-nums">
                    {totalDoseDisplay}
                  </div>
                </div>

                <div className="bg-red-50 p-3.5 rounded-lg border border-red-200">
                  <div className="text-xs text-red-700 font-semibold">Volumen exacto a cargar en jeringa:</div>
                  <div className="text-3xl font-black font-mono text-red-600 mt-1 tabular-nums flex items-baseline gap-1">
                    {volumeMl.toFixed(2)} <span className="text-sm text-red-500 font-normal">mL</span>
                  </div>
                </div>
              </div>

              {selectedDrug.dosis.dilucionSugerida && (
                <div className="mt-4 p-3 bg-white rounded-lg text-xs text-slate-700 border border-slate-200">
                  <span className="font-semibold text-red-600">Dilución recomendada: </span>
                  {selectedDrug.dosis.dilucionSugerida}
                </div>
              )}
            </div>

            {/* Drug Pearls & Warnings */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-2 text-xs">
              <div className="flex items-center gap-1.5 text-amber-700 font-semibold">
                <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Punto importante de la administración:</span>
              </div>
              <p className="text-slate-600 leading-relaxed">
                {selectedDrug.puntosImportantes && selectedDrug.puntosImportantes.length > 0 
                  ? selectedDrug.puntosImportantes[0] 
                  : selectedDrug.flashcard.puntosClave[0]}
              </p>
              <div className="pt-2 text-slate-500 border-t border-slate-100 flex items-center justify-between">
                <span>Riesgo en Embarazo: <strong className="text-slate-700">Categoría FDA {selectedDrug.riesgoEmbarazo}</strong></span>
                <span>Antídoto/Sobredosis: <strong className="text-slate-700">{selectedDrug.txSobredosis.substring(0, 35)}...</strong></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
