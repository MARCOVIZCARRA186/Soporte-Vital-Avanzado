import React, { useState } from 'react';
import { Activity, AlertTriangle, CheckCircle2, HelpCircle, Wind, Zap } from 'lucide-react';

export interface CapnographyPattern {
  id: string;
  nombre: string;
  patron: string;
  etco2Rango: string;
  etco2ValorNum: number;
  frecuencia: string;
  descripcion: string;
  causasComunes: string[];
  conductaInmediata: string[];
  svgPath: string;
  fasesColor: string;
}

export const CAPNOGRAPHY_PATTERNS: CapnographyPattern[] = [
  {
    id: 'normal',
    nombre: 'Capnograma Normal (Onda Cuadrada)',
    patron: 'Onda rectangular simétrica de 4 fases con meseta alveolar horizontal y ángulo alfa/beta conservados.',
    etco2Rango: '35 - 45 mmHg',
    etco2ValorNum: 38,
    frecuencia: '12 - 16 rpm',
    descripcion: 'Indica ventilación alveolar adecuada, perfusión pulmonar normal y colocación intratraqueal inequívoca del tubo endotraqueal. Fase I (espacio muerto anatómico a 0), Fase II (ascenso rápido por mezcla gas espacio muerto/alveolar), Fase III (meseta alveolar de CO2 puro) y Fase IV (descenso inspiratorio brusco a 0).',
    causasComunes: [
      'Paciente intubado o con supraglótico con ventilación y gasto cardíaco conservados',
      'Ventilación mecánica protectora normocápnica'
    ],
    conductaInmediata: [
      'Mantener parámetros ventilatorios programados (Vt 6-8 mL/kg PBW, FR 12-16 rpm)',
      'Monitorizar continuamente: cualquier pérdida brusca es emergencia crítica'
    ],
    svgPath: 'M 0 70 L 40 70 L 45 68 L 55 25 L 120 22 L 122 70 L 160 70 L 165 68 L 175 25 L 240 22 L 242 70 L 280 70 L 285 68 L 295 25 L 360 22 L 362 70 L 400 70',
    fasesColor: '#10b981'
  },
  {
    id: 'broncoespasmo',
    nombre: 'Broncoespasmo / Obstrucción (Aleta de Tiburón)',
    patron: 'Pendiente ascendente prolongada en la fase III, pérdida del ángulo alfa (patrón en "aleta de tiburón").',
    etco2Rango: '35 - 60 mmHg (variable según retención)',
    etco2ValorNum: 48,
    frecuencia: '18 - 24 rpm',
    descripcion: 'El vaciamiento alveolar se encuentra retardado e irregular debido al aumento de resistencia en la vía aérea distal. Típico de asma severa, exacerbación de EPOC o acodamiento/secreciones en el tubo endotraqueal.',
    causasComunes: [
      'Crisis asmática severa o estatus asmático',
      'Exacerbación aguda de EPOC con broncoespasmo',
      'Tubo endotraqueal parcialmente ocluido por moco o acodado',
      'Reacción alérgica / anafilaxia con compromiso bronquial'
    ],
    conductaInmediata: [
      'Administrar broncodilatadores inmediatamente (Salbutamol + Ipratropio nebulizados o MDI en circuito)',
      'Administrar Sulfato de Magnesio 2 g IV en infusión rápida y Corticoides (Dexametasona / Hidrocortisona)',
      'En ventilador: alargar tiempo espiratorio (relación I:E 1:3 o 1:4), reducir FR para evitar atrapamiento aéreo (auto-PEEP)'
    ],
    svgPath: 'M 0 70 L 30 70 L 45 55 L 75 35 L 115 22 L 120 70 L 150 70 L 165 55 L 195 35 L 235 22 L 240 70 L 270 70 L 285 55 L 315 35 L 355 22 L 360 70 L 400 70',
    fasesColor: '#f59e0b'
  },
  {
    id: 'hipoventilacion',
    nombre: 'Hipoventilación Alveolar (EtCO2 Elevado)',
    patron: 'Ondas de morfología cuadrada normal pero con meseta progresivamente más alta (> 45 - 55 mmHg).',
    etco2Rango: '> 45 - 60 mmHg',
    etco2ValorNum: 54,
    frecuencia: '6 - 10 rpm (bradipnea)',
    descripcion: 'Volumen minuto insuficiente para la producción metabólica de CO2, acumulando ácido carbónico en sangre (acidosis respiratoria). Común en sobredosis por opioides, benzodiacepinas o programación insuficiente del respirador.',
    causasComunes: [
      'Depresión del centro respiratorio por opioides (heroína, fentanilo, morfina)',
      'Sedación profunda o intoxicación etílica / sedantes',
      'Volumen corriente (Vt) o frecuencia respiratoria (FR) programados demasiado bajos en el ventilador',
      'Fatiga extrema de la musculatura respiratoria'
    ],
    conductaInmediata: [
      'Si se sospecha opioide: administrar Naloxona 0.4 - 2 mg IV/IN',
      'En paciente bajo ventilación mecánica: aumentar el volumen minuto (aumentar FR en 2-4 rpm o aumentar Vt respetando 8 mL/kg)',
      'Objetivo: normalizar EtCO2 a 35-45 mmHg (precaución en EPOC retenedor crónico: no hiperventilar bruscamente)'
    ],
    svgPath: 'M 0 70 L 30 70 L 35 68 L 45 10 L 125 8 L 128 70 L 160 70 L 165 68 L 175 10 L 255 8 L 258 70 L 290 70 L 295 68 L 305 10 L 385 8 L 388 70 L 400 70',
    fasesColor: '#ef4444'
  },
  {
    id: 'hiperventilacion',
    nombre: 'Hiperventilación / Lavado de CO2 (EtCO2 Bajo)',
    patron: 'Ondas de morfología cuadrada pero con baja amplitud y meseta inferior a 30 mmHg.',
    etco2Rango: '< 30 - 20 mmHg',
    etco2ValorNum: 24,
    frecuencia: '24 - 35 rpm (taquipnea)',
    descripcion: 'Volumen minuto excesivo que lava rápidamente el CO2 alveolar hacia el exterior, causando alcalosis respiratoria y vasoconstricción cerebral profunda (isquemia cerebral en TEC).',
    causasComunes: [
      'Hiperventilación iatrogénica por exceso de embolsado con BVM por el rescatador (error prehospitalario frecuente)',
      'Ataque de pánico / crisis de ansiedad severa',
      'Compensación respiratoria de acidosis metabólica grave (cetoacidosis diabética Kussmaul, shock)',
      'Embolia pulmonar masiva o bajo gasto cardíaco grave'
    ],
    conductaInmediata: [
      '¡ALERTAR AL OPERADOR DE LA BVM!: reducir la frecuencia de ventilación a 1 ventilación cada 6 segundos (10 rpm)',
      'En TEC / TCE grave: PROHIBIDA la hiperventilación profiláctica (la vasoconstricción cerebral causa hipoperfusión isquémica secundaria severa)',
      'Ajustar el respirador disminuyendo FR o Vt para llevar el EtCO2 a 35-40 mmHg'
    ],
    svgPath: 'M 0 70 L 25 70 L 30 68 L 38 48 L 75 47 L 78 70 L 105 70 L 110 68 L 118 48 L 155 47 L 158 70 L 185 70 L 190 68 L 198 48 L 235 47 L 238 70 L 265 70 L 270 68 L 278 48 L 315 47 L 318 70 L 345 70 L 350 68 L 358 48 L 395 47 L 400 70',
    fasesColor: '#3b82f6'
  },
  {
    id: 'curare',
    nombre: 'Hendidura de Curare (Curare Cleft)',
    patron: 'Depresión o muesca negativa repentina en el tercio final de la meseta alveolar (fase III).',
    etco2Rango: '35 - 45 mmHg',
    etco2ValorNum: 39,
    frecuencia: '14 rpm',
    descripcion: 'Aparece cuando el efecto del bloqueante neuromuscular (Rocuronio / Succinilcolina) comienza a desvanecerse y el diafragma del paciente realiza un esfuerzo inspiratorio espontáneo antes de que termine el ciclo del ventilador.',
    causasComunes: [
      'Agotamiento o descenso de la concentración plasmática del relajante muscular en paciente intubado',
      'El paciente está "peleando" o asincrónico con el ventilador mecánico',
      'Analgesia o sedación superficial insatisfactoria'
    ],
    conductaInmediata: [
      'Reevaluar profundidad anestésica: administrar bolo adicional de sedante/analgésico (Fentanilo / Midazolam / Ketamina)',
      'Si se requiere parálisis estricta (ej. en SDRA o trauma severo): administrar dosis de mantenimiento de Rocuronio (0.15 - 0.2 mg/kg IV)',
      'Verificar sincronía paciente-ventilador'
    ],
    svgPath: 'M 0 70 L 35 70 L 40 68 L 48 25 L 85 24 L 92 48 L 100 24 L 115 24 L 118 70 L 155 70 L 160 68 L 168 25 L 205 24 L 212 48 L 220 24 L 235 24 L 238 70 L 275 70 L 280 68 L 288 25 L 325 24 L 332 48 L 340 24 L 355 24 L 358 70 L 400 70',
    fasesColor: '#8b5cf6'
  },
  {
    id: 'rosc',
    nombre: 'Retorno de Circulación Espontánea (ROSC en RCP)',
    patron: 'Salto abrupto y sostenido de EtCO2 de niveles bajos (10-15 mmHg) a más de 35 - 45 mmHg durante las compresiones.',
    etco2Rango: 'Salto a > 35 - 50 mmHg',
    etco2ValorNum: 42,
    frecuencia: '10 rpm (con RCP)',
    descripcion: 'Es el marcador clínico MÁS PRECOZ y sensible de que el corazón del paciente ha vuelto a bombear espontáneamente sangre a través de los lechos capilares pulmonares, liberando masivamente el CO2 acumulado en los tejidos hacia los alvéolos.',
    causasComunes: [
      'Reanudación del latido cardíaco eficaz espontáneo (ROSC) tras desfibrilación o fármacos en paro cardíaco',
      'Mejora drástica de la perfusión pulmonar antes de que el rescatador palpe el pulso carotídeo'
    ],
    conductaInmediata: [
      '¡COMPROBAR INMEDIATAMENTE EL PULSO CAROTÍDEO! Si hay pulso central palpable, detener compresiones',
      'Iniciar protocolo inmediato de CUIDADOS POST-PARO (ROSC): optimizar PAM ≥ 65, SpO2 92-98%, ECG de 12 derivaciones',
      'Evitar la hiperventilación en el post-paro (la hiperventilación colapsa el retorno venoso coronario y cerebral)'
    ],
    svgPath: 'M 0 70 L 25 70 L 28 68 L 35 55 L 55 54 L 58 70 L 85 70 L 88 68 L 95 54 L 115 53 L 118 70 L 145 70 L 150 68 L 160 18 L 230 15 L 233 70 L 265 70 L 270 68 L 280 18 L 350 15 L 353 70 L 400 70',
    fasesColor: '#059669'
  },
  {
    id: 'perdida_subita',
    nombre: 'Pérdida Súbita de Onda a Cero (Emergencia Crítica)',
    patron: 'La línea del trazado cae abruptamente a 0 mmHg y se mantiene plana (sin onda espiratoria).',
    etco2Rango: '0 mmHg',
    etco2ValorNum: 0,
    frecuencia: '0 rpm efectivas',
    descripcion: 'Pérdida absoluta de intercambio gaseoso o flujo exhalado hacia el sensor de capnografía. Es una emergencia médica que exige acción inmediata en los primeros 10 segundos.',
    causasComunes: [
      'Extubación esofágica accidental o desplazamiento del tubo durante el traslado en camilla',
      'Desconexión del tubo del circuito o del respirador',
      'Neumotórax a tensión masivo con colapso cardiovascular agudo',
      'Paro cardíaco súbito con parada circulatoria total',
      'Obstrucción completa del tubo endotraqueal por coágulo o secreción masiva'
    ],
    conductaInmediata: [
      'Regla DOPE inmediata: Desplazamiento (verificar tubo en cuerdas/incisivos), Obstrucción (aspirar con Yankauer), Pneumotórax (auscultar campos pulmonares; descompresión con aguja/catéter 14G si silente con shock), Equipo (desconectar ventilador y ventilar manualmente con BVM)',
      'Si el tubo se desplazó al esófago: RETIRAR INMEDIATAMENTE y reintubar o colocar supraglótico i-gel'
    ],
    svgPath: 'M 0 70 L 30 70 L 35 68 L 45 25 L 115 22 L 118 70 L 150 70 L 400 70',
    fasesColor: '#dc2626'
  },
  {
    id: 'obstruccion_tubo',
    nombre: 'Obstrucción Parcial / Secreciones en Tubo',
    patron: 'Fase II y III irregulares, meseta oscilante o con jorobas irregulares sin retorno limpio a la línea base.',
    etco2Rango: 'Variable (30 - 50 mmHg)',
    etco2ValorNum: 36,
    frecuencia: '16 rpm',
    descripcion: 'El flujo espiratorio choca contra un obstáculo mecánico (secreciones mucosas espesas, sangre o condensación en la trampa de agua del capnógrafo).',
    causasComunes: [
      'Acumulación de moco en el interior del tubo endotraqueal',
      'Vómito o sangre aspirada en la luz traqueal',
      'Línea de muestreo del capnógrafo con condensación de agua'
    ],
    conductaInmediata: [
      'Aspirar inmediatamente el tubo con sonda de aspiración cerrada o estéril',
      'Revisar la trampa de agua del sensor y purgar la línea de muestreo',
      'Verificar que el paciente no esté mordiendo el tubo (colocar cánula de Guedel como bloqueador de mordida)'
    ],
    svgPath: 'M 0 70 L 30 70 L 38 60 L 50 35 L 70 28 L 85 36 L 105 25 L 115 28 L 118 70 L 150 70 L 158 60 L 170 35 L 190 28 L 205 36 L 225 25 L 235 28 L 238 70 L 270 70 L 278 60 L 290 35 L 310 28 L 325 36 L 345 25 L 355 28 L 358 70 L 400 70',
    fasesColor: '#d97706'
  }
];

export default function CapnographyViewer() {
  const [selectedPatternId, setSelectedPatternId] = useState<string>('normal');

  const currentPattern = CAPNOGRAPHY_PATTERNS.find(p => p.id === selectedPatternId) || CAPNOGRAPHY_PATTERNS[0];

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-600 font-bold">
            <Activity className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Curvas de Capnografía y Monitorización de EtCO₂
            </h3>
            <p className="text-xs text-slate-500">
              Patrones de forma de onda, fases fisiológicas, causas clínicas y conducta inmediata
            </p>
          </div>
        </div>
        <span className="text-[11px] font-mono font-semibold px-2.5 py-1 bg-red-50 text-red-700 rounded-full border border-red-200 self-start sm:self-auto">
          Estándar Cruz Roja APH
        </span>
      </div>

      {/* Grid of pattern selectors */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {CAPNOGRAPHY_PATTERNS.map((p) => {
          const isSelected = p.id === selectedPatternId;
          return (
            <button
              key={p.id}
              type="button"
              onClick={() => setSelectedPatternId(p.id)}
              className={`p-2.5 rounded-lg text-left transition-all border ${
                isSelected
                  ? 'bg-red-50/80 border-red-400 text-slate-900 shadow-xs'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-red-600 ring-2 ring-red-200' : 'bg-slate-300'}`} />
                <span className="text-[10px] font-mono font-bold text-slate-500">{p.etco2ValorNum} mmHg</span>
              </div>
              <span className={`text-xs font-bold line-clamp-1 ${isSelected ? 'text-red-700' : 'text-slate-800'}`}>
                {p.nombre.split('(')[0]}
              </span>
            </button>
          );
        })}
      </div>

      {/* Real-time Capnograph Screen Simulation */}
      <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 shadow-md">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-slate-300 font-bold tracking-wider">CAPNÓGRAFO CONTINUO DE ONDA</span>
            <span className="text-slate-500 hidden sm:inline">| Sensor Mainstream/Sidestream</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>FR: <strong className="text-white font-bold">{currentPattern.frecuencia}</strong></span>
            <span>Rango: <strong className="text-teal-400 font-bold">{currentPattern.etco2Rango}</strong></span>
          </div>
        </div>

        {/* Oscilloscope Grid Display */}
        <div className="relative h-32 w-full bg-slate-950 rounded-lg overflow-hidden border border-slate-900 flex items-center">
          {/* Subtle grid lines */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b0a_1px,transparent_1px),linear-gradient(to_bottom,#1e293b0a_1px,transparent_1px)] bg-[size:20px_20px]" />
          
          {/* 40 mmHg Reference Line */}
          <div className="absolute top-[28%] left-0 right-0 border-b border-dashed border-slate-800 flex justify-end pr-2">
            <span className="text-[10px] font-mono text-slate-600">40 mmHg</span>
          </div>
          {/* Baseline */}
          <div className="absolute bottom-3 left-0 right-0 border-b border-slate-800 flex justify-end pr-2">
            <span className="text-[10px] font-mono text-slate-600">0 mmHg</span>
          </div>

          {/* SVG Waveform */}
          <svg className="w-full h-full relative z-10" viewBox="0 0 400 80" preserveAspectRatio="none">
            <path
              d={currentPattern.svgPath}
              fill="none"
              stroke={currentPattern.fasesColor}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="transition-all duration-300"
            />
          </svg>

          {/* Live Digital Readout Overlay */}
          <div className="absolute top-2 right-4 z-20 text-right pointer-events-none">
            <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">EtCO₂</div>
            <div className="text-3xl font-black font-mono leading-none tracking-tight" style={{ color: currentPattern.fasesColor }}>
              {currentPattern.etco2ValorNum}
              <span className="text-xs font-normal text-slate-400 ml-1">mmHg</span>
            </div>
          </div>
        </div>

        {/* Phase Legend */}
        <div className="mt-2 pt-2 border-t border-slate-900/80 grid grid-cols-4 text-center text-[10px] font-mono text-slate-400">
          <div><strong className="text-slate-300">Fase I:</strong> Vaciado Espacio Muerto (0)</div>
          <div><strong className="text-slate-300">Fase II:</strong> Ascenso Rápido (Mezcla)</div>
          <div><strong className="text-slate-300">Fase III:</strong> Meseta Alveolar</div>
          <div><strong className="text-slate-300">Fase 0:</strong> Descenso Inspiratorio</div>
        </div>
      </div>

      {/* Pattern Clinical Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Description & Causes */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
          <div>
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
              Descripción Fisiopatológica
            </span>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
              {currentPattern.descripcion}
            </p>
          </div>

          <div>
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block mb-1">
              Causas Clínicas Más Frecuentes
            </span>
            <ul className="space-y-1">
              {currentPattern.causasComunes.map((c, i) => (
                <li key={i} className="text-xs text-slate-600 flex items-start gap-1.5">
                  <span className="text-red-500 font-bold shrink-0">•</span>
                  <span>{c}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Immediate Prehospital Action */}
        <div className="bg-red-50/50 border border-red-200 rounded-xl p-4 space-y-3">
          <div className="flex items-center gap-1.5 text-red-700 font-bold text-xs uppercase tracking-wider">
            <Zap className="w-3.5 h-3.5" />
            <span>Conducta Inmediata en Ambulancia</span>
          </div>

          <ul className="space-y-2">
            {currentPattern.conductaInmediata.map((act, i) => (
              <li key={i} className="text-xs text-slate-800 flex items-start gap-2 bg-white p-2.5 rounded-lg border border-red-100 shadow-2xs">
                <CheckCircle2 className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <span className="leading-snug font-medium">{act}</span>
              </li>
            ))}
          </ul>

          <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-800 flex items-start gap-1.5">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <span>
              <strong>Perla APH:</strong> La capnografía es obligatoria para confirmar intubación. Si EtCO₂ cae a cero, asuma extubación accidental hasta demostrar lo contrario.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
