import React, { useState } from 'react';
import { Flame, Clock, Droplets, Info, Check, RotateCcw } from 'lucide-react';

interface BodyPart {
  id: string;
  nombre: string;
  pctAdulto: number;
  pctPediátrico: number;
}

const BODY_PARTS: BodyPart[] = [
  { id: 'cabeza', nombre: 'Cabeza y Cuello', pctAdulto: 9, pctPediátrico: 18 },
  { id: 'torax_ant', nombre: 'Tórax y Abdomen Anterior', pctAdulto: 18, pctPediátrico: 18 },
  { id: 'espalda_post', nombre: 'Espalda y Glúteos Posterior', pctAdulto: 18, pctPediátrico: 18 },
  { id: 'brazo_der', nombre: 'Brazo Derecho Completo', pctAdulto: 9, pctPediátrico: 9 },
  { id: 'brazo_izq', nombre: 'Brazo Izquierdo Completo', pctAdulto: 9, pctPediátrico: 9 },
  { id: 'pierna_der', nombre: 'Pierna Derecha Completa', pctAdulto: 18, pctPediátrico: 14 },
  { id: 'pierna_izq', nombre: 'Pierna Izquierda Completa', pctAdulto: 18, pctPediátrico: 14 },
  { id: 'genitales', nombre: 'Genitales / Periné', pctAdulto: 1, pctPediátrico: 1 },
];

export default function ParklandBurnCalc() {
  const [esPediatrico, setEsPediatrico] = useState<boolean>(false);
  const [pesoKg, setPesoKg] = useState<number>(75);
  const [horasDesdeQuemadura, setHorasDesdeQuemadura] = useState<number>(1);
  const [selectedParts, setSelectedParts] = useState<Record<string, number>>({});
  const [parchesPalma, setParchesPalma] = useState<number>(0); // 1% each
  const [formulaTipo, setFormulaTipo] = useState<'parkland' | 'brooke'>('parkland');

  const togglePart = (id: string, maxPct: number) => {
    setSelectedParts(prev => {
      const current = prev[id] || 0;
      if (current === 0) {
        return { ...prev, [id]: maxPct };
      } else if (current === maxPct) {
        return { ...prev, [id]: Number((maxPct / 2).toFixed(1)) };
      } else {
        const next = { ...prev };
        delete next[id];
        return next;
      }
    });
  };

  const handleReset = () => {
    setSelectedParts({});
    setParchesPalma(0);
  };

  // Calculate Total SCQ (%)
  const totalScqFromParts = Object.values(selectedParts).reduce((a, b) => a + b, 0);
  const totalScq = Math.min(100, Number((totalScqFromParts + parchesPalma).toFixed(1)));

  // Fluid Factor (4 mL for Parkland, 2 mL for modified Brooke)
  const factorMl = formulaTipo === 'parkland' ? 4 : 2;

  // Total 24h fluids = factor * peso * % SCQ (Ringer Lactate)
  const totalFluidos24h = factorMl * pesoKg * totalScq;

  // First 8 hours = 50%
  const volumenPrimeras8h = totalFluidos24h * 0.5;
  const horasRestantesPrimeras8h = Math.max(0.5, 8 - horasDesdeQuemadura);
  const tasaPrimeras8hMlH = horasRestantesPrimeras8h > 0 ? volumenPrimeras8h / horasRestantesPrimeras8h : 0;

  // Next 16 hours = 50%
  const volumenSiguientes16h = totalFluidos24h * 0.5;
  const tasaSiguientes16hMlH = volumenSiguientes16h / 16;

  // Hourly target urine output
  const diuresisMin = esPediatrico ? pesoKg * 1.0 : pesoKg * 0.5;
  const diuresisMax = esPediatrico ? pesoKg * 1.5 : pesoKg * 1.0;

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-orange-50 border border-orange-200 flex items-center justify-center text-orange-600 font-bold">
              <Flame className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Calculadora de Quemados: Regla de los 9 de Wallace & Parkland
              </h2>
              <p className="text-xs text-slate-500">
                Superficie Corporal Quemada (% SCQ) y Esquema de Reanimación con Ringer Lactato
              </p>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-400">Guías ABA & APH</span>
        </div>

        {/* Top Controls: Mode & Patient */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <label className="block text-xs uppercase tracking-wider text-slate-700 font-bold mb-1.5">
              Paciente
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => setEsPediatrico(false)}
                className={`py-1.5 px-2 text-xs font-bold rounded-lg border transition-all ${
                  !esPediatrico ? 'bg-red-600 border-red-600 text-white shadow-2xs' : 'bg-white border-slate-200 text-slate-700'
                }`}
              >
                Adulto
              </button>
              <button
                type="button"
                onClick={() => setEsPediatrico(true)}
                className={`py-1.5 px-2 text-xs font-bold rounded-lg border transition-all ${
                  esPediatrico ? 'bg-red-600 border-red-600 text-white shadow-2xs' : 'bg-white border-slate-200 text-slate-700'
                }`}
              >
                Pediátrico
              </button>
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <label className="block text-xs uppercase tracking-wider text-slate-700 font-bold mb-1.5">
              Fórmula
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => setFormulaTipo('parkland')}
                className={`py-1.5 px-2 text-xs font-bold rounded-lg border transition-all ${
                  formulaTipo === 'parkland' ? 'bg-red-600 border-red-600 text-white shadow-2xs' : 'bg-white border-slate-200 text-slate-700'
                }`}
              >
                Parkland (4mL)
              </button>
              <button
                type="button"
                onClick={() => setFormulaTipo('brooke')}
                className={`py-1.5 px-2 text-xs font-bold rounded-lg border transition-all ${
                  formulaTipo === 'brooke' ? 'bg-red-600 border-red-600 text-white shadow-2xs' : 'bg-white border-slate-200 text-slate-700'
                }`}
              >
                Brooke (2mL)
              </button>
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div className="flex justify-between text-xs font-bold mb-1">
              <span className="text-slate-600">Peso del Paciente</span>
              <span className="font-mono text-red-600">{pesoKg} kg</span>
            </div>
            <input
              type="range"
              min={esPediatrico ? 5 : 40}
              max={esPediatrico ? 50 : 150}
              value={pesoKg}
              onChange={(e) => setPesoKg(Number(e.target.value))}
              className="w-full accent-red-600 cursor-pointer"
            />
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div className="flex justify-between text-xs font-bold mb-1">
              <span className="text-slate-600">Horas desde Lesión</span>
              <span className="font-mono text-red-600">{horasDesdeQuemadura} h</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="7"
              step="0.5"
              value={horasDesdeQuemadura}
              onChange={(e) => setHorasDesdeQuemadura(Number(e.target.value))}
              className="w-full accent-red-600 cursor-pointer"
            />
          </div>
        </div>

        {/* Wallace Rule of Nines Zone Selector */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Selector de Zonas Quemadas (Regla de los 9)
              </span>
              <button
                type="button"
                onClick={handleReset}
                className="text-xs text-red-600 hover:text-red-700 font-medium flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Limpiar</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {BODY_PARTS.map(part => {
                const maxPct = esPediatrico ? part.pctPediátrico : part.pctAdulto;
                const currentVal = selectedParts[part.id] || 0;
                const isFull = currentVal === maxPct;
                const isHalf = currentVal > 0 && currentVal < maxPct;

                return (
                  <button
                    key={part.id}
                    type="button"
                    onClick={() => togglePart(part.id, maxPct)}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      isFull
                        ? 'bg-red-50 border-red-500 text-slate-900 font-bold shadow-2xs'
                        : isHalf
                        ? 'bg-amber-50 border-amber-400 text-slate-900 font-semibold'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs truncate">{part.nombre}</span>
                      <span className="font-mono text-xs font-bold text-red-600">
                        {currentVal > 0 ? `${currentVal}%` : `${maxPct}%`}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-500 block">
                      {isFull ? 'Zona completa (clic para 50%)' : isHalf ? 'Media zona (clic para quitar)' : 'Sin afectación'}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Palm Rule (1%) */}
            <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-800 block">Regla de la Palma de la Mano</span>
                <span className="text-[11px] text-slate-500">Cada palma con dedos del paciente = 1% SCQ</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setParchesPalma(Math.max(0, parchesPalma - 1))}
                  className="w-7 h-7 bg-white border border-slate-300 rounded font-bold text-slate-700 hover:bg-slate-100"
                >
                  -
                </button>
                <span className="font-mono font-bold text-sm text-red-600 px-1">{parchesPalma}%</span>
                <button
                  type="button"
                  onClick={() => setParchesPalma(parchesPalma + 1)}
                  className="w-7 h-7 bg-white border border-slate-300 rounded font-bold text-slate-700 hover:bg-slate-100"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          {/* Results: SCQ and Parkland Fluid Schedule */}
          <div className="lg:col-span-6 space-y-4">
            {/* Total SCQ Banner */}
            <div className="bg-red-50/50 border border-red-200 rounded-xl p-5 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-red-700 uppercase tracking-wider block font-mono">
                  Superficie Corporal Quemada Total
                </span>
                <div className="text-5xl font-black font-mono text-slate-900 mt-1">
                  {totalScq}% <span className="text-base text-slate-500 font-normal">SCQ</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-500 block">Líquidos Totales (24h):</span>
                <span className="text-2xl font-black font-mono text-red-600">
                  {Math.round(totalFluidos24h)} mL
                </span>
                <span className="text-[10px] text-slate-400 block font-mono">Ringer Lactato</span>
              </div>
            </div>

            {/* Schedule 8h / 16h Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* First 8 hours */}
              <div className="bg-white border border-red-200 rounded-xl p-4 shadow-2xs space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-red-700 uppercase">Primeras 8 Horas (50%)</span>
                  <Clock className="w-3.5 h-3.5 text-red-500" />
                </div>
                <div className="text-2xl font-black font-mono text-slate-900">
                  {Math.round(volumenPrimeras8h)} <span className="text-xs text-slate-500 font-normal">mL</span>
                </div>
                <div className="pt-2 border-t border-slate-100 text-xs">
                  <span className="text-slate-500 block text-[11px]">Velocidad de Infusión:</span>
                  <span className="font-mono font-bold text-red-600 text-base">
                    {Math.round(tasaPrimeras8hMlH)} mL / h
                  </span>
                  <span className="text-[10px] text-slate-400 block font-mono mt-0.5">
                    (Quedan {horasRestantesPrimeras8h} h para completar las 8h)
                  </span>
                </div>
              </div>

              {/* Next 16 hours */}
              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700 uppercase">Siguientes 16 Horas (50%)</span>
                  <Droplets className="w-3.5 h-3.5 text-slate-400" />
                </div>
                <div className="text-2xl font-black font-mono text-slate-900">
                  {Math.round(volumenSiguientes16h)} <span className="text-xs text-slate-500 font-normal">mL</span>
                </div>
                <div className="pt-2 border-t border-slate-100 text-xs">
                  <span className="text-slate-500 block text-[11px]">Velocidad de Infusión:</span>
                  <span className="font-mono font-bold text-slate-800 text-base">
                    {Math.round(tasaSiguientes16hMlH)} mL / h
                  </span>
                  <span className="text-[10px] text-slate-400 block font-mono mt-0.5">
                    (Constante durante las 16h restantes)
                  </span>
                </div>
              </div>
            </div>

            {/* Urine Output Target */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-slate-800 block">Objetivo de Diuresis Horaria:</span>
                <span className="text-slate-500">Indicador principal de reposición hídrica adecuada</span>
              </div>
              <div className="text-right font-mono font-bold text-slate-900 text-sm">
                {Math.round(diuresisMin)} - {Math.round(diuresisMax)} mL / h
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
