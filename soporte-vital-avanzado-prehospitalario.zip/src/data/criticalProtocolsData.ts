export interface ProtocolStep {
  etiqueta: string;
  titulo: string;
  descripcion: string;
  acciones: string[];
  alertasRojas?: string[];
}

export interface CriticalProtocol {
  id: string;
  nombre: string;
  categoria: 'trauma' | 'neurologico' | 'cardiovascular' | 'respiratorio' | 'metabolico' | 'sistemico';
  tiempoOro: string;
  resumen: string;
  pasos: ProtocolStep[];
  criteriosAlerta: string[];
}

export const CRITICAL_PROTOCOLS: CriticalProtocol[] = [
  {
    id: 'xabcde',
    nombre: 'Abordaje Sistemático XABCDE Prehospitalario',
    categoria: 'sistemico',
    tiempoOro: 'Evaluación primaria en < 2 minutos',
    resumen: 'Metodología sistemática priorizada para la evaluación y estabilización inmediata del paciente crítico traumático o médico.',
    criteriosAlerta: [
      'Cualquier compromiso detectado debe tratarse INMEDIATAMENTE antes de avanzar a la siguiente letra.',
      'Reevaluación continua cada 5 minutos o tras cualquier intervención.'
    ],
    pasos: [
      {
        etiqueta: 'X',
        titulo: 'Exsanguinating Hemorrhage (Hemorragia Exanguinante)',
        descripcion: 'Control inmediato de hemorragias catastróficas externas con amenaza vital inmediata antes de cualquier otra acción.',
        acciones: [
          'Aplicar torniquete táctico (CAT/SOF-T) "alto y apretado" sobre la extremidad afectada hasta el cese total del sangrado y ausencia de pulso distal.',
          'Si la hemorragia es en zonas de unión (axila, ingle, cuello): empaquetamiento hemostático con gasa impregnada con caolín/quitosano con presión manual firme durante al menos 3 minutos continuos.',
          'Si el sangrado persiste tras el primer torniquete: colocar un segundo torniquete inmediatamente proximal al primero.',
          'Anotar la hora exacta de colocación en el torniquete (marcador indeleble).'
        ],
        alertasRojas: ['El shock hipovolémico mata en minutos. El torniquete salva vidas y es seguro hasta por 2 horas sin riesgo de pérdida de extremidad.']
      },
      {
        etiqueta: 'A',
        titulo: 'Airway & Cervical Spine (Vía Aérea y Control Cervical)',
        descripcion: 'Asegurar permeabilidad aérea manteniendo inmovilización bimanual en posición neutra en pacientes con sospecha de trauma.',
        acciones: [
          'Evaluar si habla, emite sonidos o presenta estridor/ronquidos.',
          'Apertura manual mediante tracción mandibular (sin hiperextensión cervical).',
          'Aspiración de secreciones, sangre o vómito con cánula rígida de Yankauer.',
          'Colocación de cánula orofaríngea (Guedel) en inconscientes o cánula nasofaríngea en pacientes con reflejo nauseoso.',
          'Si la vía aérea está amenazada o Glasgow ≤ 8: proceder a Secuencia Rápida de Intubación (SRI) o dispositivo supraglótico.'
        ],
        alertasRojas: ['Nunca forzar una cánula orofaríngea si el paciente tiene reflejo nauseoso (puede inducir vómito y broncoaspiración masiva).']
      },
      {
        etiqueta: 'B',
        titulo: 'Breathing & Ventilation (Ventilación y Oxigenación)',
        descripcion: 'Evaluar mecánica ventilatoria, frecuencia respiratoria, simetría y descartar lesiones torácicas con riesgo de muerte inminente.',
        acciones: [
          'Inspeccionar simetría torácica, esfuerzo respiratorio, uso de musculatura accesoria.',
          'Auscultar campos pulmonares en 4 puntos (ápices y axilas).',
          'Descartar Neumotórax a Tensión: triada de hipoxemia refractaria + timpanismo unilateral con hipoventilación + hipotensión/ingurgitación yugular. Realizar descompresión torácica con aguja 14G (mínimo 8 cm de longitud) o toracostomía simple en el 5º espacio intercostal línea axilar anterior o 2º EIC línea medioclavicular.',
          'Neumotórax Abierto: colocar parche torácico valvulado comercial con sello de 3 vías.',
          'Administrar oxígeno suplementario para mantener SpO2 94-98% (u 88-92% en EPOC).'
        ]
      },
      {
        etiqueta: 'C',
        titulo: 'Circulation & Perfusion (Circulación y Control de Shock)',
        descripcion: 'Evaluar estado hemodinámico, perfusión tisular y obtener accesos vasculares.',
        acciones: [
          'Evaluar pulso radial (suele indicar TAS ≥ 80 mmHg) vs femoral vs carotídeo.',
          'Tiempo de llenado capilar (normal < 2 segundos), coloración y temperatura cutánea.',
          'Instalar 2 accesos venosos periféricos de grueso calibre (14G o 16G) o acceso intraóseo humeral/tibial (EZ-IO).',
          'En trauma con shock hemorrágico: iniciar Ácido Tranexámico (TXA) 1 g en 10 min dentro de las primeras 3 horas.',
          'Estrategia de Resucitación con Control de Daños / Hipotensión Permisiva: mantener TAS objetivo de 80-90 mmHg (o TAM 60-65 mmHg) con bolos restringidos de cristaloide tibio (250-500 mL) para no diluir factores de coagulación ni romper el coágulo preformado (salvo en Traumatismo Craneoencefálico, donde la TAS debe ser ≥ 100-110 mmHg para asegurar Presión de Perfusión Cerebral PPC).'
        ],
        alertasRojas: ['La administración masiva de suero salino frío induce la triada letal del trauma: Hipotermia, Coagulopatía y Acidosis metabólica.']
      },
      {
        etiqueta: 'D',
        titulo: 'Disability (Déficit Neurológico)',
        descripcion: 'Evaluación neurológica rápida del estado de conciencia, pupilas y metabolismo cerebral.',
        acciones: [
          'Escala de Coma de Glasgow (GCS) y reactividad pupilar (GCS-P).',
          'Examen pupilar: tamaño (isocoria, anisocoria), reactividad simétrica a la luz (descartar herniación uncal por aumento de PIC).',
          'GLUCEMIA CAPILAR obligatoria de inmediato en todo paciente con déficit neurológico o alteración del estado mental (descartar hipoglucemia simulación de ictus o coma).',
          'Detectar signos de focalidad neurológica motora.'
        ]
      },
      {
        etiqueta: 'E',
        titulo: 'Exposure & Environment (Exposición y Prevención de Hipotermia)',
        descripcion: 'Visualización completa de lesiones corporales protegiendo de la pérdida de temperatura central.',
        acciones: [
          'Retirar ropa cortando por costuras cuando sea necesario para examinar cuerpo completo.',
          'Cubrir INMEDIATAMENTE al paciente con manta térmica de rescate reflectante.',
          'Calentar el compartimiento de la ambulancia a 24-26 °C.',
          'Empaquetamiento y movilización en bloque con tabla rígida / colchón de vacío (retirar la tabla espinal tan pronto sea posible para evitar úlceras por decúbito).'
        ]
      }
    ]
  },
  {
    id: 'codigo_ictus',
    nombre: 'Código Ictus / ACV Prehospitalario',
    categoria: 'neurologico',
    tiempoOro: 'Tiempo de inicio de síntomas < 4.5 h (trombolisis) o < 24 h (trombectomía mecánica)',
    resumen: 'Detección ultrarrápida del accidente cerebrovascular isquémico agudo con escalas de cribado validadas y prealerta hospitalaria.',
    criteriosAlerta: [
      'Hora de "Última Vez Visto Bien" (UVVB) es el dato clínico más importante.',
      'Descartar hipoglucemia antes de cualquier otra conclusión.',
      'No descender la presión arterial salvo que TAS > 220 o TAD > 120 mmHg.'
    ],
    pasos: [
      {
        etiqueta: 'Paso 1',
        titulo: 'Confirmación y Escala Cincinnati (CPSS)',
        descripcion: 'Cribado inicial prehospitalario de 3 signos:',
        acciones: [
          '1. Asimetría Facial: pedir al paciente que muestre los dientes o sonría (anormal: un lado no se mueve igual que el otro).',
          '2. Caída del Brazo: pedir que cierre los ojos y extienda ambos brazos hacia adelante con palmas arriba durante 10 s (anormal: un brazo cae o rota hacia adentro).',
          '3. Habla Anormal: pedir que repita "El perro corre en el parque" (anormal: arrastra las palabras, usa palabras incorrectas o es incapaz de hablar).',
          'Interpretación: 1 parámetro alterado = 72% probabilidad de ACV. Los 3 parámetros = > 85% probabilidad.'
        ]
      },
      {
        etiqueta: 'Paso 2',
        titulo: 'Escala RACE (Rapid Arterial oCclusion Evaluation)',
        descripcion: 'Predicción específica de Oclusión de Gran Vaso (OGV) candidato a Trombectomía Mecánica urgente:',
        acciones: [
          'Paresia facial (0-2) + Paresia braquial (0-2) + Paresia crural (0-2) + Desviación de mirada cefálica (0-1) + Afasia/Agnosia (0-2).',
          'Puntuación RACE ≥ 5 puntos predice fuertemente Oclusión de Gran Vaso (arteria cerebral media M1 o carótida interna). Activar traslado directo a centro con Neurorradiología Intervencionista 24/7.'
        ]
      },
      {
        etiqueta: 'Paso 3',
        titulo: 'Manejo Prehospitalario y Preaviso',
        descripcion: 'Acciones críticas durante el traslado urgente:',
        acciones: [
          'Glucemia capilar inmediata (si < 60 mg/dL corregir con D10W).',
          'Acceso venoso periférico 18G preferente en brazo NO parético (evitar punciones innecesarias que limiten trombolisis).',
          'Cabecero a 0° - 15° si tolera para maximizar la perfusión cerebral penumbral (salvo vómitos o dificultad respiratoria, donde se eleva a 30°).',
          'Oxígeno suplementario solo si SpO2 < 94% (no usar O2 de rutina por hiperoxia vasoconstrictora).',
          'PREALERTA HOSPITALARIA con: edad, tiempo de evolución UVVB, escala RACE, uso previo de anticoagulantes orales (Sintrom, Eliquis, Xarelto) y constantes.'
        ]
      }
    ]
  },
  {
    id: 'codigo_infarto',
    nombre: 'Código Infarto / IAMCEST Prehospitalario',
    categoria: 'cardiovascular',
    tiempoOro: 'ECG en < 10 min de contacto. Angioplastia primaria (ICP) < 120 min desde diagnóstico',
    resumen: 'Identificación precoz de infarto agudo de miocardio con elevación del segmento ST y activación de la red de reperfusión.',
    criteriosAlerta: [
      'Si el tiempo previsto hasta la ICP es > 120 minutos, valorar Fibrinolisis Prehospitalaria inmediata (TNK / Tenecteplasa) antes de 30 minutos.',
      'En todo IAM inferior, realizar derivaciones derechas (V3R, V4R) antes de nitratos.'
    ],
    pasos: [
      {
        etiqueta: 'Paso 1',
        titulo: 'Diagnóstico Electrocardiográfico (ECG de 12 derivaciones en < 10 min)',
        descripcion: 'Criterios de elevación del punto J en ≥ 2 derivaciones anatómicamente contiguas:',
        acciones: [
          'V2-V3: ≥ 2 mm (0.2 mV) en hombres ≥ 40 años; ≥ 2.5 mm en hombres < 40 años; ≥ 1.5 mm en mujeres de cualquier edad.',
          'Resto de derivaciones (DI, aVL, DII, DIII, aVF, V1, V4-V6): ≥ 1 mm (0.1 mV).',
          'Bloqueo de Rama Izquierda (BRI) nuevo o presumiblemente nuevo con sospecha clínica o Criterios de Sgarbossa modificados (elevación concordante del ST ≥ 1 mm o depresión concordante en V1-V3 ≥ 1 mm o elevación discordante excesiva ≥ 25% de la onda S).',
          'Cara inferior (DII, DIII, aVF): tomar obligatoriamente V3R y V4R para descartar infarto de ventrículo derecho.'
        ]
      },
      {
        etiqueta: 'Paso 2',
        titulo: 'Tratamiento Inicial Prehospitalario (FONA)',
        descripcion: 'Estrategia farmacológica de estabilización y antiagregación:',
        acciones: [
          'ÁCIDO ACETILSALICÍLICO (AAS): 162 a 325 mg masticados (sin cubierta entérica).',
          'Segundo antiagregante (Inhibidor P2Y12 según protocolo local): Ticagrelor 180 mg o Clopidogrel 300-600 mg VO.',
          'Anticoagulación: Heparina no fraccionada (bolo 60-70 UI/kg IV, máx 5.000 UI) o Enoxaparina 30 mg IV.',
          'Nitroglicerina SL 0.4 mg cada 5 min (máx 3) SOLO si TAS > 90 mmHg y NO hay sospecha de infarto de ventrículo derecho ni consumo de inhibidores de PDE5.',
          'Morfina (2-4 mg IV) o Fentanilo (50-100 mcg IV) si el dolor es refractario a nitratos.',
          'Oxígeno suplementario únicamente si SpO2 < 90%.'
        ]
      }
    ]
  },
  {
    id: 'estatus_epileptico',
    nombre: 'Estatus Epiléptico Prehospitalario',
    categoria: 'neurologico',
    tiempoOro: 'Tiempo T1 (5 min) inicio de daño neuronal. T2 (30 min) daño irreversible',
    resumen: 'Protocolo de rescate farmacológico ante crisis convulsivas prolongadas (> 5 minutos) o repetidas sin recuperación de conciencia.',
    criteriosAlerta: [
      'A los 5 minutos de convulsión activa se pierde la capacidad de autolimitación y se considera Estatus Convulsivo.',
      'Control de vía aérea, glucemia y posición de seguridad.'
    ],
    pasos: [
      {
        etiqueta: 'T = 0 a 5 min',
        titulo: 'Fase Inicial y Medidas Generales',
        descripcion: 'Protección y soporte fisiológico inicial:',
        acciones: [
          'Proteger al paciente de traumatismos secundarios en suelo o ambulancia.',
          'Posición de seguridad lateral una vez cese la fase tónica si ventila adecuadamente.',
          'Aspiración de secreciones y oxígeno a alto flujo mediante mascarilla con reservorio.',
          'Medición de Glucemia Capilar inmediata (si < 60 mg/dL: Dextrosa 10% 200 mL IV).'
        ]
      },
      {
        etiqueta: 'T = 5 a 10 min',
        titulo: 'Fase 1: Terapia de Primera Línea (Benzodiazepinas de Acción Rápida)',
        descripcion: 'Administración urgente sin demoras buscando accesos venosos dificultosos:',
        acciones: [
          'Sin vía venosa: MIDAZOLAM 10 mg Intramuscular (en muslo) o Intranasal (5 mg en cada fosa nasal con atomizador) para peso > 40 kg (o 0.2 mg/kg en niños).',
          'Con vía venosa: DIAZEPAM 10 mg IV lento a 2 mg/min (o Midazolam 0.1 mg/kg IV / Lorazepam 4 mg IV).',
          'Si la crisis persiste tras 5 minutos de la primera dosis: repetir una segunda dosis idéntica de Benzodiazepina.',
          'Tener preparado Ambú con mascarilla por riesgo de apnea transitoria poscrisis.'
        ]
      },
      {
        etiqueta: 'T = 10 a 30 min',
        titulo: 'Fase 2: Fármacos Antiepilépticos de Segunda Línea',
        descripcion: 'Si las convulsiones no ceden tras dos dosis de benzodiazepinas:',
        acciones: [
          'Levetiracetam (Keppra): 60 mg/kg IV en 10 min (máx 4.5 g).',
          'Valproato de Sodio: 40 mg/kg IV en 10 min (máx 3 g).',
          'Fenitoína: 20 mg/kg IV en infusión lenta (máx 50 mg/min con monitorización de ECG por riesgo de arritmias).',
          'Si progresa a estatus refractario (> 30 min): Inducción anestésica con Ketamina o Propofol e intubación orotraqueal.'
        ]
      }
    ]
  },
  {
    id: 'anafilaxia',
    nombre: 'Anafilaxia Grave y Shock Anafiláctico',
    categoria: 'respiratorio',
    tiempoOro: 'Administración de Adrenalina IM en los primeros 5 minutos',
    resumen: 'Manejo agresivo de la reacción alérgica sistémica potencialmente mortal que compromete vía aérea, respiración o circulación.',
    criteriosAlerta: [
      'La Adrenalina Intramuscular en muslo es el único fármaco que reduce la mortalidad comprobada.',
      'Antihistamínicos y corticoides son de segunda línea y NUNCA deben retrasar la adrenalina.'
    ],
    pasos: [
      {
        etiqueta: 'Paso 1',
        titulo: 'Adrenalina Intramuscular Inmediata',
        descripcion: 'Droga de primera línea de administración imperativa:',
        acciones: [
          'ADRENALINA 0.5 mg IM (ampolla 1:1.000 sin diluir = 0.5 mL) en la cara anterolateral del muslo (vasto lateral).',
          'En niños: 0.01 mg/kg IM (máx 0.3 mg en preescolares / 0.5 mg en adolescentes).',
          'Repetir cada 5 a 15 minutos si la respuesta es incompleta o los síntomas reaparecen.'
        ]
      },
      {
        etiqueta: 'Paso 2',
        titulo: 'Posicionamiento y Fluidoterapia Agresiva',
        descripcion: 'Manejo del colapso circulatorio distributivo:',
        acciones: [
          'Colocar al paciente en decúbito supino con piernas elevadas (o posición semisentada si predomina estridor/disnea sin shock). ¡NUNCA poner de pie o sentar bruscamente a un paciente en anafilaxia porque puede ocurrir el síndrome de "corazón vacío" por colapso del retorno venoso y parada cardíaca súbita!',
          'Oxígeno a 15 L/min con mascarilla con reservorio.',
          'Canalizar 2 accesos venosos periféricos de gran calibre (14G o 16G).',
          'Carga rápida de solución cristaloide isotónica (Solución Ringer Lactato o SF 0.9%): 1 a 2 Litros en adulto (20 mL/kg en niños) debido a la extravasación masiva de plasma al intersticio.'
        ]
      },
      {
        etiqueta: 'Paso 3',
        titulo: 'Fármacos Secundarios y Vía Aérea',
        descripcion: 'Manejo de síntomas bronquiales y prevención de respuesta bifásica:',
        acciones: [
          'Si hay broncoespasmo: Salbutamol nebulizado 5 mg + Bromuro de ipratropio 0.5 mg.',
          'Si hay estridor laríngeo severo: preparar inmediatamente intubación endotraqueal precoz antes de que el edema cierre por completo la glotis.',
          'Corticoides: Hidrocortisona 200 mg IV o Metilprednisolona 1-2 mg/kg IV.',
          'Antihistamínicos: Dexclorfeniramina 5 mg IV o Difenhidramina 50 mg IV lento.',
          'Si shock refractario a adrenalina IM y fluidos: infusión continua de Adrenalina IV (2 a 10 mcg/min).'
        ]
      }
    ]
  }
];
