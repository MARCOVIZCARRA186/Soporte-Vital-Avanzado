export interface IndicacionVentilacion {
  categoria: 'insuficiencia' | 'proteccion' | 'neurologica' | 'miscelanea';
  titulo: string;
  items: string[];
}

export const INDICACIONES_VENTILACION_AVENTHO: IndicacionVentilacion[] = [
  {
    categoria: 'insuficiencia',
    titulo: 'Insuficiencia Respiratoria',
    items: [
      'PaO2 < 60 mmHg (previo O2 suplementario)',
      'SpO2 < 88% (previo O2 suplementario)',
      'PaCO2 > 50 mmHg con pH < 7.32 (habitualmente sintomática)'
    ]
  },
  {
    categoria: 'proteccion',
    titulo: 'Protección de la Vía Aérea',
    items: [
      'Apnea',
      'Obstrucción mecánica de la vía aérea',
      'Deterioro neurológico que condicione hipoxemia o hipoventilación',
      'Alta probabilidad de obstrucción, aspiración o falla ventilatoria inminente',
      'Traumatismo Craneoencefálico (TCE) Severo',
      'Trauma Facial con compromiso o sospecha de compromiso de vía aérea',
      'Trauma Cervical con compromiso o sospecha de vía aérea',
      'Quemadura de vía aérea o sospecha de inhalación de humo / quemadura glótica'
    ]
  },
  {
    categoria: 'neurologica',
    titulo: 'Indicaciones Neurológicas',
    items: [
      'Escala de Coma de Glasgow ≤ 8 puntos ("Glasgow 8 o menos, intubación")',
      'Disminución aguda de 2 o más puntos del puntaje inicial de Glasgow'
    ]
  },
  {
    categoria: 'miscelanea',
    titulo: 'Indicaciones Misceláneas y Transporte',
    items: [
      'Anestesia, analgesia y sedación en pacientes sometidos a cirugía mayor (superiores al diafragma)',
      'Transporte crítico de paciente con riesgo inminente de colapso neurológico o respiratorio',
      'Procedimientos diagnóstico-terapéuticos complejos (ej. broncoscopía de urgencia)'
    ]
  }
];

export interface SedanteAventho {
  farmaco: string;
  tipo: string;
  dosisInduccion: string;
  dosisMantenimiento: string;
  inicio: string;
  duracion: string;
  observaciones: string[];
  embarazo: string;
}

export const SEDANTES_AVENTHO: SedanteAventho[] = [
  {
    farmaco: 'Etomidato',
    tipo: 'Hipnótico no barbitúrico',
    dosisInduccion: '0.2 - 0.6 mg/kg IV',
    dosisMantenimiento: '5 - 20 mcg/kg/min IV',
    inicio: '30 segundos',
    duracion: '3 - 10 minutos',
    observaciones: [
      'Estabilidad hemodinámica y respiratoria óptima (de elección en shock o cardiopatía).',
      'No tiene efecto analgésico.',
      'Reduce consumo cerebral de O2, la presión intraocular (PIO) y la presión intracraneal (PIC).',
      'Nota AVENTHO inestable: 0.2 mg/kg con Fentanilo 20-40 mcg.'
    ],
    embarazo: 'Clase C'
  },
  {
    farmaco: 'Fentanilo',
    tipo: 'Opiáceo sintético',
    dosisInduccion: '1 - 3 mcg/kg IV (sedación 50-100 mcg IV)',
    dosisMantenimiento: '0.7 - 10 mcg/kg/h infusión continua',
    inicio: '1 - 2 minutos',
    duracion: '30 - 40 minutos',
    observaciones: [
      'Gran variabilidad de la dosis.',
      'Dependencia física a los 3-5 días de uso continuo.',
      '¡Alerta!: La infusión IV rápida puede provocar rigidez muscular y de pared torácica ("tórax en leño"), hipotensión y bradicardia.'
    ],
    embarazo: 'Clase B'
  },
  {
    farmaco: 'Ketamina',
    tipo: 'Anestésico disociativo (antagonista NMDA)',
    dosisInduccion: '1 - 2.5 mg/kg IV (sedación 0.5 - 1 mg/kg IV)',
    dosisMantenimiento: '0.7 - 3 mcg/kg/h infusión continua',
    inicio: '30 segundos',
    duracion: '5 - 15 minutos IV',
    observaciones: [
      'Mantiene reflejos protectores de la vía aérea y el tono simpático.',
      'Potente broncodilatación (ideal en crisis asmática o EPOC severo).',
      'Produce broncorrea, analgesia somática profunda, nistagmo y midriasis.',
      '¡Precaución!: Puede inducir hipotensión y apnea en pacientes con shock séptico terminal y reservas de catecolaminas depletadas.'
    ],
    embarazo: 'Clase C'
  },
  {
    farmaco: 'Midazolam',
    tipo: 'Benzodiacepina de acción corta',
    dosisInduccion: '0.1 - 0.3 mg/kg IV (sedación consciente 0.05 - 0.1 mg/kg)',
    dosisMantenimiento: '0.04 - 0.4 mg/kg/h infusión',
    inicio: '1 - 2 minutos',
    duracion: '1 - 4 horas',
    observaciones: [
      'Potente efecto amnésico anterógrado, no provee analgesia.',
      'Dosis muy variable según tolerancia; reducir 50% la dosis si Depuración de Creatinina < 10 mL/min.',
      'El uso prolongado causa acumulación de metabolitos activos y síndrome de abstinencia.'
    ],
    embarazo: 'Clase D'
  },
  {
    farmaco: 'Propofol',
    tipo: 'Hipnótico alquilfenol',
    dosisInduccion: '1.5 - 2 mg/kg IV',
    dosisMantenimiento: '1 - 5 mg/kg/h infusión',
    inicio: '20 - 40 segundos',
    duracion: '8 - 15 minutos',
    observaciones: [
      'Inicio de efecto hipnótico ultrarrápido y despertar muy limpio, efecto antiemético.',
      'No tiene efecto analgésico.',
      'Causa vasodilatación sistémica e hipotensión arterial marcada; induce apnea.',
      'Formulación lipídica: se contamina fácilmente; contraindicado en alérgicos a soya o huevo.'
    ],
    embarazo: 'Clase B'
  },
  {
    farmaco: 'Tiopental',
    tipo: 'Barbitúrico de acción ultracorta',
    dosisInduccion: '3 - 5 mg/kg IV (sedación 0.5 - 1 mg/kg)',
    dosisMantenimiento: 'Infusión reservada para estatus refractario',
    inicio: '30 segundos',
    duracion: '3 - 5 minutos',
    observaciones: [
      'Hipnosis rápida, amnesia retrógrada, sin analgesia.',
      'Reduce drásticamente la PIO, PIC y el consumo de O2 cerebral.',
      'Depresor miocárdico directo, dolor en el sitio de inyección y puede desencadenar broncoespasmo.'
    ],
    embarazo: 'Clase D'
  }
];

export interface RelajanteAventho {
  farmaco: string;
  tipo: 'Despolarizante' | 'No despolarizante';
  dosisIv: string;
  inicioEfecto: string;
  recuperacion: string;
  perlas: string;
}

export const RELAJANTES_AVENTHO: RelajanteAventho[] = [
  {
    farmaco: 'Succinilcolina',
    tipo: 'Despolarizante',
    dosisIv: '1 - 2 mg/kg IV',
    inicioEfecto: '< 1 minuto (45 s)',
    recuperacion: '3 - 10 minutos',
    perlas: 'Fasciculaciones previas. Contraindicado en hipercalemia, quemaduras > 24h, denervación muscular o antecedente de hipertermia maligna.'
  },
  {
    farmaco: 'Rocuronio',
    tipo: 'No despolarizante',
    dosisIv: '1 - 1.2 mg/kg IV',
    inicioEfecto: '< 1 minuto (60 s)',
    recuperacion: '> 20 - 45 minutos',
    perlas: 'De elección para SRI si Succinilcolina está contraindicada. Reversor específico disponible: Sugammadex (16 mg/kg para reversión inmediata).'
  },
  {
    farmaco: 'Vecuronio',
    tipo: 'No despolarizante',
    dosisIv: '0.1 - 0.2 mg/kg IV',
    inicioEfecto: '1 - 2 minutos',
    recuperacion: '> 20 - 35 minutos',
    perlas: 'Excelente estabilidad hemodinámica. Se utiliza para mantenimiento o si no hay Rocuronio disponible.'
  },
  {
    farmaco: 'Rapacuronio',
    tipo: 'No despolarizante',
    dosisIv: '1.5 - 2 mg/kg IV',
    inicioEfecto: '< 1 minuto',
    recuperacion: '5 - 7 minutos',
    perlas: 'Acción rápida y recuperación intermedia. Poco disponible por riesgo de broncoespasmo severo.'
  },
  {
    farmaco: 'Atracurio',
    tipo: 'No despolarizante',
    dosisIv: '0.1 mg/kg IV',
    inicioEfecto: '2 minutos',
    recuperacion: '30 minutos',
    perlas: 'Eliminación de Hofmann independiente de función hepática y renal. Puede liberar histamina si se inyecta rápido.'
  }
];

export interface EscalaSedacionAventho {
  grado: number;
  nombre: string;
  descripcion: string;
  indicacionClinica: string;
}

export const ESCALA_SEDACION_AVENTHO: EscalaSedacionAventho[] = [
  {
    grado: 1,
    nombre: 'Ansiolisis',
    descripcion: 'Disminuir o quitar ansiedad o agitación de forma no farmacológica y/o farmacológica, sin pérdida de la consciencia del paciente.',
    indicacionClinica: 'Paciente en posoperatorio inmediato no ventilado o destete ventilatorio.'
  },
  {
    grado: 2,
    nombre: 'Sedación Mínima',
    descripcion: 'Estado de transición entre consciente y disminución del nivel de consciencia, respondiendo normalmente a órdenes verbales. Función ventilatoria y cardiovascular intactas.',
    indicacionClinica: 'Trastornos neuromusculares (ej. Guillain-Barré), SDRA leve, o causas no neurocríticas.'
  },
  {
    grado: 3,
    nombre: 'Sedación Moderada',
    descripcion: 'Responde a órdenes verbales o estimulación táctil/luminosa. La ventilación espontánea es adecuada y la función cardiovascular se mantiene.',
    indicacionClinica: 'Insuficiencia respiratoria tipo 1 moderada (ej. Neumonía grave, SDRA con PaO2/FiO2 > 150).'
  },
  {
    grado: 4,
    nombre: 'Sedación Profunda',
    descripcion: 'No despierta fácilmente, responde a estímulo doloroso. La función ventilatoria y hemodinámica pueden afectarse.',
    indicacionClinica: 'SDRA severo, Hipertensión Intracraneal (HIC) o hiperinsuflación dinámica crítica (Estatus asmático / EPOC).'
  },
  {
    grado: 5,
    nombre: 'Sedo-anestesia',
    descripcion: 'Pérdida total de consciencia, no excitable a estimulación dolorosa. Sin función ventilatoria espontánea; compromiso cardiovascular común.',
    indicacionClinica: 'Paro cardíaco, SRI inmediata, relajación neuromuscular obligatoria o SDRA severo refractario.'
  }
];

export interface TrastornoAcidoBase {
  trastorno: string;
  ph: '⬇' | '⬆';
  pco2: '⬆' | '⬇';
  eb: 'Normal' | '⬆' | '⬇';
  interpretacion: string;
}

export const ACIDO_BASE_AVENTHO: TrastornoAcidoBase[] = [
  { trastorno: 'Acidosis respiratoria aguda', ph: '⬇', pco2: '⬆', eb: 'Normal', interpretacion: 'Hipoventilación aguda sin compensación renal todavía (ej. sobredosis aguda opioides).' },
  { trastorno: 'Acidosis respiratoria crónica', ph: '⬇', pco2: '⬆', eb: '⬆', interpretacion: 'Retenedor crónico de CO2 con compensación metabólica renal (bicarbonato elevado).' },
  { trastorno: 'Alcalosis respiratoria aguda', ph: '⬆', pco2: '⬇', eb: 'Normal', interpretacion: 'Hiperventilación aguda por dolor, crisis de ansiedad o embolsado excesivo con BVM.' },
  { trastorno: 'Alcalosis respiratoria crónica', ph: '⬆', pco2: '⬇', eb: '⬇', interpretacion: 'Hiperventilación sostenida con compensación renal (ej. embarazo, hipoxemia de gran altura).' },
  { trastorno: 'Acidosis metabólica', ph: '⬇', pco2: '⬇', eb: '⬇', interpretacion: 'Cetoacidosis, shock láctico, intoxicación. Se debe calcular PaCO2 esperado con fórmula de Winter.' },
  { trastorno: 'Alcalosis metabólica', ph: '⬆', pco2: '⬆', eb: '⬆', interpretacion: 'Pérdida de ácido (vómitos copiosos) o exceso de bicarbonato con hipoventilación compensatoria.' },
];
