import { DrugItem, VasoactiveDrugPreset } from '../types/clinical';

export const PHARMACOLOGY_DATABASE: DrugItem[] = [
  // 1. ASA
  {
    id: 'asa',
    nombre: 'ASA (Ácido Acetilsalicílico)',
    nombreComercial: 'Aspirina, Adiro',
    clasificacion: 'Antiagregante plaquetario, AINE, Analgésico / Antipirético',
    categoria: 'cardiovascular',
    presentacion: 'Comprimidos masticables 100 mg, 300 mg y 500 mg',
    concentracion: '100 mg - 500 mg / comp',
    mgPorMl: 100,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 300, etiqueta: 'SCACEST / SCASEST masticado' },
    dosisPresets: [
      { label: 'SCA / IAM dosis de carga (162 - 325 mg VO)', doseVal: 300, unit: 'mg_fijo' },
      { label: 'Analgesia / Fiebre adulto (500 - 1000 mg VO)', doseVal: 500, unit: 'mg_fijo' },
    ],
    viasAdministracion: ['VO (Oral masticada sin cubierta entérica)'],
    indicaciones: [
      'Síndrome Coronario Agudo (IAMCEST / SCASEST / Angina inestable) de primera línea',
      'Accidente Isquémico Transitorio (AIT) y ACV isquémico agudo (tras descartar hemorragia en TAC)',
      'Dolor leve a moderado y fiebre (uso no urgente)'
    ],
    contraindicaciones: [
      'Hipersensibilidad conocida a salicilatos o AINEs (asma inducida por aspirina / triada de Samter)',
      'Hemorragia digestiva activa o úlcera péptica sangrante',
      'Sospecha de disección aórtica o hemorragia subaracnoidea',
      'Niños y adolescentes con fiebre viral (riesgo de Síndrome de Reye)'
    ],
    dosis: {
      adulto: 'SCA: 162 a 325 mg vía oral MASTICADA (habitualmente 3 comprimidos de 100 mg o 1 de 300/500 mg sin cubierta entérica).',
      pediatrico: 'Contraindicado en analgesia/fiebre por Síndrome de Reye (salvo Enfermedad de Kawasaki bajo supervisión hospitalaria: 30-50 mg/kg/día).',
      maxDose: 'SCA: 325 mg carga.',
      dilucionSugerida: 'Administrar vía oral pidiendo al paciente que lo mastique y disuelva en la boca antes de deglutir para máxima absorción transmucosa.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Inhibición irreversible de la ciclooxigenasa-1 (COX-1) plaquetaria por acetilación, bloqueando la síntesis de tromboxano A2 (TXA2) durante toda la vida útil de la plaqueta (7 a 10 días).',
      farmacocinetica: {
        inicio: '15 a 30 minutos (masticada se reduce a < 15 min)',
        pico: '1 a 2 horas',
        duracion: '7 a 10 días (vida media de las plaquetas)',
        metabolismoSemivida: 'Metabolismo hepático a salicilato. Semivida plasmática del ASA: 15-20 min; del ácido salicílico: 2-3 horas.'
      }
    },
    efectosSecundarios: ['Dispepsia, pirosis, náuseas, dolor epigástrico, prolongación del tiempo de sangrado.'],
    efectosAdversos: ['Hemorragia digestiva grave, broncoespasmo severo en asmáticos, acúfenos (salicilismo), trombocitopenia.'],
    txSobredosis: 'Alcalinización urinaria con Bicarbonato de Sodio IV (objetivo pH urinario > 7.5), carbón activado si ingesta reciente (< 2 h), hemodiálisis en niveles séricos > 100 mg/dL.',
    riesgoEmbarazo: 'D',
    puntosImportantes: [
      'Debe ser MASTICADA: la absorción por mucosa oral y gástrica inmediata es fundamental en el infarto en curso.',
      'No utilizar comprimidos con cubierta entérica en emergencias porque su absorción se retrasa horas.',
      'Preguntar siempre por alergia a aspirina y asma grave.'
    ],
    flashcard: {
      pregunta: '¿Por qué la Aspirina (ASA) debe ser obligatoriamente MASTICADA en el Síndrome Coronario Agudo?',
      respuesta: 'Porque al masticarla se absorbe rápidamente a través de la mucosa oral y gástrica, logrando la inhibición completa del tromboxano A2 plaquetario en menos de 15 minutos (frente a > 1 hora si se traga entera).',
      puntosClave: [
        'Dosis estándar prehospitalaria: 162 a 325 mg VO.',
        'Evitar presentaciones con recubrimiento entérico.',
        'Contraindicada en hemorragia digestiva activa o triada de Samter.'
      ]
    }
  },

  // 2. ATX (Ácido Tranexámico / TXA)
  {
    id: 'atx',
    nombre: 'ATX (Ácido Tranexámico / TXA)',
    nombreComercial: 'Amchafibrin, Cyklokapron',
    clasificacion: 'Antifibrinolítico sintético',
    categoria: 'resucitacion',
    presentacion: 'Ampolla 1.000 mg (1 g) / 10 mL (100 mg/mL) o 500 mg / 5 mL',
    concentracion: '100 mg/mL',
    mgPorMl: 100,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 1000, etiqueta: 'Bolo IV en 10 min (< 3h de trauma)' },
    dosisPresets: [
      { label: 'Adulto trauma / shock hemorrágico (1 g IV en 10 min)', doseVal: 1000, unit: 'mg_fijo' },
      { label: 'Pediátrico trauma (15 mg/kg IV en 10 min)', doseVal: 15, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV', 'IO'],
    indicaciones: [
      'Traumatismo grave con sospecha o evidencia de shock hemorrágico (TAS < 90 mmHg, FC > 110 lpm)',
      'Hemorragia posparto severa refractaria',
      'Hemorragia exanguinante en combate o rescate dentro de las primeras 3 horas de la lesión'
    ],
    contraindicaciones: [
      'Transcurridas más de 3 HORAS desde el traumatismo (incrementa la mortalidad)',
      'Hipersensibilidad al fármaco',
      'Hemorragia subaracnoidea no traumática'
    ],
    dosis: {
      adulto: '1 gramo IV diluido en 100 mL de SF 0.9% a pasar en 10 minutos (seguido en hospital de 1 g en infusión de 8 horas).',
      pediatrico: '15 a 20 mg/kg IV en 10 min (máx 1.000 mg).',
      formulaMgKg: 15,
      maxDose: '1 g en bolo inicial prehospitalario.',
      dilucionSugerida: 'Diluir 1 g en 100 mL de Solución Fisiológica 0.9% y pasar en 10 minutos.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Bloqueador competitivo de los sitios de fijación de lisina en las moléculas de plasminógeno, impidiendo su transformación en plasmina y la degradación del coágulo de fibrina.',
      farmacocinetica: {
        inicio: '5 a 15 minutos IV',
        pico: 'Inmediato tras infusión',
        duracion: '3 a 4 horas',
        metabolismoSemivida: 'Excreción renal inalterada (> 95%). Semivida: 2 a 3 horas.'
      }
    },
    efectosSecundarios: ['Náuseas, diarrea, mareos, cefalea leve.'],
    efectosAdversos: ['Hipotensión grave por infusión rápida, trombosis venosa profunda, tromboembolismo pulmonar, convulsiones a dosis muy elevadas.'],
    txSobredosis: 'Soporte hemodinámico, hidratación y monitorización de eventos tromboembólicos.',
    riesgoEmbarazo: 'B',
    puntosImportantes: [
      'Regla de oro CRASH-2: debe administrarse en las primeras 3 HORAS (ideal < 1 h). Después de 3 horas aumenta la mortalidad.',
      'Nunca administrar en bolo directo rápido sin diluir por riesgo de colapso hemodinámico.',
      'No demorar el traslado; iniciar la infusión en ruta.'
    ],
    flashcard: {
      pregunta: '¿Cuál es el límite temporal estricto del Ácido Tranexámico (ATX) en trauma severo?',
      respuesta: '3 horas desde el momento del traumatismo. Si se administra después de 3 horas, el estudio CRASH-2 demostró un aumento significativo de la mortalidad por eventos trombóticos y necrosis.',
      puntosClave: [
        'Dosis: 1 g IV en 100 mL SF a pasar en 10 minutos.',
        'Indicación: TAS < 90 mmHg, FC > 110 lpm o sangrado masivo.',
        'Vía IV o IO.'
      ]
    }
  },

  // 3. ADENOSINA
  {
    id: 'adenosina',
    nombre: 'Adenosina',
    nombreComercial: 'Adenocor',
    clasificacion: 'Antiarrítmico de clase V (nucleósido purinérgico)',
    categoria: 'antiarritmicos',
    presentacion: 'Ampolla 6 mg / 2 mL (3 mg/mL)',
    concentracion: '3 mg/mL',
    mgPorMl: 3,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 6, etiqueta: '1ª dosis bolo ultrarrápido' },
    dosisPresets: [
      { label: '1ª Dosis Adulto TSVP (6 mg bolo rápido)', doseVal: 6, unit: 'mg_fijo' },
      { label: '2ª Dosis Adulto TSVP (12 mg bolo rápido)', doseVal: 12, unit: 'mg_fijo' },
      { label: '1ª Dosis Pediátrica (0.1 mg/kg, máx 6 mg)', doseVal: 0.1, unit: 'mg/kg' },
      { label: '2ª Dosis Pediátrica (0.2 mg/kg, máx 12 mg)', doseVal: 0.2, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV rápida proximal con técnica de dos jeringas / llave de 3 vías'],
    indicaciones: [
      'Taquicardia Supraventricular Paroxística (TSVP) hemodinámicamente estable',
      'Diagnóstico diferencial de taquicardia regular de complejo estrecho'
    ],
    contraindicaciones: [
      'Asma bronquial severa o broncoespasmo activo',
      'Bloqueo AV de 2º o 3º grado previo (salvo con marcapasos)',
      'Síndrome del seno enfermo',
      'FA con preexcitación (WPW) si es irregular o ancha'
    ],
    dosis: {
      adulto: '1ª dosis: 6 mg en bolo ultrarrápido (1-2 s) + 20 mL SF. Si no revierte en 1-2 min: 2ª dosis de 12 mg.',
      pediatrico: '1ª dosis: 0.1 mg/kg (máx 6 mg). 2ª dosis: 0.2 mg/kg (máx 12 mg).',
      formulaMgKg: 0.1,
      maxDose: '12 mg por dosis.',
      dilucionSugerida: 'Sin diluir. Usar vena antecubital proximal y arrastrar con 20 mL de SF con elevación del brazo.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Estimula receptores A1 purinérgicos miocárdicos acoplados a proteína Gi, bloqueando la entrada de calcio y abriendo canales de K+. Deprime la conducción del nódulo AV y corta el circuito de reentrada.',
      farmacocinetica: {
        inicio: 'Inmediato (< 10 segundos)',
        pico: 'Inmediato',
        duracion: '< 10 a 20 segundos',
        metabolismoSemivida: 'Semivida < 10 segundos. Degradada por adenosina desaminasa en eritrocitos y células endoteliales.'
      }
    },
    efectosSecundarios: ['Sensación inminente de muerte, rubor facial, disnea, opresión torácica, mareo.'],
    efectosAdversos: ['Pausa sinusal prolongada / asistolia transitoria, broncoespasmo severo, fibrilación auricular inducida.'],
    txSobredosis: 'Efecto autolimitado en segundos por semivida ultracorta; Teofilina/Aminofilina actúan como antagonistas competitivos.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'Advertir SIEMPRE al paciente consciente lo que sentirá durante 10 segundos.',
      'Reducir a la mitad la dosis (3 mg inicial) si toma dipiridamol, carbamazepina o trasplante cardíaco.',
      'Tener monitor de ECG imprimiendo continuamente.'
    ],
    flashcard: {
      pregunta: '¿Por qué la Adenosina requiere inyección en bolo ultrarrápido y arrastre con 20 mL de suero?',
      respuesta: 'Porque su semivida es menor a 10 segundos debido a la rápida recaptación y degradación endotelial/eritrocitaria. Si se administra lentamente, se metaboliza antes de llegar al corazón.',
      puntosClave: [
        'Dosis: 6 mg -> 12 mg.',
        'Usar vena antecubital proximal grande y llave de 3 vías.',
        'Contraindicada en asma severa.'
      ]
    }
  },

  // 4. AMIODARONA
  {
    id: 'amiodarona',
    nombre: 'Amiodarona',
    nombreComercial: 'Trangorex, Cordarone',
    clasificacion: 'Antiarrítmico de clase III (bloqueador de canales de K+)',
    categoria: 'antiarritmicos',
    presentacion: 'Ampolla 150 mg / 3 mL (50 mg/mL)',
    concentracion: '50 mg/mL',
    mgPorMl: 50,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 300, etiqueta: '1ª dosis paro FV/TVSP tras 3ª descarga' },
    dosisPresets: [
      { label: 'Paro FV/TVSP 1ª dosis (300 mg bolo)', doseVal: 300, unit: 'mg_fijo' },
      { label: 'Paro FV/TVSP 2ª dosis (150 mg bolo)', doseVal: 150, unit: 'mg_fijo' },
      { label: 'Taquicardia ventricular estable (150 mg en 10 min)', doseVal: 150, unit: 'mg_fijo' },
      { label: 'Paro pediátrico (5 mg/kg bolo)', doseVal: 5, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV', 'IO'],
    indicaciones: [
      'Paro cardiorrespiratorio por FV o TVSP refractaria a la 3ª descarga',
      'Taquicardia ventricular monomórfica estable con pulso',
      'Control de frecuencia y ritmo en taquiarritmias auriculares refractarias'
    ],
    contraindicaciones: [
      'Hipersensibilidad al yodo',
      'Bloqueo AV de 2º o 3º grado sin marcapasos',
      'Bradicardia severa sin marcapasos',
      'Prolongación del intervalo QT / Torsades de Pointes'
    ],
    dosis: {
      adulto: 'Paro: 300 mg bolo IV/IO (tras 3ª descarga); 2ª dosis 150 mg (tras 5ª descarga). Con pulso: 150 mg en 100 mL SG 5% en 10 min.',
      pediatrico: 'Paro: 5 mg/kg IV/IO (máx 300 mg).',
      formulaMgKg: 5,
      maxDose: 'Adulto paro: 450 mg acumulados. 24h: 2.2 g.',
      dilucionSugerida: 'En paro pasar directa. En paciente con pulso: diluir EXCLUSIVAMENTE en SG al 5% (precipita en SF).'
    },
    mecanismoAccion: {
      farmacodinamia: 'Bloquea canales de potasio prolongando la fase 3 del potencial de acción y el periodo refractario auricular y ventricular. Efectos accesorios de clase I, II y IV.',
      farmacocinetica: {
        inicio: 'Inmediato en paro; 15-30 min en infusión',
        pico: '1 a 2 horas',
        duracion: 'Horas a semanas (gran depósito tisular)',
        metabolismoSemivida: 'Hepático a desetilamiodarona. Semivida de eliminación extremadamente larga (20 a 100 días).'
      }
    },
    efectosSecundarios: ['Hipotensión arterial (por disolventes/polisorbato 80), bradicardia, náuseas, flebitis periférica.'],
    efectosAdversos: ['Prolongación severa de QT, Torsades de Pointes, colapso cardiocirculatorio, fibrosis pulmonar y tirotoxicosis (uso crónico).'],
    txSobredosis: 'Marcapasos transcutáneo si hay bradicardia o bloqueo, sulfato de magnesio si hay Torsades de Pointes, vasopresores.',
    riesgoEmbarazo: 'D',
    puntosImportantes: [
      'Diluir siempre en Dextrosa/Glucosa al 5% cuando se pase en infusión (precipita en suero salino fisiológico).',
      'En paciente con pulso, una infusión rápida provoca vasodilatación e hipotensión profunda.'
    ],
    flashcard: {
      pregunta: '¿Cuáles son las dosis de Amiodarona en el algoritmo de Paro Cardíaco ACLS en ritmos desfibrilables?',
      respuesta: 'Primera dosis: 300 mg IV/IO en bolo tras la 3ª descarga. Segunda dosis: 150 mg IV/IO en bolo tras la 5ª descarga.',
      puntosClave: [
        'Se administra durante el ciclo de RCP tras la descarga correspondiente.',
        'Alternativa: Lidocaína 1-1.5 mg/kg.',
        'Diluir en SG 5% si el paciente tiene pulso.'
      ]
    }
  },

  // 5. ATORVASTATINA
  {
    id: 'atorvastatina',
    nombre: 'Atorvastatina',
    nombreComercial: 'Lipitor, Cardyl, Zarator',
    clasificacion: 'Hipolipemiante, inhibidor de la HMG-CoA reductasa (Estatinas de alta potencia)',
    categoria: 'cardiovascular',
    presentacion: 'Comprimidos 20 mg, 40 mg y 80 mg',
    concentracion: '20 - 80 mg / comp',
    mgPorMl: 80,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 80, etiqueta: 'Dosis precoz de carga en SCA' },
    dosisPresets: [
      { label: 'SCA / IAM dosis de carga precoz (80 mg VO)', doseVal: 80, unit: 'mg_fijo' },
      { label: 'Prevención secundaria estándar (40 mg VO)', doseVal: 40, unit: 'mg_fijo' },
    ],
    viasAdministracion: ['VO (Oral)'],
    indicaciones: [
      'Tratamiento precoz intensivo del Síndrome Coronario Agudo (IAMCEST / SCASEST)',
      'Prevención secundaria tras ictus isquémico o AIT',
      'Dislipidemias severas'
    ],
    contraindicaciones: [
      'Hipersensibilidad a estatinas',
      'Enfermedad hepática activa o elevación persistente de transaminasas > 3 veces el límite normal',
      'Embarazo y lactancia'
    ],
    dosis: {
      adulto: '80 mg vía oral en dosis única precoz en las primeras 24 horas del SCA.',
      pediatrico: 'Uso excepcional en hipercolesterolemia familiar grave.',
      maxDose: '80 mg / 24h.',
      dilucionSugerida: 'Vía oral con agua.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Inhibe competitivamente la 3-hidroxi-3-metilglutaril-coenzima A (HMG-CoA) reductasa. En SCA posee efectos pleiotrópicos inmediatos: estabilización de la placa de ateroma, antiinflamatorio, antioxidante y mejora de la función endotelial.',
      farmacocinetica: {
        inicio: '1 a 2 horas (absorción oral)',
        pico: '1 a 2 horas',
        duracion: '24 horas',
        metabolismoSemivida: 'Metabolismo hepático por CYP3A4. Semivida plasmática: 14 horas; actividad inhibidora: 20-30 horas.'
      }
    },
    efectosSecundarios: ['Mialgias, molestias gastrointestinales, cefalea, elevación transitoria de transaminasas.'],
    efectosAdversos: ['Rabdomiólisis con insuficiencia renal aguda, hepatotoxicidad severa, miopatía necrotizante.'],
    txSobredosis: 'Lavado gástrico, soporte general, monitorización de CPK y función renal.',
    riesgoEmbarazo: 'X',
    puntosImportantes: [
      'El beneficio en el Código Infarto precoz se debe a la estabilización de la placa y efecto antiinflamatorio plaquetario endotelial.',
      'Contraindicación absoluta categoría X en el embarazo (teratogénica).'
    ],
    flashcard: {
      pregunta: '¿Por qué se administra una dosis alta de Atorvastatina (80 mg) en la fase aguda del Código Infarto?',
      respuesta: 'Por sus efectos pleiotrópicos tempranos: estabiliza la placa de ateroma rota, disminuye la inflamación endotelial aguda y previene nuevos eventos trombóticos a corto plazo.',
      puntosClave: [
        'Dosis aguda: 80 mg VO.',
        'Categoría X en embarazo.',
        'Se administra junto con la doble antiagregación.'
      ]
    }
  },

  // 6. ATROPINA
  {
    id: 'atropina',
    nombre: 'Atropina Sulfato',
    nombreComercial: 'Atropina',
    clasificacion: 'Anticolinérgico, parasimpaticolítico, antagonista muscarínico',
    categoria: 'resucitacion',
    presentacion: 'Ampolla 1 mg / 1 mL',
    concentracion: '1 mg/mL',
    mgPorMl: 1,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 1, etiqueta: 'Bolo IV rápido en bradicardia' },
    dosisPresets: [
      { label: 'Bradicardia sintomática adulto (1 mg IV cada 3-5 min)', doseVal: 1, unit: 'mg_fijo' },
      { label: 'Intoxicación organofosforados (2 a 5 mg IV repetible)', doseVal: 2, unit: 'mg_fijo' },
      { label: 'Bradicardia pediátrica (0.02 mg/kg IV, mín 0.1 mg)', doseVal: 0.02, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV', 'IO', 'IM', 'ET'],
    indicaciones: [
      'Bradicardia sinusal sintomática / inestable de primera línea',
      'Intoxicación por organofosforados y carbamatos (síndrome colinérgico)',
      'Premedicación en SRI pediátrico para prevenir bradicardia refleja'
    ],
    contraindicaciones: [
      'No efectiva en Bloqueo AV 2º Mobitz II ni Bloqueo AV 3º con QRS ancho o corazón trasplantado',
      'Glaucoma de ángulo cerrado (no demorar en bradicardia extrema)'
    ],
    dosis: {
      adulto: 'Bradicardia: 1 mg IV en bolo cada 3-5 min (máx 3 mg total). Organofosforados: 2 a 5 mg IV cada 5-10 min hasta signos de atropinización (secreciones secas).',
      pediatrico: '0.02 mg/kg IV/IO (dosis mínima 0.1 mg; máx dosis única 0.5 mg).',
      formulaMgKg: 0.02,
      maxDose: 'Adulto bradicardia: 3 mg acumulados.',
      dilucionSugerida: 'Bolo IV directo rápido.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Antagonista competitivo de receptores muscarínicos colinérgicos. Bloquea el estímulo del nervio vago sobre los nódulos SA y AV, acelerando la frecuencia cardíaca y disminuyendo secreciones bronquiales/salivales.',
      farmacocinetica: {
        inicio: '1 a 2 minutos IV',
        pico: '2 a 4 minutos',
        duracion: '2 a 4 horas',
        metabolismoSemivida: 'Hepático parcial (50%) y eliminación renal (50%). Semivida: 2 a 3 horas.'
      }
    },
    efectosSecundarios: ['Sequedad bucal, midriasis, visión borrosa, retención urinaria, taquicardia sinusal, rubor facial.'],
    efectosAdversos: ['Bradicardia paradójica (con dosis < 0.5 mg), arritmias ventriculares, delirium anticolinérgico, coma hipertermia.'],
    txSobredosis: 'Fisostigmina (1-2 mg IV lento) es el antídoto específico para toxicidad anticolinérgica severa.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'Dosis < 0.5 mg en adultos causan bradicardia paradójica por estimulación vagal central presináptica.',
      'Si 1 mg no revierte la inestabilidad, preparar de inmediato Marcapasos Transcutáneo (TCP) o infusión de Noradrenalina/Dopamina.'
    ],
    flashcard: {
      pregunta: '¿Cuál es la dosis máxima de Atropina en bradicardia según ACLS y por qué dosis menores a 0.5 mg están contraindicadas?',
      respuesta: 'Dosis máxima: 3 mg acumulados (alcanza el bloqueo vagal completo). Dosis < 0.5 mg producen bradicardia paradójica por estimulación colinérgica presináptica.',
      puntosClave: [
        'Dosis estándar actual ACLS: 1 mg bolo IV rápido.',
        'Mínimo en pediatría: 0.1 mg.',
        'Antídoto en organofosforados: titular hasta secar secreciones.'
      ]
    }
  },

  // 7. BICARBONATO DE SODIO
  {
    id: 'bicarbonato_sodio',
    nombre: 'Bicarbonato de Sodio 1 Molar (8.4%) o 1/6 M (1.4%)',
    nombreComercial: 'Bicarbonato Sódico 1M',
    clasificacion: 'Agente alcalinizante sistémico y urinario, electrolito',
    categoria: 'electrolitos',
    presentacion: 'Frasco ampolla 8.4% (1 Molar = 1 mEq/mL en 100 mL o 250 mL)',
    concentracion: '1 mEq/mL (8.4%)',
    mgPorMl: 84,
    dosisPorDefecto: { tipo: 'mg/kg', valor: 1, etiqueta: '1 mEq/kg IV bolo lento' },
    dosisPresets: [
      { label: 'Intoxicación por Antidepresivos Tricíclicos (1-2 mEq/kg)', doseVal: 1, unit: 'mg/kg' },
      { label: 'Hiperpotasemia grave con cambios ECG (1 mEq/kg)', doseVal: 1, unit: 'mg/kg' },
      { label: 'Acidosis metabólica refractaria en paro prolongado (1 mEq/kg)', doseVal: 1, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV estricta', 'IO'],
    indicaciones: [
      'Intoxicación por antidepresivos tricíclicos (QRS > 100 ms, onda R prominente en aVR)',
      'Hiperpotasemia severa con ensanchamiento de QRS',
      'Sobredosis por bloqueantes de canales de sodio (cocaína, anestésicos locales, flecainida)',
      'Acidosis láctica grave documentada (pH < 7.1) o paro prolongado con ventilación adecuada'
    ],
    contraindicaciones: [
      'Alcalosis metabólica o respiratoria',
      'Hipocalcemia severa previa (el bicarbonato reduce el calcio iónico libre)',
      'Hipernatremia severa'
    ],
    dosis: {
      adulto: '1 a 2 mEq/kg (o mL/kg de solución 8.4%) IV lento en 2-5 minutos. Titular hasta estrechamiento del QRS o pH 7.50-7.55.',
      pediatrico: '1 mEq/kg IV lento (en lactantes diluir al 4.2% con agua bidestilada 1:1 para evitar hiperosmolaridad y hemorragia intraventricular).',
      formulaMgKg: 1,
      maxDose: 'Guiado por gasometría y duración del QRS.',
      dilucionSugerida: 'Administrar por vía venosa exclusiva permeable. No mezclar con calcio ni catecolaminas (precipitan/inactivan).'
    },
    mecanismoAccion: {
      farmacodinamia: 'Aporta iones bicarbonato y sodio. Neutraliza protones extracelulares aumentando el pH sérico y aporta una sobrecarga de sodio extracelular que desplaza a los antidepresivos tricíclicos de los canales de sodio dependientes de voltaje en el miocardio.',
      farmacocinetica: {
        inicio: 'Inmediato (< 2 minutos)',
        pico: '5 minutos',
        duracion: '1 a 2 horas',
        metabolismoSemivida: 'Se disocia en sodio y bicarbonato; este se combina con H+ y se elimina como CO2 por pulmones y orina.'
      }
    },
    efectosSecundarios: ['Hipernatremia, hiperosmolaridad, hipopotasemia (introduce K+ a la célula), hipocalcemia con tetania.'],
    efectosAdversos: ['Alcalosis metabólica severa, necrosis tisular grave por extravasación, edema agudo de pulmón por sobrecarga salina, acidosis intracelular paradójica cerebral si la ventilación es insuficiente.'],
    txSobredosis: 'Suspensión inmediata, infusión de suero glucosado, corrección de hipopotasemia e hipocalcemia.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      '¡NUNCA mezclar en la misma vía con Gluconato de Calcio! Precipita carbonato de calcio sólido insoluble como yeso.',
      'Inactiva las catecolaminas (Adrenalina/Noradrenalina) si se pasan juntas en la misma línea.',
      'Genera gran cantidad de CO2: el paciente DEBE estar bien ventilado para no empeorar la acidosis intracelular.'
    ],
    flashcard: {
      pregunta: '¿Por qué el Bicarbonato de Sodio es el antídoto de elección en la intoxicación por Antidepresivos Tricíclicos (ATC)?',
      respuesta: 'Porque el aumento del pH sérico (7.50-7.55) disminuye la unión del fármaco al canal de sodio, y la sobrecarga de sodio (Na+) supera el bloqueo competitivo en el miocardio, estrechando el QRS y previniendo arritmias letales.',
      puntosClave: [
        'Indicación: QRS > 100 ms o R > 3 mm en aVR.',
        'Dosis: 1 a 2 mEq/kg IV bolo lento.',
        'No mezclar jamás con calcio ni catecolaminas.'
      ]
    }
  },

  // 8. BROMURO DE IPRATROPIO
  {
    id: 'bromuro_ipratropio',
    nombre: 'Bromuro de Ipratropio',
    nombreComercial: 'Atrovent',
    clasificacion: 'Broncodilatador anticolinérgico inhalatorio, derivado cuaternario de amonio',
    categoria: 'respiratorio',
    presentacion: 'Vial para nebulización 0.5 mg / 2 mL (0.25 mg/mL) o Inhalador 20 mcg/dosis',
    concentracion: '0.25 mg/mL',
    mgPorMl: 0.25,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 0.5, etiqueta: 'Nebulización combinada con salbutamol' },
    dosisPresets: [
      { label: 'Adulto crisis asma/EPOC (0.5 mg nebulizado)', doseVal: 0.5, unit: 'mg_fijo' },
      { label: 'Pediátrico crisis moderada-severa (0.25 - 0.5 mg neb)', doseVal: 0.25, unit: 'mg_fijo' },
    ],
    viasAdministracion: ['Inhalatoria / Nebulizada'],
    indicaciones: [
      'Crisis asmática moderada a grave (asociado a Salbutamol)',
      'Exacerbación aguda de Enfermedad Pulmonar Obstructiva Crónica (EPOC)'
    ],
    contraindicaciones: [
      'Hipersensibilidad al ipratropio o a la atropina',
      'Precaución en glaucoma de ángulo estrecho e hiperplasia prostática'
    ],
    dosis: {
      adulto: '0.5 mg (1 ampolla de 2 mL) nebulizado con 3 mL de SF junto con Salbutamol (2.5 - 5 mg) con O2 a 6-8 L/min cada 20 min (hasta 3 dosis en la 1ª hora).',
      pediatrico: '< 12 años: 0.25 mg; > 12 años: 0.5 mg nebulizado.',
      maxDose: '1.5 mg en la primera hora.',
      dilucionSugerida: 'Combinar en la misma cazoleta con Salbutamol completando a 4 mL con SF 0.9%.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Bloquea competitivamente los receptores muscarínicos M3 en el músculo liso bronquial, inhibiendo la broncoconstricción refleja mediada por el nervio vago y disminuyendo la secreción mucosa bronquial.',
      farmacocinetica: {
        inicio: '15 minutos',
        pico: '1 a 2 horas',
        duracion: '4 a 6 horas',
        metabolismoSemivida: 'Mínima absorción sistémica (< 10%). Semivida de eliminación: 1.6 horas.'
      }
    },
    efectosSecundarios: ['Sequedad bucal, sabor metálico amargo, tos irritativa leve, náuseas.'],
    efectosAdversos: ['Midriasis y empeoramiento de glaucoma si la mascarilla pierde aerosol sobre los ojos, retención urinaria, taquicardia paradójica.'],
    txSobredosis: 'Rarísima por absorción sistémica casi nula; soporte local.',
    riesgoEmbarazo: 'B',
    puntosImportantes: [
      'Asegurar buen sello de la mascarilla facial para evitar contacto ocular (puede inducir glaucoma agudo).',
      'Efecto sinérgico demostrado al asociarse a beta-2 agonistas en la primera hora de crisis severa.'
    ],
    flashcard: {
      pregunta: '¿Cuál es el principal beneficio de asociar Bromuro de Ipratropio a Salbutamol en la primera hora de una crisis asmática severa?',
      respuesta: 'Reduce significativamente la tasa de ingresos hospitalarios y mejora el VEF1 en un 15-20% adicional gracias a la broncodilatación por una vía farmacológica complementaria (bloqueo vagal M3 vs estimulación Beta-2).',
      puntosClave: [
        'Dosis adulto: 0.5 mg nebulizado.',
        'Proteger los ojos de la fuga de aerosol.',
        'Se mezcla en la misma cazoleta con salbutamol.'
      ]
    }
  },

  // 9. BUDESONIDA
  {
    id: 'budesonida',
    nombre: 'Budesonida',
    nombreComercial: 'Pulmicort',
    clasificacion: 'Glucocorticoide inhalado no halogenado',
    categoria: 'respiratorio',
    presentacion: 'Suspensión para nebulización 0.5 mg / 2 mL y 1 mg / 2 mL',
    concentracion: '0.5 mg/mL',
    mgPorMl: 0.5,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 2, etiqueta: 'Nebulización en laringotraqueítis o asma' },
    dosisPresets: [
      { label: 'Crup / Laringotraqueítis aguda pediátrica (2 mg nebulizado)', doseVal: 2, unit: 'mg_fijo' },
      { label: 'Crisis asmática aguda adulto (1 a 2 mg nebulizado)', doseVal: 1, unit: 'mg_fijo' },
    ],
    viasAdministracion: ['Inhalatoria / Nebulizada'],
    indicaciones: [
      'Crup laríngeo / Laringotraqueítis aguda infantil (estridor inspiratorio en reposo)',
      'Crisis asmática aguda como coadyuvante antiinflamatorio tópico de acción rápida'
    ],
    contraindicaciones: ['Hipersensibilidad a la budesonida'],
    dosis: {
      adulto: '1 a 2 mg nebulizado cada 12 horas.',
      pediatrico: 'Crup infantil: 2 mg nebulizado en dosis única con flujo de O2 a 6-8 L/min.',
      maxDose: '2 mg por dosis.',
      dilucionSugerida: 'Nebulizar con mascarilla facial bien ajustada.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Antiinflamatorio esteroideo tópico potente. Reduce el edema subglótico, la permeabilidad capilar y la migración celular inflamatoria en la mucosa laríngea y bronquial.',
      farmacocinetica: {
        inicio: '30 a 60 minutos',
        pico: '2 a 4 horas',
        duracion: '12 a 24 horas',
        metabolismoSemivida: 'Gran aclaramiento hepático de primer paso (90%). Semivida: 2 a 3 horas.'
      }
    },
    efectosSecundarios: ['Irritación faríngea, disfonía, tos, sabor amargo.'],
    efectosAdversos: ['Candidiasis orofaríngea (con uso prolongado), broncoespasmo paradójico raro.'],
    txSobredosis: 'Sin toxicidad aguda grave; soporte sintomático.',
    riesgoEmbarazo: 'B',
    puntosImportantes: [
      'En Crup infantil con estridor moderado a severo, la Budesonida 2 mg nebulizada combinada con Dexametasona oral/IM reduce drásticamente la necesidad de intubación.',
      'Enjuagar la boca con agua tras la nebulización si el paciente colabora.'
    ],
    flashcard: {
      pregunta: '¿Cuál es la indicación de rescate prehospitalario de la Budesonida nebulizada en pediatría?',
      respuesta: 'Laringotraqueítis aguda (Crup) con estridor inspiratorio de reposo a dosis de 2 mg nebulizados, para reducir rápidamente el edema subglótico.',
      puntosClave: [
        'Dosis: 2 mg nebulizados.',
        'Asociar con Dexametasona sistémica (0.6 mg/kg).',
        'Alternativa rápida si hay compromiso inminente: Adrenalina nebulizada.'
      ]
    }
  },

  // 10. BUPRENORFINA
  {
    id: 'buprenorfina',
    nombre: 'Buprenorfina',
    nombreComercial: 'Buprex, Transtec, Subutex',
    clasificacion: 'Opioide potente semisintético, agonista parcial de receptores mu y antagonista kappa',
    categoria: 'sedacion_analgesia',
    presentacion: 'Ampolla 0.3 mg / 1 mL (300 mcg/mL) o Comprimidos sublinguales 0.2 mg',
    concentracion: '0.3 mg/mL',
    mgPorMl: 0.3,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 0.3, etiqueta: 'IV lenta / IM en dolor severo' },
    dosisPresets: [
      { label: 'Analgesia dolor severo adulto (0.3 mg IV lento en 2 min)', doseVal: 0.3, unit: 'mg_fijo' },
      { label: 'Analgesia sublingual adulto (0.2 a 0.4 mg SL)', doseVal: 0.2, unit: 'mg_fijo' },
    ],
    viasAdministracion: ['IV lenta', 'IM', 'SL (Sublingual)'],
    indicaciones: [
      'Dolor agudo moderado a severo oncológico, traumatológico o postoperatorio refractario',
      'Alternativa a morfina con menor potencial de abuso y menor depresión respiratoria por "efecto techo"'
    ],
    contraindicaciones: [
      'Depresión respiratoria severa o asma bronquial aguda descompensada',
      'Uso concomitante o reciente de agonistas opioides puros (puede desencadenar síndrome de abstinencia agudo)',
      'Miastenia gravis e insuficiencia hepática severa'
    ],
    dosis: {
      adulto: '0.3 mg (1 ampolla) IV lenta en no menos de 2 minutos o IM cada 6 a 8 horas. Vía sublingual: 0.2 a 0.4 mg.',
      pediatrico: 'Uso no recomendado en menores de 12 años en el ámbito prehospitalario.',
      maxDose: '0.6 mg por dosis.',
      dilucionSugerida: 'Diluir en 10 mL de SF y administrar lentamente en 2-3 minutos.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Agonista parcial de receptores mu-opioides con afinidad extraordinariamente alta y lenta disociación, y antagonista de receptores kappa. Posee efecto analgésico potente (30 veces más que la morfina) con "efecto techo" para depresión respiratoria.',
      farmacocinetica: {
        inicio: '5 a 15 minutos IV; 15-30 min IM/SL',
        pico: '30 a 60 minutos',
        duracion: '6 a 8 horas',
        metabolismoSemivida: 'Hepático por CYP3A4 a norbuprenorfina. Semivida: 20 a 36 horas.'
      }
    },
    efectosSecundarios: ['Sedación, mareo, náuseas, vómitos, diaforesis, miosis, cefalea.'],
    efectosAdversos: ['Hipotensión ortostática, bradicardia, depresión respiratoria (difícil de revertir con naloxona por alta afinidad), alucinaciones.'],
    txSobredosis: 'Naloxona en dosis elevadas continuas (puede requerir 2 a 10 mg IV debido a la lenta disociación del receptor) y soporte ventilatorio invasivo si es necesario.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'Por su alta afinidad por el receptor mu, desplaza a otros opioides (morfina, fentanilo) y precipita abstinencia aguda en pacientes dependientes.',
      'La reversión con Naloxona es más difícil y requiere dosis mucho más altas de lo habitual.'
    ],
    flashcard: {
      pregunta: '¿Por qué la sobredosis o depresión respiratoria por Buprenorfina es más difícil de revertir con Naloxona que la de Morfina?',
      respuesta: 'Porque la Buprenorfina tiene una afinidad de unión al receptor mu-opioide extremadamente alta y una disociación muy lenta, por lo que requiere dosis masivas repetidas de Naloxona (hasta 10 mg) y ventilación asistida.',
      puntosClave: [
        'Agonista parcial de receptores mu (30 veces más potente que morfina).',
        'Posee efecto techo respiratorio.',
        'Desencadena abstinencia si se administra a pacientes con opioides puros.'
      ]
    }
  },

  // 11. CARBON ACTIVADO
  {
    id: 'carbon_activado',
    nombre: 'Carbón Activado',
    nombreComercial: 'Carbomix, Ultra Adsorb',
    clasificacion: 'Adsorbente gastrointestinal / Descontaminante toxicológico',
    categoria: 'antidotos',
    presentacion: 'Frasco / Botella suspensión 50 g en polvo o suspensión acuosa con sorbitol',
    concentracion: '50 g / frasco',
    mgPorMl: 250,
    dosisPorDefecto: { tipo: 'mg/kg', valor: 1000, etiqueta: '1 g/kg vía oral o por sonda nasogástrica' },
    dosisPresets: [
      { label: 'Adulto intoxicación aguda (50 a 100 g VO/SNG)', doseVal: 50000, unit: 'mg_fijo' },
      { label: 'Pediátrico intoxicación aguda (1 g/kg VO/SNG)', doseVal: 1000, unit: 'mg/kg' },
    ],
    viasAdministracion: ['VO (Oral)', 'SNG (Sonda Nasogástrica)'],
    indicaciones: [
      'Ingestión de tóxicos o sobredosis oral potencialmente mortal presentada dentro de la primera hora del evento',
      'Tóxicos con recirculación enterohepática (Carbamazepina, Dapsona, Fenobarbital, Quinina, Teofilina) en dosis múltiples'
    ],
    contraindicaciones: [
      'Vía aérea no protegida con deterioro de la conciencia (riesgo crítico de broncoaspiración mortal de carbón)',
      'Ingestión de cáusticos (ácidos o álcalis fuertes) o hidrocarburos (gasolina, queroseno)',
      'Sustancias NO adsorbidas: alcoholes (etanol, metanol), metales pesados (hierro, plomo), litio, potasio, flúor',
      'Íleo paralítico u obstrucción intestinal sospechada'
    ],
    dosis: {
      adulto: '50 a 100 g vía oral o por sonda nasogástrica suspendido en 200-300 mL de agua.',
      pediatrico: '1 g/kg (o 25 a 50 g en escolares; 10 a 25 g en lactantes).',
      formulaMgKg: 1000,
      maxDose: '100 g por dosis.',
      dilucionSugerida: 'Mezclar con agua o zumo de frutas. Si se asocia a sorbitol, no repetir para evitar diarrea osmótica e hipovolemia.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Material poroso con enorme área de superficie interna (1.000 m²/g) que adsorbe toxinas mediante fuerzas electrostáticas y de van der Waals en la luz gastrointestinal, impidiendo su absorción sistémica.',
      farmacocinetica: {
        inicio: 'Inmediato por contacto físico',
        pico: 'Inmediato',
        duracion: 'Hasta el tránsito intestinal completo',
        metabolismoSemivida: 'No se absorbe ni metaboliza. Se elimina íntegro en las heces tiñéndolas de negro.'
      }
    },
    efectosSecundarios: ['Heces negras, estreñimiento, vómitos, náuseas, sensación de plenitud.'],
    efectosAdversos: ['Neumonitis química y asfixia letal por broncoaspiración de carbón, obstrucción intestinal, diarrea osmótica severa si lleva sorbitol.'],
    txSobredosis: 'Laxantes suaves, hidratación.',
    riesgoEmbarazo: 'A',
    puntosImportantes: [
      '¡PELIGRO MORTAL!: La broncoaspiración de carbón activado destruye el parénquima pulmonar y tiene una mortalidad superior al 50%. Solo administrar si el paciente está plenamente alerta o con TET bien inflado.',
      'No sirve de nada en intoxicación por alcoholes, litio ni hierro.'
    ],
    flashcard: {
      pregunta: '¿Cuáles son las sustancias tóxicas que NO se adhieren al Carbón Activado y qué contraindicación absoluta tiene?',
      respuesta: 'No adsorbe: Alcoholes (metanol, etanol), Litio, Hierro, Potasio ni Cáusticos. Contraindicación absoluta: paciente con bajo nivel de conciencia sin vía aérea protegida (peligro letal de aspiración pulmonar).',
      puntosClave: [
        'Ventana terapéutica ideal: < 1 hora de la ingesta.',
        'Dosis: 1 g/kg (50-100 g en adultos).',
        'Tiñe las heces de negro.'
      ]
    }
  },

  // 12. CLOPIDOGREL
  {
    id: 'clopidogrel',
    nombre: 'Clopidogrel',
    nombreComercial: 'Plavix, Iscover',
    clasificacion: 'Antiagregante plaquetario, tienopiridina, inhibidor del receptor P2Y12',
    categoria: 'cardiovascular',
    presentacion: 'Comprimidos 75 mg y 300 mg',
    concentracion: '75 mg - 300 mg / comp',
    mgPorMl: 75,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 300, etiqueta: 'Dosis de carga SCA prehospitalaria' },
    dosisPresets: [
      { label: 'SCA carga para angioplastia / ICP (600 mg VO)', doseVal: 600, unit: 'mg_fijo' },
      { label: 'SCA carga estándar / Fibrinolisis ≤ 75 años (300 mg VO)', doseVal: 300, unit: 'mg_fijo' },
      { label: 'SCA en paciente > 75 años con fibrinolisis (75 mg VO)', doseVal: 75, unit: 'mg_fijo' },
    ],
    viasAdministracion: ['VO (Oral)'],
    indicaciones: [
      'Síndrome Coronario Agudo con o sin elevación del ST (doble antiagregación junto con ASA)',
      'Tratamiento adyuvante en fibrinolisis prehospitalaria o angioplastia primaria',
      'Ictus isquémico o arteriopatía periférica sintomática'
    ],
    contraindicaciones: [
      'Hemorragia patológica activa (úlcera péptica sangrante, hemorragia intracraneal)',
      'Hipersensibilidad grave al clopidogrel',
      'Insuficiencia hepática grave'
    ],
    dosis: {
      adulto: 'Dosis de carga en SCA: 300 a 600 mg VO (habitualmente 4 a 8 comprimidos de 75 mg o comprimidos de 300 mg). En pacientes > 75 años que recibirán fibrinolisis, omitir la carga e iniciar con 75 mg.',
      pediatrico: 'No indicado en pediatría.',
      maxDose: '600 mg de carga.',
      dilucionSugerida: 'Vía oral con agua.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Profármaco cuyo metabolito activo inhibe irreversiblemente el receptor P2Y12 del difosfato de adenosina (ADP) en las plaquetas, bloqueando la activación del complejo glucoproteico GPIIb/IIIa y la agregación plaquetaria.',
      farmacocinetica: {
        inicio: '2 horas (con dosis de carga de 600 mg); 4-6 h con 300 mg',
        pico: '2 a 4 horas',
        duracion: '7 a 10 días (vida media de la plaqueta)',
        metabolismoSemivida: 'Activación hepática en dos pasos por citocromo P450 (principalmente CYP2C19). Semivida del metabolito activo: 8 horas.'
      }
    },
    efectosSecundarios: ['Hematomas, epistaxis, dispepsia, dolor abdominal, diarrea.'],
    efectosAdversos: ['Hemorragia digestiva o intracraneal severa, púrpura trombocitopénica trombótica (PTT), neutropenia grave (rara).'],
    txSobredosis: 'Transfusión de concentrados de plaquetas para restaurar la hemostasia si hay hemorragia activa no controlada.',
    riesgoEmbarazo: 'B',
    puntosImportantes: [
      'En ancianos (> 75 años) tributarios de trombolisis farmacológica, NO se da dosis de carga (se dan solo 75 mg) por riesgo de hemorragia cerebral.',
      'Informar al equipo de hemodinamia de la dosis y hora de administración para la angioplastia coronaria.'
    ],
    flashcard: {
      pregunta: '¿Cuál es la dosis de carga de Clopidogrel en el IAMCEST antes de una angioplastia primaria vs en un paciente > 75 años con trombolisis?',
      respuesta: 'Para angioplastia primaria: 600 mg VO de carga. Para trombolisis en paciente mayor de 75 años: NO dar carga, administrar únicamente 75 mg VO para evitar hemorragia intracraneal.',
      puntosClave: [
        'Doble antiagregación estándar junto con ASA.',
        'Inhibidor irreversible del receptor P2Y12.',
        'Antídoto en hemorragia masiva: transfusión de plaquetas.'
      ]
    }
  },

  // 13. DEXAMETASONA
  {
    id: 'dexametasona',
    nombre: 'Dexametasona',
    nombreComercial: 'Fortecortin, Decadron',
    clasificacion: 'Glucocorticoide sintético de alta potencia y larga duración',
    categoria: 'antiinflamatorios',
    presentacion: 'Ampolla 4 mg / 1 mL y 8 mg / 2 mL (4 mg/mL)',
    concentracion: '4 mg/mL',
    mgPorMl: 4,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 8, etiqueta: 'Bolo IV/IM en asma/anafilaxia' },
    dosisPresets: [
      { label: 'Anafilaxia / Broncoespasmo severo adulto (8 mg IV/IM)', doseVal: 8, unit: 'mg_fijo' },
      { label: 'Crup / Laringitis pediátrica (0.6 mg/kg VO/IM/IV, máx 16 mg)', doseVal: 0.6, unit: 'mg/kg' },
      { label: 'Edema cerebral vasogénico / Hipertensión endocraneana (10 mg IV)', doseVal: 10, unit: 'mg_fijo' },
    ],
    viasAdministracion: ['IV', 'IM', 'VO'],
    indicaciones: [
      'Laringotraqueítis aguda (Crup) en pediatría (droga de elección)',
      'Anafilaxia grave y shock anafiláctico (para prevenir fase tardía/bifásica)',
      'Edema cerebral vasogénico por tumores o mal de montaña agudo',
      'Exacerbación asmática severa y COVID-19 con requerimiento de oxígeno'
    ],
    contraindicaciones: [
      'Infección fúngica sistémica no tratada',
      'Hipersensibilidad al fármaco'
    ],
    dosis: {
      adulto: '8 a 16 mg IV o IM en dosis única o cada 12-24 horas.',
      pediatrico: 'Crup infantil: 0.6 mg/kg VO, IM o IV en dosis única (máximo 16 mg). Dosis tan bajas como 0.15 mg/kg han demostrado similar eficacia en casos leves-moderados.',
      formulaMgKg: 0.6,
      maxDose: 'Adulto: 16-20 mg; Pediátrico Crup: 16 mg.',
      dilucionSugerida: 'Inyección directa IV lenta en 1-2 minutos o IM profunda.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Glucocorticoide puro sin actividad mineralocorticoide apreciable (no retiene sodio ni agua). Inhibe la síntesis de mediadores inflamatorios (citocinas, leucotrienos, prostaglandinas), estabiliza membranas lisosomales y reduce la permeabilidad endotelial.',
      farmacocinetica: {
        inicio: '1 a 2 horas (efecto genómico)',
        pico: '2 a 4 horas',
        duracion: '36 a 72 horas (larga duración)',
        metabolismoSemivida: 'Hepático. Semivida biológica tisular: 36 a 54 horas (semivida plasmática: 3-4 h).'
      }
    },
    efectosSecundarios: ['Sensación transitoria de prurito o quemazón perianal tras inyección IV rápida, hiperglucemia, insomnio.'],
    efectosAdversos: ['Infecciones oportunistas, retención gástrica, hemorragia digestiva alta, psicosis esteroidea (raro en dosis única).'],
    txSobredosis: 'Tratamiento de soporte y control glucémico.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'La inyección intravenosa rápida produce una sensación urente y desagradable de quemazón en el área genital y perineal: administrar lento.',
      'En Crup infantil tiene la ventaja de que una única dosis cubre todo el periodo agudo por su semivida de más de 36 horas.',
      'En anafilaxia NO sustituye a la Adrenalina; su rol es prevenir la respuesta bifásica a las 6-12 horas.'
    ],
    flashcard: {
      pregunta: '¿Cuál es el fármaco esteroideo de primera elección en el Crup infantil y cuál es su dosis?',
      respuesta: 'Dexametasona a dosis de 0.6 mg/kg (dosis única VO, IM o IV, máx 16 mg). Su larga duración de acción (36-72 h) cubre toda la fase inflamatoria crítica.',
      puntosClave: [
        'Dosis: 0.6 mg/kg (máx 16 mg).',
        'Administrar IV lento para evitar prurito perineal.',
        'Potencia antiinflamatoria 25 veces mayor que el cortisol sin retención de sodio.'
      ]
    }
  },

  // 14. DIFENHIDRAMINA
  {
    id: 'difenhidramina',
    nombre: 'Difenhidramina',
    nombreComercial: 'Benadryl',
    clasificacion: 'Antihistamínico de primera generación, bloqueador H1, anticolinérgico',
    categoria: 'antiinflamatorios',
    presentacion: 'Ampolla 50 mg / 1 mL (o 10 mg / 1 mL)',
    concentracion: '50 mg/mL',
    mgPorMl: 50,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 50, etiqueta: 'Bolo IV lento o IM' },
    dosisPresets: [
      { label: 'Adulto anafilaxia / urticaria aguda (25 a 50 mg IV lento)', doseVal: 50, unit: 'mg_fijo' },
      { label: 'Reacción extrapiramidal / distonía aguda (50 mg IV)', doseVal: 50, unit: 'mg_fijo' },
      { label: 'Pediátrico reacción alérgica (1 mg/kg IV/IM, máx 50 mg)', doseVal: 1, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV lenta', 'IM', 'VO'],
    indicaciones: [
      'Reacciones alérgicas agudas, urticaria y prurito severo',
      'Coadyuvante de segunda línea en anafilaxia (tras la adrenalina)',
      'Tratamiento de reacciones extrapiramidales agudas y distonías inducidas por antipsicóticos (ej. haloperidol) o metoclopramida'
    ],
    contraindicaciones: [
      'Crisis asmática aguda severa (espesa secreciones bronquiales por efecto anticolinérgico)',
      'Glaucoma de ángulo cerrado o hipertrofia prostática sintomática severa',
      'Prematuros y recién nacidos'
    ],
    dosis: {
      adulto: '25 a 50 mg IV lento en 2-3 minutos o IM profunda.',
      pediatrico: '1 mg/kg IV o IM (máximo 50 mg por dosis).',
      formulaMgKg: 1,
      maxDose: 'Adulto: 100 mg por dosis (máx 400 mg/día).',
      dilucionSugerida: 'Diluir 50 mg en 10 mL de SF y administrar en 2 a 3 minutos.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Antagonista competitivo de los receptores de histamina H1 a nivel periférico y central. Posee potentes propiedades anticolinérgicas (antimuscarínicas) centrales y sedantes.',
      farmacocinetica: {
        inicio: '15 a 30 minutos IV; 20-30 min IM',
        pico: '1 a 2 horas',
        duracion: '4 a 6 horas',
        metabolismoSemivida: 'Metabolismo hepático extenso. Semivida: 4 a 8 horas.'
      }
    },
    efectosSecundarios: ['Somnolencia profunda, sequedad de boca, visión borrosa, mareos, hipotensión leve.'],
    efectosAdversos: ['Retención urinaria, taquicardia sinusal, agitación paradójica en niños pequeños, arritmias ventriculares a dosis tóxicas.'],
    txSobredosis: 'Soporte cardiovascular, Bicarbonato de sodio si hay QRS ancho, Fisostigmina solo en delirium anticolinérgico extremo.',
    riesgoEmbarazo: 'B',
    puntosImportantes: [
      'NUNCA debe demorar la aplicación de Adrenalina en la anafilaxia: los antihistamínicos NO revierten el shock ni el edema laríngeo.',
      'Excelente fármaco para revertir crisis distónicas agudas causadas por Plasil / Metoclopramida o Haloperidol.'
    ],
    flashcard: {
      pregunta: '¿Para qué complicación neurológica aguda iatrogénica es de primera elección la Difenhidramina?',
      respuesta: 'Para las reacciones extrapiramidales agudas (distonías agudas, tortícolis espasmódica, crisis oculógiras) desencadenadas por fármacos como Metoclopramida o Haloperidol.',
      puntosClave: [
        'Dosis: 50 mg IV lento.',
        'En anafilaxia es de 2ª línea tras la adrenalina.',
        'Produce somnolencia significativa.'
      ]
    }
  },

  // 15. DOBUTAMINA
  {
    id: 'dobutamina',
    nombre: 'Dobutamina',
    nombreComercial: 'Dobutrex',
    clasificacion: 'Inótropo positivo sintético, agonista adrenérgico Beta-1 selectivo',
    categoria: 'vasoactivos',
    presentacion: 'Vial 250 mg / 20 mL (12.5 mg/mL)',
    concentracion: '12.5 mg/mL',
    mgPorMl: 12.5,
    dosisPorDefecto: { tipo: 'mcg/kg', valor: 5, etiqueta: '5 mcg/kg/min en infusión continua' },
    dosisPresets: [
      { label: 'Shock cardiogénico dosis baja (2.5 mcg/kg/min)', doseVal: 2.5, unit: 'mcg/kg' },
      { label: 'Dosis inotrópica estándar (5 a 10 mcg/kg/min)', doseVal: 5, unit: 'mcg/kg' },
      { label: 'Dosis máxima inotrópica (15 a 20 mcg/kg/min)', doseVal: 15, unit: 'mcg/kg' },
    ],
    viasAdministracion: ['IV en infusión continua', 'IO en infusión continua'],
    indicaciones: [
      'Shock cardiogénico con bajo gasto cardíaco y presiones de llenado elevadas (con TAS > 85-90 mmHg)',
      'Insuficiencia cardíaca congestiva descompensada severa refractaria a vasodilatadores'
    ],
    contraindicaciones: [
      'Estenosis subaórtica hipertrófica idiopática (MCH)',
      'Hipotensión arterial severa no corregida (TAS < 80 mmHg: requiere antes Noradrenalina)',
      'Feocromocitoma y taquiarritmias ventriculares activas'
    ],
    dosis: {
      adulto: '2.5 a 20 mcg/kg/min en infusión continua por bomba. Iniciar a 2.5-5 mcg/kg/min y titular según respuesta hemodinámica.',
      pediatrico: '2.5 a 15 mcg/kg/min.',
      formulaMcgKg: 5,
      maxDose: '20 mcg/kg/min (a dosis > 15 aumenta consumo de O2 y riesgo de taquiarritmias).',
      dilucionSugerida: '250 mg en 250 mL SG 5% o SF 0.9% (concentración = 1.000 mcg/mL = 1 mg/mL).'
    },
    mecanismoAccion: {
      farmacodinamia: 'Estimulación directa de receptores Beta-1 adrenérgicos miocárdicos, incrementando la contractilidad (inotropismo) y el volumen sistólico con menor taquicardia que el isoproterenol. Leve efecto Beta-2 y Alfa-1 vascular equilibrado que produce vasodilatación neta.',
      farmacocinetica: {
        inicio: '1 a 2 minutos',
        pico: '10 minutos',
        duracion: '10 minutos tras cesar infusión',
        metabolismoSemivida: 'Metabolismo hepático y tisular por COMT. Semivida plasmática: 2 minutos.'
      }
    },
    efectosSecundarios: ['Taquicardia, palpitaciones, cefalea, náuseas, angina de pecho.'],
    efectosAdversos: ['Taquiarritmias ventriculares (extrasístoles, TV), hipotensión arterial por vasodilatación Beta-2 en hipovolemia, isquemia miocárdica por aumento de MVO2.'],
    txSobredosis: 'Cese inmediato o reducción de la infusión continua; semivida corta de 2 minutos.',
    riesgoEmbarazo: 'B',
    puntosImportantes: [
      'Si el paciente está severamente hipotenso (TAS < 80-85 mmHg), la Dobutamina EMPEORARÁ la hipotensión por su efecto vasodilatador periférico. Se debe asociar antes a Noradrenalina.',
      'Aumenta el consumo miocárdico de oxígeno: precaución extrema en infarto agudo de miocardio activo.'
    ],
    flashcard: {
      pregunta: '¿Por qué la Dobutamina está contraindicada como monoterapia en el shock con hipotensión profunda (TAS < 80 mmHg)?',
      respuesta: 'Porque posee un efecto vasodilatador periférico mediado por receptores Beta-2 vasculares que puede provocar colapso tensional adicional; debe combinarse con un vasopresor (como Noradrenalina) para asegurar la presión de perfusión coronaria.',
      puntosClave: [
        'Dosis: 2.5 a 20 mcg/kg/min.',
        'Inótropo de elección en falla cardíaca con normo/hipertensión.',
        'Semivida: 2 minutos.'
      ]
    }
  },

  // 16. DIAZEPAM
  {
    id: 'diazepam',
    nombre: 'Diazepam',
    nombreComercial: 'Valium',
    clasificacion: 'Benzodiazepina de acción prolongada, anticonvulsivo, ansiolítico, miorrelajante',
    categoria: 'sedacion_analgesia',
    presentacion: 'Ampolla 10 mg / 2 mL (5 mg/mL) o Comprimidos 5 mg y 10 mg',
    concentracion: '5 mg/mL',
    mgPorMl: 5,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 10, etiqueta: 'Bolo IV lento en convulsiones' },
    dosisPresets: [
      { label: 'Estatus epiléptico adulto (10 mg IV lento a 2 mg/min)', doseVal: 10, unit: 'mg_fijo' },
      { label: 'Convulsión pediátrica rectal (0.5 mg/kg, máx 10 mg)', doseVal: 0.5, unit: 'mg/kg' },
      { label: 'Convulsión pediátrica IV (0.2 mg/kg IV lento)', doseVal: 0.2, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV lenta estricta', 'Rectal (canuleta)', 'VO'],
    indicaciones: [
      'Estatus epiléptico y crisis convulsivas activas prolongadas (> 5 min)',
      'Espasmos musculares severos (tétanos) y sedación de emergencia',
      'Agitación psicomotriz extrema por abstinencia alcohólica (delirium tremens)'
    ],
    contraindicaciones: [
      'Depresión respiratoria severa previa sin vía aérea avanzada',
      'Miastenia gravis y glaucoma de ángulo cerrado',
      'Insuficiencia respiratoria o hepática severa'
    ],
    dosis: {
      adulto: '5 a 10 mg IV lenta administrados a una velocidad máxima de 2 a 5 mg/min. Se puede repetir a los 10-15 min si persisten crisis (máx 30 mg).',
      pediatrico: '0.2 a 0.3 mg/kg IV lento o 0.5 mg/kg por vía rectal.',
      formulaMgKg: 0.2,
      maxDose: 'Adulto: 10 mg por dosis única (30 mg acumulados).',
      dilucionSugerida: 'Inyección IV lenta SIN diluir o diluida en 10 mL de SF. Precipita si se deja reposar en soluciones acuosas.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Modulador alostérico positivo del receptor GABA-A en el SNC. Incrementa la frecuencia de apertura de los canales de cloro, facilitando la hiperpolarización neuronal y frenando la actividad epiléptica.',
      farmacocinetica: {
        inicio: '1 a 3 minutos IV; 5-10 min rectal',
        pico: '5 minutos',
        duracion: 'Efecto anticonvulsivo 15-30 min (por rápida redistribución grasa); sedación hasta 24 h',
        metabolismoSemivida: 'Hepático a metabolitos activos (desmetildiazepam). Semivida: 20 a 50 horas (metabolito hasta 100 h).'
      }
    },
    efectosSecundarios: ['Sedación, ataxia, mareo, disartria, dolor en el sitio de inyección venosa (flebitis por propilenglicol).'],
    efectosAdversos: ['Depresión respiratoria y apnea (especialmente si se administra rápido o con opioides), hipotensión arterial, laringoespasmo.'],
    txSobredosis: 'Flumazenilo (0.2 mg IV en 30 s), con precaución extrema en pacientes epilépticos conocidos por riesgo de desencadenar estatus convulsivo intratable.',
    riesgoEmbarazo: 'D',
    puntosImportantes: [
      'La vía INTRAMUSCULAR NO SE RECOMIENDA: absorción errática, lenta y dolorosa. En ausencia de vía venosa, se prefiere la vía rectal o Midazolam IM/IN.',
      'Su efecto anticonvulsivo dura solo 15 a 30 minutos debido a la rápida redistribución a tejido graso, a pesar de que su semivida es de más de 24 horas.'
    ],
    flashcard: {
      pregunta: '¿Por qué NO se recomienda la vía Intramuscular para el Diazepam en emergencias prehospitalarias?',
      respuesta: 'Porque su absorción intramuscular es errática, muy lenta y produce dolor intenso y necrosis local por el vehículo de propilenglicol. Si no hay vía venosa, debe utilizarse Midazolam IM/IN o Diazepam rectal.',
      puntosClave: [
        'Dosis adulto: 10 mg IV lento (máx 2-5 mg/min).',
        'Duración anticonvulsiva corta (15-30 min) por redistribución.',
        'Antídoto: Flumazenilo.'
      ]
    }
  },

  // 17. EPINEFRINA (Adrenalina)
  {
    id: 'epinefrina',
    nombre: 'Epinefrina (Adrenalina)',
    nombreComercial: 'Adrenalin, Epipen, Jext',
    clasificacion: 'Agonista adrenérgico no selectivo (Alfa-1, Alfa-2, Beta-1, Beta-2), catecolamina endógena',
    categoria: 'resucitacion',
    presentacion: 'Ampolla 1 mg / 1 mL (1:1.000)',
    concentracion: '1 mg/mL',
    mgPorMl: 1,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 1, etiqueta: 'Paro cardíaco 1 mg IV/IO cada 3-5 min' },
    dosisPresets: [
      { label: 'Paro cardíaco adulto (1 mg IV/IO cada 3-5 min)', doseVal: 1, unit: 'mg_fijo' },
      { label: 'Anafilaxia adulto (0.5 mg IM cara lateral muslo)', doseVal: 0.5, unit: 'mg_fijo' },
      { label: 'Paro cardíaco pediátrico (0.01 mg/kg IV/IO 1:10.000)', doseVal: 0.01, unit: 'mg/kg' },
      { label: 'Anafilaxia pediátrica (0.01 mg/kg IM, máx 0.5 mg)', doseVal: 0.01, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV', 'IO', 'IM', 'Nebulizado', 'ET'],
    indicaciones: [
      'Paro cardiorrespiratorio en todos los ritmos (FV, TVSP, Asistolia, AESP)',
      'Anafilaxia grave y shock anafiláctico de primera elección imperativa',
      'Broncoespasmo potencialmente fatal refractario',
      'Bradicardia sintomática refractaria a atropina (en infusión continua)',
      'Crup laríngeo infantil grave (nebulizada)'
    ],
    contraindicaciones: [
      'Ninguna absoluta en paro cardiorrespiratorio ni en anafilaxia'
    ],
    dosis: {
      adulto: 'Paro: 1 mg IV/IO cada 3-5 min. Anafilaxia: 0.5 mg IM sin diluir en cara anterolateral del muslo. Infusión bradicardia/shock: 2 a 10 mcg/min.',
      pediatrico: 'Paro: 0.01 mg/kg IV/IO (0.1 mL/kg de dilución 1:10.000). Anafilaxia: 0.01 mg/kg IM (máx 0.5 mg).',
      formulaMgKg: 0.01,
      maxDose: 'Paro: Sin límite total. Anafilaxia: 0.5 mg por dosis IM.',
      dilucionSugerida: 'Para IV en paro: Diluir 1 mg en 9 mL de SF (1:10.000) y empujar con 20 mL de SF. Para infusión: 4 mg en 250 mL SG 5% (16 mcg/mL).'
    },
    mecanismoAccion: {
      farmacodinamia: 'Estimula receptores Alfa-1 (vasoconstricción periférica intensa que eleva presión de perfusión coronaria y cerebral), Beta-1 (inotropismo y cronotropismo positivos) y Beta-2 (broncodilatación y estabilización de mastocitos evitando liberación de histamina).',
      farmacocinetica: {
        inicio: 'Inmediato IV/IO; 3 a 5 min IM en muslo',
        pico: '1 a 2 min IV; 5-10 min IM',
        duracion: '5 a 10 minutos',
        metabolismoSemivida: 'Inactivación rápida por MAO y COMT en hígado y tejidos simpáticos. Semivida plasmática: 2 a 3 minutos.'
      }
    },
    efectosSecundarios: ['Palpitaciones, taquicardia sinusal, palidez, temblor fino, ansiedad, cefalea pulsátil.'],
    efectosAdversos: ['Arritmias ventriculares letales, crisis hipertensiva con hemorragia intracraneal, isquemia miocárdica/IAM, necrosis tisular periférica por extravasación.'],
    txSobredosis: 'Vasodilatadores de acción rápida (Nitroglicerina, Fentolamina, Nitroprusiato) y betabloqueantes.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'En anafilaxia, la vía es SIEMPRE IM en la cara anterolateral del muslo (vasto lateral): la absorción es significativamente más rápida que en el deltoides o vía SC.',
      'En paro cardiorrespiratorio no desfibrilable (Asistolia/AESP), administrar de inmediato tan pronto se tenga acceso IV/IO.',
      'En ritmos desfibrilables (FV/TVSP), administrar tras la 2ª descarga.'
    ],
    flashcard: {
      pregunta: '¿Cuál es la dosis y sitio anatómico de elección de la Epinefrina en la Anafilaxia grave en adultos?',
      respuesta: '0.5 mg IM (0.5 mL de la ampolla 1:1.000 sin diluir) inyectado en la cara ANTEROLATERAL DEL MUSLO (vasto lateral). Puede repetirse a los 5-15 minutos.',
      puntosClave: [
        'No diluir para administración IM.',
        'Vía anterolateral del muslo logra niveles plasmáticos pico mucho más rápidos que el brazo.',
        'La epinefrina es el único fármaco que reduce la mortalidad en anafilaxia.'
      ]
    }
  },

  // 18. ETOMIDATO
  {
    id: 'etomidato',
    nombre: 'Etomidato',
    nombreComercial: 'Hypnomidate',
    clasificacion: 'Anestésico intravenoso no barbitúrico, derivado carboxilado del imidazol',
    categoria: 'via_aerea',
    presentacion: 'Ampolla 20 mg / 10 mL (2 mg/mL)',
    concentracion: '2 mg/mL',
    mgPorMl: 2,
    dosisPorDefecto: { tipo: 'mg/kg', valor: 0.3, etiqueta: 'Inducción SRI (0.3 mg/kg IV)' },
    dosisPresets: [
      { label: 'Inducción SRI estándar (0.3 mg/kg IV)', doseVal: 0.3, unit: 'mg/kg' },
      { label: 'Inducción paciente anciano / frágil (0.15 a 0.2 mg/kg IV)', doseVal: 0.2, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV estricta'],
    indicaciones: [
      'Inductor hipnótico de elección para Secuencia Rápida de Intubación (SRI) en pacientes con inestabilidad hemodinámica, trauma severo o cardiopatía isquémica',
      'Sedación profunda para procedimientos breves (cardioversión urgente)'
    ],
    contraindicaciones: [
      'Hipersensibilidad al etomidato',
      'Insuficiencia suprarrenal aguda conocida',
      'Porfiria aguda'
    ],
    dosis: {
      adulto: '0.3 mg/kg IV en bolo directo en 30 a 60 segundos (habitualmente 1 ampolla de 20 mg en un adulto de 70 kg).',
      pediatrico: '0.3 mg/kg IV en niños > 2 años.',
      formulaMgKg: 0.3,
      maxDose: '0.3 mg/kg.',
      dilucionSugerida: 'Administrar en bolo IV directo sin diluir.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Modulador alostérico positivo de los receptores GABA-A. Produce pérdida rápida del conocimiento sin liberación de histamina y con mínima o nula repercusión sobre la contractilidad cardíaca, el gasto y la presión arterial.',
      farmacocinetica: {
        inicio: '30 a 60 segundos',
        pico: '1 minuto',
        duracion: '5 a 10 minutos',
        metabolismoSemivida: 'Hidrólisis hepática rápida por esterasas plasmáticas y hepáticas. Semivida: 2 a 5 horas.'
      }
    },
    efectosSecundarios: ['Mioclonías transitorias durante la inducción, dolor en el sitio de inyección (por propilenglicol), náuseas posprocedimiento.'],
    efectosAdversos: ['Supresión suprarrenal transitoria por inhibición reversible de la enzima 11-beta-hidroxilasa (bloquea la síntesis de cortisol por 24 h), apnea transitoria.'],
    txSobredosis: 'Soporte de vía aérea y ventilación asistida hasta el cese de su efecto.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'Es el fármaco inductor con mayor estabilidad cardiovascular junto con la ketamina (ideal en trauma e hipotensión).',
      'Produce mioclonías benignas que pueden confundirse con convulsiones: se previenen con la administración del relajante neuromuscular.',
      'Su uso en infusión continua está PROHIBIDO por inducir insuficiencia suprarrenal mortal.'
    ],
    flashcard: {
      pregunta: '¿Cuál es la principal ventaja hemodinámica del Etomidato en la Secuencia Rápida de Intubación?',
      respuesta: 'Excelente estabilidad hemodinámica: no deprime la contractilidad miocárdica ni reduce las resistencias vasculares periféricas, manteniendo la presión arterial intacta incluso en pacientes críticos.',
      puntosClave: [
        'Dosis: 0.3 mg/kg IV bolo.',
        'Inhibe temporalmente la 11-beta-hidroxilasa suprarrenal.',
        'Nunca usar en infusión continua.'
      ]
    }
  },

  // 19. FENITOINA
  {
    id: 'fenitoina',
    nombre: 'Fenitoína (Difenilhidantoína)',
    nombreComercial: 'Epamin, Dilantin',
    clasificacion: 'Antiepiléptico de segunda línea, antiarrítmico de clase IB',
    categoria: 'neurologico',
    presentacion: 'Ampolla 250 mg / 5 mL (50 mg/mL)',
    concentracion: '50 mg/mL',
    mgPorMl: 50,
    dosisPorDefecto: { tipo: 'mg/kg', valor: 20, etiqueta: '20 mg/kg IV en infusión lenta' },
    dosisPresets: [
      { label: 'Estatus epiléptico carga (20 mg/kg IV en SF a máx 50 mg/min)', doseVal: 20, unit: 'mg/kg' },
      { label: 'Dosis pediátrica estatus (20 mg/kg IV a máx 1 mg/kg/min)', doseVal: 20, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV en infusión lenta estricta (filtro recomendado)'],
    indicaciones: [
      'Estatus epiléptico convulsivo refractario a benzodiazepinas (Fase 2 de rescate)',
      'Profilaxis de crisis en traumatismo craneoencefálico grave o neurocirugía',
      'Arritmias ventriculares por intoxicación por digitálicos'
    ],
    contraindicaciones: [
      'Bloqueo auriculoventricular de 2º o 3º grado, bradicardia sinusal severa',
      'Síndrome del seno enfermo',
      'Hipersensibilidad a hidantoínas'
    ],
    dosis: {
      adulto: 'Dosis de carga: 20 mg/kg IV en 100 mL de Solución Fisiológica a pasar a una velocidad MÁXIMA de 50 mg/min (suele durar 20-30 min) con monitorización continua de ECG.',
      pediatrico: '20 mg/kg IV a velocidad máxima de 1 mg/kg/min.',
      formulaMgKg: 20,
      maxDose: 'Velocidad máxima: 50 mg/minuto en adultos.',
      dilucionSugerida: 'Diluir EXCLUSIVAMENTE en Solución Fisiológica 0.9% (precipita de inmediato en Dextrosa/Glucosa) y administrar con filtro en línea.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Bloqueador dependiente de voltaje y frecuencia de los canales de sodio neuronales. Prolonga el periodo de inactivación del canal, evitando la descarga repetitiva de potenciales de acción de alta frecuencia.',
      farmacocinetica: {
        inicio: '20 a 30 minutos (tras finalizar la infusión)',
        pico: '1 a 2 horas',
        duracion: '24 horas',
        metabolismoSemivida: 'Metabolismo hepático saturable (cinética de Michaelis-Menten / orden cero a niveles terapéuticos). Semivida: 12 a 36 horas.'
      }
    },
    efectosSecundarios: ['Ataxia, mareo, nistagmo, náuseas, somnolencia, flebitis intensa en el sitio de punción.'],
    efectosAdversos: ['Hipotensión arterial severa y asistolia/paro cardíaco por infusión rápida (debido al propilenglicol), síndrome del guante morado (necrosis isquémica de extremidad por extravasación), Stevens-Johnson.'],
    txSobredosis: 'Soporte hemodinámico, carbón activado, hemodiálisis no es muy eficaz por alta unión a proteínas (90%).',
    riesgoEmbarazo: 'D',
    puntosImportantes: [
      '¡REGLAS CRÍTICAS DE SEGURIDAD!: Nunca infundir a más de 50 mg/min (induce arritmias letales e hipotensión severa).',
      'Nunca mezclar con suero glucosado (cristaliza y precipita de inmediato).',
      'Verificar retorno venoso absoluto para evitar el Síndrome del Guante Morado (necrosis tisular grave).'
    ],
    flashcard: {
      pregunta: '¿Cuáles son las dos precauciones de oro indispensables al administrar Fenitoína IV?',
      respuesta: '1) Diluir SOLO en Solución Fisiológica (en glucosa precipita). 2) No sobrepasar la velocidad de 50 mg/min y monitorizar ECG continuo por riesgo de arritmias mortales e hipotensión.',
      puntosClave: [
        'Dosis de carga: 20 mg/kg.',
        'Extravasación causa "Síndrome del Guante Morado".',
        'Alternativa moderna más segura: Levetiracetam (Keppra).'
      ]
    }
  },

  // 20. FENTANILO
  {
    id: 'fentanilo',
    nombre: 'Fentanilo',
    nombreComercial: 'Fentanest, Sublimaze',
    clasificacion: 'Opioide sintético potente de acción ultracorta (derivado de la fenilpiperidina)',
    categoria: 'sedacion_analgesia',
    presentacion: 'Ampolla 150 mcg / 3 mL y 500 mcg / 10 mL (50 mcg/mL = 0.05 mg/mL)',
    concentracion: '50 mcg/mL',
    mgPorMl: 0.05,
    dosisPorDefecto: { tipo: 'mcg/kg', valor: 1, etiqueta: '1 mcg/kg IV lento en analgesia aguda' },
    dosisPresets: [
      { label: 'Analgesia aguda moderada-severa (1 mcg/kg IV lento)', doseVal: 1, unit: 'mcg/kg' },
      { label: 'Pretratamiento SRI en TEC / disección (2 a 3 mcg/kg IV)', doseVal: 2, unit: 'mcg/kg' },
      { label: 'Analgesia intranasal con atomizador (1.5 mcg/kg IN)', doseVal: 1.5, unit: 'mcg/kg' },
    ],
    viasAdministracion: ['IV lenta', 'IO', 'IN (Intranasal con atomizador MAD)', 'IM'],
    indicaciones: [
      'Dolor agudo moderado a severo (politrauma, síndrome coronario agudo, quemaduras, fracturas)',
      'Pretratamiento en SRI para atenuar la descarga simpática (aumento de PIC y PA)',
      'Analgesia y sedación en paciente bajo ventilación mecánica'
    ],
    contraindicaciones: [
      'Depresión respiratoria grave sin soporte de vía aérea disponible',
      'Hipersensibilidad a opiáceos',
      'Uso simultáneo con inhibidores de la MAO'
    ],
    dosis: {
      adulto: 'Analgesia: 1 a 2 mcg/kg IV lento (50 a 100 mcg inicial) cada 30-60 min. Intranasal: 1.5 a 2 mcg/kg. Pretratamiento SRI: 2 a 3 mcg/kg IV.',
      pediatrico: '1 a 2 mcg/kg IV o IN.',
      formulaMcgKg: 1,
      maxDose: 'Titular según dolor; en bolo rápido > 5 mcg/kg riesgo de rigidez de la pared torácica.',
      dilucionSugerida: 'Inyección lenta en 1-2 minutos. Puede diluirse en 10 mL de SF.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Agonista potente y selectivo de receptores mu-opioides (100 veces más potente que la morfina). Gran liposolubilidad que facilita el paso rápido a la barrera hematoencefálica.',
      farmacocinetica: {
        inicio: '1 a 2 minutos IV; 5-10 min IN',
        pico: '3 a 5 minutos',
        duracion: '30 a 60 minutos',
        metabolismoSemivida: 'Metabolismo hepático por CYP3A4 a norfentanilo inactivo. Semivida de eliminación: 2 a 4 horas (pero acción clínica corta por redistribución).'
      }
    },
    efectosSecundarios: ['Sedación, náuseas, vómitos, mareo, bradicardia leve, miosis punziforme.'],
    efectosAdversos: ['Depresión respiratoria profunda, apnea, síndrome de tórax leñoso (rigidez muscular torácica aguda que impide la ventilación si se pasa en bolo rápido), hipotensión.'],
    txSobredosis: 'Naloxona 0.04 a 0.4 mg IV o 2 a 4 mg IN; si hay tórax leñoso refractario: relajante neuromuscular (rocuronio/succinilcolina) e intubación.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'Mayor estabilidad hemodinámica y menor liberación de histamina que la morfina (menos hipotensión).',
      'Administrar SIEMPRE lentamente en 1 a 2 minutos para prevenir el tórax de madera (rigidez muscular).',
      'La vía intranasal (MAD) es ideal para dolor severo en pediatría y rescate sin vía venosa.'
    ],
    flashcard: {
      pregunta: '¿Qué es el síndrome de "tórax leñoso" inducido por Fentanilo y cómo se previene?',
      respuesta: 'Es una rigidez muscular masiva de los músculos torácicos e intercostales y cuerdas vocales que imposibilita ventilar con bolsa-mascarilla, inducida por la inyección intravenosa rápida de fentanilo. Se previene inyectando lentamente en 1-2 minutos.',
      puntosClave: [
        'Potencia 100 veces mayor a la morfina.',
        'Inicio: 1-2 minutos, duración: 30-60 min.',
        'Antídoto: Naloxona.'
      ]
    }
  },

  // 21. FLUMAZENIL
  {
    id: 'flumazenil',
    nombre: 'Flumazenil',
    nombreComercial: 'Anexate',
    clasificacion: 'Antagonista específico de los receptores de benzodiazepinas (derivado de imidazobenzodiazepina)',
    categoria: 'antidotos',
    presentacion: 'Ampolla 0.5 mg / 5 mL (0.1 mg/mL) y 1 mg / 10 mL',
    concentracion: '0.1 mg/mL',
    mgPorMl: 0.1,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 0.2, etiqueta: '0.2 mg IV en 30 s' },
    dosisPresets: [
      { label: 'Reversión sedación adulto (0.2 mg IV en 30 s, repetir 0.1 mg/min)', doseVal: 0.2, unit: 'mg_fijo' },
      { label: 'Sobredosis severa comatosa (0.2 mg IV cada minuto hasta máx 1-3 mg)', doseVal: 0.2, unit: 'mg_fijo' },
      { label: 'Pediátrico reversión (0.01 mg/kg IV en 15 s, máx 0.2 mg)', doseVal: 0.01, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV lenta estricta'],
    indicaciones: [
      'Reversión completa o parcial de la sedación inducida por benzodiazepinas en procedimientos diagnósticos',
      'Diagnóstico y tratamiento de sobredosis pura de benzodiazepinas con depresión respiratoria'
    ],
    contraindicaciones: [
      'Pacientes con antecedentes de EPILEPSIA o tratamiento crónico con benzodiazepinas (desencadena convulsiones incontrolables)',
      'Sospecha de intoxicación mixta con ANTIDEPRESIVOS TRICÍCLICOS o fármacos proconvulsivantes (induce paro cardíaco y convulsiones mortales)',
      'Hipertensión intracraneal severa'
    ],
    dosis: {
      adulto: '0.2 mg IV administrados en 30 segundos. Si no hay respuesta en 60 segundos, administrar 0.1 mg cada minuto hasta un máximo de 1 mg (raramente 3 mg).',
      pediatrico: '0.01 mg/kg IV (máx 0.2 mg inicial).',
      formulaMgKg: 0.01,
      maxDose: 'Adulto: 1 mg en sedación habitual; 3 mg en intoxicación masiva.',
      dilucionSugerida: 'Inyección IV directa en bolo lento.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Antagonista competitivo puro que bloquea específicamente el sitio de unión de las benzodiazepinas en el complejo receptor GABA-A en el SNC.',
      farmacocinetica: {
        inicio: '1 a 2 minutos',
        pico: '3 minutos',
        duracion: '45 a 90 minutos (menor que la de casi todas las benzodiazepinas)',
        metabolismoSemivida: 'Hepático rápido. Semivida plasmática: 40 a 80 minutos.'
      }
    },
    efectosSecundarios: ['Náuseas, vómitos, mareo, ansiedad, diaforesis, cefalea, rubor.'],
    efectosAdversos: ['Convulsiones de difícil control (en epilépticos o dependientes crónicos), arritmias cardíacas en intoxicaciones mixtas, síndrome de abstinencia agudo severo.'],
    txSobredosis: 'No suele causar toxicidad directa propia.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      '¡ALERTA!: La semivida del flumazenil (45-60 min) es MENOR que la del midazolam o diazepam. El paciente puede "resedarse" y volver a entrar en coma y apnea tras 1 hora. Vigilancia continua obligatoria.',
      'En sobredosis comatosa no diferenciada, suele ser más seguro asegurar la vía aérea y ventilar que arriesgarse a convulsiones intratables por flumazenil.'
    ],
    flashcard: {
      pregunta: '¿Por qué el Flumazenil está contraindicado en la sobredosis de causa desconocida o en consumidores crónicos de benzodiazepinas?',
      respuesta: 'Porque puede desencadenar un estatus epiléptico incontrolable y letal al bloquear bruscamente el freno GABAérgico, o desencadenar arritmias ventriculares si hay consumo simultáneo de antidepresivos tricíclicos.',
      puntosClave: [
        'Semivida más corta que las benzodiazepinas (riesgo de resedación).',
        'Dosis inicial: 0.2 mg IV en 30 segundos.',
        'Priorizar soporte de vía aérea y ventilación.'
      ]
    }
  },

  // 22. GLUCONATO DE CALCIO
  {
    id: 'gluconato_calcio',
    nombre: 'Gluconato de Calcio al 10%',
    nombreComercial: 'Gluconato Cálcico 10%',
    clasificacion: 'Sal de calcio, estabilizador de membrana miocárdica, electrolito',
    categoria: 'electrolitos',
    presentacion: 'Ampolla 1 g (1.000 mg) / 10 mL (100 mg/mL al 10% = 4.65 mEq Ca2+)',
    concentracion: '100 mg/mL',
    mgPorMl: 100,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 1000, etiqueta: '1 g (10 mL) IV lento en 5-10 min' },
    dosisPresets: [
      { label: 'Hiperpotasemia con cambios ECG / QRS ancho (1 a 2 g IV)', doseVal: 1000, unit: 'mg_fijo' },
      { label: 'Intoxicación por Calcioantagonistas (1 a 3 g IV lento)', doseVal: 2000, unit: 'mg_fijo' },
      { label: 'Pediátrico hiperpotasemia / hipocalcemia (60 a 100 mg/kg IV)', doseVal: 60, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV lenta estricta', 'IO'],
    indicaciones: [
      'Hiperpotasemia severa con alteraciones electrocardiográficas (ondas T picudas, pérdida de P, QRS ancho, ritmo sinoventricular)',
      'Intoxicación por bloqueantes de los canales de calcio (calcioantagonistas)',
      'Toxicidad severa por Sulfato de Magnesio (abolición de reflejos, depresión respiratoria)',
      'Hipocalcemia sintomática aguda con tetania o convulsiones'
    ],
    contraindicaciones: [
      'Hipercalcemia',
      'Toxicidad digitálica previa (la administración rápida de calcio puede precipitar arritmias ventriculares mortales por "efecto sinérgico")',
      'Fibrilación ventricular (salvo hiperpotasemia causante)'
    ],
    dosis: {
      adulto: '1 a 2 g (10 a 20 mL de solución al 10%) IV lento en 5 a 10 minutos con monitorización electrocardiográfica continua. Puede repetirse a los 5-10 min si persisten cambios en el ECG.',
      pediatrico: '60 a 100 mg/kg (0.6 a 1 mL/kg de solución al 10%) IV lento (máx 1.000 mg).',
      formulaMgKg: 60,
      maxDose: 'Adulto: 3 g por episodio agudo.',
      dilucionSugerida: 'Administrar sin diluir o en 50-100 mL de SF a pasar en 5-10 min. ¡NUNCA administrar por vía IM o SC!'
    },
    mecanismoAccion: {
      farmacodinamia: 'Estabiliza el potencial de membrana de las células miocárdicas. En hiperpotasemia, la elevación de calcio restaura la diferencia fisiológica entre el potencial de membrana en reposo y el umbral de despolarización, revirtiendo el ensanchamiento del QRS en minutos (NO baja los niveles séricos de potasio).',
      farmacocinetica: {
        inicio: '1 a 3 minutos',
        pico: '5 minutos',
        duracion: '30 a 60 minutos',
        metabolismoSemivida: 'Se incorpora al reservorio óseo y se excreta por riñón y heces.'
      }
    },
    efectosSecundarios: ['Sensación de calor corporal difuso, sabor calcáreo/metálico, vasodilatación transitoria.'],
    efectosAdversos: ['Bradicardia severa y paro cardíaco si se inyecta rápido, necrosis química y calcificación tisular si se extravasa.'],
    txSobredosis: 'Hipercalcemia: hidratación salina agresiva y furosemida.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      '¡NO BAJA EL POTASIO!: Solo protege el corazón de arritmias letales durante 30-60 minutos. Se deben administrar simultáneamente medidas que metan el potasio a la célula (Salbutamol, Insulina + Glucosa) o lo eliminen.',
      'El gluconato de calcio causa mucho menos daño tisular por extravasación que el cloruro de calcio, siendo la sal de elección en vías periféricas.',
      '¡NUNCA mezclar con Bicarbonato de Sodio en la misma vía!'
    ],
    flashcard: {
      pregunta: '¿Cuál es el mecanismo de acción del Gluconato de Calcio en la hiperpotasemia grave con QRS ensanchado?',
      respuesta: 'Estabiliza la membrana miocárdica restaurando el umbral de excitabilidad eléctrica y previniendo la parada cardíaca en 2-3 minutos. NO reduce los niveles séricos de potasio en sangre.',
      puntosClave: [
        'Dosis: 1 a 2 gramos IV en 5-10 min.',
        'Duración del efecto protector: 30 a 60 minutos.',
        'Nunca mezclar con Bicarbonato de Sodio.'
      ]
    }
  },

  // 23. GLUCOSA (Dextrosa 10% / 50%)
  {
    id: 'glucosa',
    nombre: 'Glucosa / Dextrosa (10% y 50%)',
    nombreComercial: 'Glucosmon, Dextrosa 10% y 50%',
    clasificacion: 'Carbohidrato simple, monosacárido, agente hipertónico',
    categoria: 'resucitacion',
    presentacion: 'Dextrosa al 10% (Bolsa 250 o 500 mL = 50 g) y Dextrosa al 50% (Ampolla 10 g / 20 mL o 50 g / 100 mL)',
    concentracion: '100 mg/mL (10%) o 500 mg/mL (50%)',
    mgPorMl: 100,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 15000, etiqueta: '150 mL D10W (15 g glucosa)' },
    dosisPresets: [
      { label: 'Adulto Dextrosa 10% (150 a 200 mL IV rápido)', doseVal: 15000, unit: 'mg_fijo' },
      { label: 'Adulto Dextrosa 50% (25 a 50 mL IV lento comprobado)', doseVal: 25000, unit: 'mg_fijo' },
      { label: 'Pediátrico Dextrosa 10% (2 a 5 mL/kg IV lento)', doseVal: 200, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV estricta periférica gruesa o central'],
    indicaciones: [
      'Hipoglucemia sintomática aguda (< 60 mg/dL o < 3.3 mmol/L) con alteración del estado mental o coma',
      'Coadyuvante con insulina en el tratamiento de la hiperpotasemia grave'
    ],
    contraindicaciones: [
      'Ninguna en hipoglucemia confirmada',
      'Extravasación tisular (la D50W produce necrosis tisular masiva por alta osmolaridad)'
    ],
    dosis: {
      adulto: '150 a 200 mL de Dextrosa al 10% (15 a 20 g de glucosa) IV rápida. Alternativa: 25 a 50 mL de Dextrosa al 50% IV lenta comprobando retorno venoso.',
      pediatrico: '¡NUNCA usar D50W en pediatría! Administrar Dextrosa al 10% a 2 a 5 mL/kg IV lento.',
      formulaMgKg: 200,
      maxDose: 'Titular según glucemia capilar cada 10-15 min.',
      dilucionSugerida: 'Se prefiere la Dextrosa al 10% sobre la del 50% por mayor seguridad endotelial y menor riesgo de rebote.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Sustrato metabólico energético primario del cerebro y tejidos dependientes de glucosa. Restaura la glucemia plasmática revirtiendo el déficit neurológico en minutos.',
      farmacocinetica: {
        inicio: '1 a 2 minutos',
        pico: '5 minutos',
        duracion: '30 a 60 minutos',
        metabolismoSemivida: 'Metabolismo celular completo a dióxido de carbono y agua.'
      }
    },
    efectosSecundarios: ['Sensación de calor, dolor en la vena de inyección.'],
    efectosAdversos: ['Necrosis tisular grave y esfacelo por extravasación de D50W, hiperglucemia de rebote extrema, tromboflebitis.'],
    txSobredosis: 'Hidratación, insulina si hiperglucemia extrema.',
    riesgoEmbarazo: 'A',
    puntosImportantes: [
      'En alcohólicos crónicos o desnutridos graves, administrar Tiamina (Vitamina B1) 100 mg IV antes o junto con la glucosa para prevenir la Encefalopatía de Wernicke aguda.',
      'Comprobar retorno venoso de sangre abundante antes de empujar D50W.',
      'En pediatría está PROSCRITA la Dextrosa al 50% (usar siempre D10W).'
    ],
    flashcard: {
      pregunta: '¿Por qué las directrices actuales prefieren Dextrosa al 10% frente a la Dextrosa al 50% en hipoglucemia?',
      respuesta: 'Porque la Dextrosa al 10% (150-200 mL) aporta la misma cantidad de gramos de glucosa (15-20 g) con osmolaridad mucho menor, eliminando el riesgo de necrosis por extravasación, tromboflebitis y rebotes hiperglucémicos severos.',
      puntosClave: [
        'Dosis adulto: 150 a 200 mL de D10W.',
        'En pediatría: 2 a 5 mL/kg de D10W.',
        'Administrar Tiamina 100 mg en desnutridos/alcohólicos.'
      ]
    }
  },

  // 24. HIDRALAZINA
  {
    id: 'hidralazina',
    nombre: 'Hidralazina',
    nombreComercial: 'Hydrapres, Apresoline',
    clasificacion: 'Vasodilatador periférico directo arteriolar',
    categoria: 'cardiovascular',
    presentacion: 'Ampolla 20 mg / 1 mL (20 mg/mL)',
    concentracion: '20 mg/mL',
    mgPorMl: 20,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 5, etiqueta: '5 a 10 mg IV lento en 2 min' },
    dosisPresets: [
      { label: 'Crisis hipertensiva en preeclampsia/eclampsia (5 a 10 mg IV lento)', doseVal: 5, unit: 'mg_fijo' },
      { label: 'Crisis hipertensiva adulto estándar (10 a 20 mg IV)', doseVal: 10, unit: 'mg_fijo' },
    ],
    viasAdministracion: ['IV lenta estricta', 'IM'],
    indicaciones: [
      'Emergencia hipertensiva en el embarazo: Preeclampsia severa y Eclampsia de primera línea',
      'Crisis hipertensivas con daño de órgano diana (cuando otros vasodilatadores no están disponibles)'
    ],
    contraindicaciones: [
      'Lupus eritematoso sistémico idiopático',
      'Disección aórtica aguda (la taquicardia refleja y fuerza de cizallamiento agravan la disección)',
      'Cardiopatía isquémica severa o estenosis mitral/aórtica grave'
    ],
    dosis: {
      adulto: '5 a 10 mg IV lento en 2 minutos. Si la presión arterial no desciende en 20 minutos, repetir 5 a 10 mg (máx 20-30 mg). Objetivo: mantener TAD entre 90 y 100 mmHg para preservar la perfusión uteroplacentaria.',
      pediatrico: '0.1 a 0.2 mg/kg IV lento cada 4 a 6 horas.',
      maxDose: '20 mg por dosis única IV.',
      dilucionSugerida: 'Diluir la ampolla de 20 mg en 19 mL de SF (1 mg/mL) y administrar 5 a 10 mL lentamente en 2 minutos.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Vasodilatador arterial directo selectivo sobre el músculo liso de las arteriolas de resistencia, mediado por apertura de canales de K+ y reducción del calcio intracelular. No afecta las vénulas de capacitancia (no reduce la precarga).',
      farmacocinetica: {
        inicio: '5 a 20 minutos IV',
        pico: '20 a 30 minutos',
        duracion: '2 a 6 horas',
        metabolismoSemivida: 'Metabolismo hepático por acetilación (acetiladores lentos tienen mayor efecto). Semivida: 2 a 3 horas.'
      }
    },
    efectosSecundarios: ['Taquicardia refleja marcada, cefalea intensa, rubor facial, palpitaciones, náuseas.'],
    efectosAdversos: ['Hipotensión brusca con compromiso de perfusión fetal, angina de pecho, síndrome lúpico inducido por fármacos (uso crónico).'],
    txSobredosis: 'Fluidos intravenosos y vasopresores alfa puros (fenilefrina/noradrenalina); betabloqueantes para la taquicardia refleja.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'Fármaco de elección histórico para emergencias hipertensivas en preeclampsia/eclampsia.',
      'Esperar al menos 20 minutos antes de repetir la dosis para evitar hipotensión acumulativa que desnutra la placenta.',
      'Contraindicado en sospecha de disección aórtica por la taquicardia y aumento de contractilidad refleja.'
    ],
    flashcard: {
      pregunta: '¿Cuál es la principal indicación obstétrica de la Hidralazina IV en medicina prehospitalaria?',
      respuesta: 'Emergencia hipertensiva en Preeclampsia severa o Eclampsia, a dosis de 5 a 10 mg IV lento, buscando mantener la presión arterial diastólica entre 90 y 100 mmHg sin comprometer la perfusión placentaria.',
      puntosClave: [
        'Dosis: 5 a 10 mg IV lento.',
        'Esperar 20 min antes de repetir.',
        'Contraindicada en disección aórtica por taquicardia refleja.'
      ]
    }
  },

  // 25. HIDROCORTISONA
  {
    id: 'hidrocortisona',
    nombre: 'Hidrocortisona (Fosfato / Succinato Sódico)',
    nombreComercial: 'Actocortina, Solu-Cortef',
    clasificacion: 'Glucocorticoide y mineralocorticoide sistémico de acción rápida de origen natural',
    categoria: 'antiinflamatorios',
    presentacion: 'Vial 100 mg y 500 mg liofilizado con disolvente',
    concentracion: '100 mg / 2 mL',
    mgPorMl: 50,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 200, etiqueta: '100 a 200 mg IV bolo en shock/anafilaxia' },
    dosisPresets: [
      { label: 'Anafilaxia / Crisis asmática adulto (100 a 200 mg IV)', doseVal: 200, unit: 'mg_fijo' },
      { label: 'Crisis suprarrenal aguda / Shock refractario (100 a 200 mg IV)', doseVal: 100, unit: 'mg_fijo' },
      { label: 'Pediátrico anafilaxia / asma (2 a 4 mg/kg IV)', doseVal: 4, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV', 'IM'],
    indicaciones: [
      'Shock anafiláctico y anafilaxia grave (segunda línea tras adrenalina para evitar respuesta bifásica)',
      'Crisis de insuficiencia suprarrenal aguda (Addisoniana) con shock refractario a vasopresores',
      'Crisis asmática severa y estatus asmático'
    ],
    contraindicaciones: [
      'Infecciones micóticas sistémicas no tratadas',
      'Hipersensibilidad al fármaco'
    ],
    dosis: {
      adulto: '100 a 200 mg IV en bolo lento en 2-3 minutos o IM.',
      pediatrico: '2 a 4 mg/kg IV o IM (máximo 100 mg).',
      formulaMgKg: 4,
      maxDose: 'Adulto: 500 mg en shock extremo.',
      dilucionSugerida: 'Reconstituir con su ampolla disolvente y pasar en bolo lento.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Glucocorticoide natural idéntico al cortisol. Posee actividad antiinflamatoria, inmunosupresora y mineralocorticoide (retiene sodio y agua, eleva la presión arterial). Restaura la sensibilidad vascular a las catecolaminas endógenas y exógenas.',
      farmacocinetica: {
        inicio: '1 hora (efectos genómicos)',
        pico: '2 a 4 horas',
        duracion: '8 a 12 horas',
        metabolismoSemivida: 'Hepático. Semivida plasmática: 90 minutos; semivida biológica tisular: 8 a 12 horas.'
      }
    },
    efectosSecundarios: ['Hiperglucemia transitoria, retención hidrosalina leve, ardor en sitio de inyección.'],
    efectosAdversos: ['Hemorragia digestiva, hipertensión arterial, psicosis esteroidea aguda (raro en dosis única).'],
    txSobredosis: 'Soporte sintomático.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'Fármaco de elección absoluto en la CRISIS SUPRARRENAL AGUDA (enfermedad de Addison descompensada o retirada brusca de corticoides crónicos con shock refractario).',
      'En anafilaxia es de segunda línea: nunca debe administrarse antes ni en sustitución de la Adrenalina IM.'
    ],
    flashcard: {
      pregunta: '¿Cuál es la indicación crítica de la Hidrocortisona en un paciente con shock refractario a vasopresores y antecedentes de uso crónico de esteroides?',
      respuesta: 'Crisis suprarrenal aguda por atrofia adrenal secundaria. Se administra Hidrocortisona 100 a 200 mg IV en bolo para restaurar el tono vascular y la sensibilidad de los receptores a las catecolaminas.',
      puntosClave: [
        'Dosis: 100 a 200 mg IV.',
        'Posee efecto mineralocorticoide que ayuda a retener volumen.',
        'En anafilaxia no reemplaza a la adrenalina.'
      ]
    }
  },

  // 26. KETAMINA
  {
    id: 'ketamina',
    nombre: 'Ketamina',
    nombreComercial: 'Ketolar',
    clasificacion: 'Anestésico disociativo, antagonista del receptor NMDA, broncodilatador',
    categoria: 'sedacion_analgesia',
    presentacion: 'Vial 500 mg / 10 mL (50 mg/mL)',
    concentracion: '50 mg/mL',
    mgPorMl: 50,
    dosisPorDefecto: { tipo: 'mg/kg', valor: 1.5, etiqueta: 'Inducción SRI (1.5 mg/kg IV)' },
    dosisPresets: [
      { label: 'Inducción SRI estándar (1.5 a 2 mg/kg IV)', doseVal: 1.5, unit: 'mg/kg' },
      { label: 'Inducción SRI en shock profundo (0.75 a 1.0 mg/kg IV)', doseVal: 1.0, unit: 'mg/kg' },
      { label: 'Analgesia subdisociativa (0.2 a 0.3 mg/kg IV en 15 min)', doseVal: 0.25, unit: 'mg/kg' },
      { label: 'Agitación psicomotriz extrema / Delirium (4 a 5 mg/kg IM)', doseVal: 4, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV', 'IO', 'IM', 'IN'],
    indicaciones: [
      'Inducción de elección para SRI en shock séptico, trauma y broncoespasmo severo',
      'Analgesia subdisociativa en politraumatismo y atrapamientos',
      'Control de agitación psicomotriz extrema y delirium excitado',
      'Broncodilatador de rescate en estatus asmático potencialmente fatal'
    ],
    contraindicaciones: [
      'Emergencia hipertensiva severa / Sospecha de disección aórtica (aumenta tono simpático)',
      'Hipersensibilidad al fármaco'
    ],
    dosis: {
      adulto: 'Inducción SRI: 1.5 a 2 mg/kg IV (4-5 mg/kg IM). Analgesia subdisociativa: 0.2 a 0.3 mg/kg IV en 10-15 min (o 0.5 mg/kg IN). Agitación extrema: 4 a 5 mg/kg IM.',
      pediatrico: 'Inducción SRI: 1.5 a 2 mg/kg IV. Analgesia: 0.25 mg/kg IV o 0.5 mg/kg IN.',
      formulaMgKg: 1.5,
      maxDose: 'Guiado por peso.',
      dilucionSugerida: 'Para analgesia: diluir 25-50 mg en 100 mL SF y pasar en 15 min para evitar disforia.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Bloqueo no competitivo de receptores N-metil-D-aspartato (NMDA) en el SNC. Desconecta funcionalmente el córtex límbico de la conciencia (anestesia disociativa) y estimula la liberación simpática endógena indirecta que preserva la presión arterial.',
      farmacocinetica: {
        inicio: '30 a 60 segundos IV; 3 a 5 min IM/IN',
        pico: '1 a 2 minutos',
        duracion: '10 a 20 minutos (redistribución rápida)',
        metabolismoSemivida: 'Hepático por CYP3A4 a norketamina (activo). Semivida: 2 a 3 horas.'
      }
    },
    efectosSecundarios: ['Sialorrea (aumento de secreciones salivales), nistagmo, taquicardia, hipertensión leve, diplopía.'],
    efectosAdversos: ['Reacciones de emergencia/disforia alucinatoria al despertar, laringoespasmo raro (con bolos rápidos), hipotensión paradójica en shock descompensado con catecolaminas agotadas.'],
    txSobredosis: 'Soporte ventilatorio y benzodiazepinas (Midazolam) para controlar disforia o alucinaciones.',
    riesgoEmbarazo: 'B',
    puntosImportantes: [
      'Inductor de elección para intubación en el paciente en shock (no produce vasodilatación a diferencia del propofol).',
      'Potente broncodilatador directo por relajación del músculo liso bronquial.',
      'Preserva el impulso respiratorio a dosis analgésicas subdisociativas.'
    ],
    flashcard: {
      pregunta: '¿Por qué la Ketamina es el fármaco ideal en la Secuencia Rápida de Intubación de un paciente con shock y asma severa?',
      respuesta: 'Porque mantiene la presión arterial y el gasto cardíaco estimulando el tono simpático endógeno, y al mismo tiempo produce una potente broncodilatación por relajación directa del músculo liso bronquial.',
      puntosClave: [
        'Dosis inducción: 1.5 a 2 mg/kg IV.',
        'Dosis analgesia: 0.2 a 0.3 mg/kg IV.',
        'Manejo de agitación extrema: 4 a 5 mg/kg IM.'
      ]
    }
  },

  // 27. KETOROLACO
  {
    id: 'ketorolaco',
    nombre: 'Ketorolaco Trometamol',
    nombreComercial: 'Toradol, Droal',
    clasificacion: 'AINE no esteroideo potente, derivado del ácido pirrolizina-carboxílico',
    categoria: 'antiinflamatorios',
    presentacion: 'Ampolla 30 mg / 1 mL',
    concentracion: '30 mg/mL',
    mgPorMl: 30,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 30, etiqueta: '30 mg IV/IM en dolor cólico/agudo' },
    dosisPresets: [
      { label: 'Adulto cólico nefrítico / dolor agudo (30 mg IV/IM)', doseVal: 30, unit: 'mg_fijo' },
      { label: 'Adulto > 65 años o < 50 kg (15 mg IV/IM)', doseVal: 15, unit: 'mg_fijo' },
      { label: 'Pediátrico analgesia (0.5 mg/kg IV/IM, máx 30 mg)', doseVal: 0.5, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV', 'IM'],
    indicaciones: [
      'Dolor agudo moderado a severo (cólico nefrítico/ureteral de primera línea)',
      'Dolor osteomuscular agudo o traumatológico sin sangrado activo',
      'Dolor postoperatorio'
    ],
    contraindicaciones: [
      'Úlcera péptica activa o antecedente de hemorragia digestiva',
      'Insuficiencia renal moderada a grave o hipovolemia/deshidratación severa',
      'Sospecha de hemorragia activa o diátesis hemorrágica (politrauma con shock, TCE)',
      'Tercer trimestre del embarazo (cierre prematuro del ductus arterioso)'
    ],
    dosis: {
      adulto: '30 mg IV o IM en dosis única (15 mg si edad > 65 años, peso < 50 kg o creatinina elevada). Máximo 60-90 mg/día durante máximo 2 a 5 días.',
      pediatrico: '0.5 mg/kg IV o IM (máximo 15-30 mg).',
      formulaMgKg: 0.5,
      maxDose: 'Adulto dosis única: 30 mg IV; ancianos: 15 mg.',
      dilucionSugerida: 'Administrar IV en no menos de 1 a 2 minutos o diluido en 50-100 mL de SF.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Inhibidor no selectivo de las ciclooxigenasas COX-1 y COX-2, bloqueando la síntesis de prostaglandinas inflamatorias y mediadoras del dolor. En cólico renal reduce la presión intraluminal ureteral.',
      farmacocinetica: {
        inicio: '10 minutos IV; 20-30 min IM',
        pico: '30 a 60 minutos',
        duracion: '4 a 6 horas',
        metabolismoSemivida: 'Hepático parcial y eliminación renal (90%). Semivida plasmática: 4 a 6 horas.'
      }
    },
    efectosSecundarios: ['Dispepsia, náuseas, dolor epigástrico, mareo, somnolencia, dolor en el sitio IM.'],
    efectosAdversos: ['Insuficiencia renal aguda (especialmente en hipovolemia por vasoconstricción de la arteriola aferente), hemorragia digestiva, broncoespasmo en asmáticos.'],
    txSobredosis: 'Carbón activado, soporte renal con hidratación y protección gástrica.',
    riesgoEmbarazo: 'D',
    puntosImportantes: [
      'Fármaco analgésico de primera línea en el CÓLICO NEFRÍTICO (alivia el espasmo ureteral mejor que los opioides).',
      '¡NO usar en politrauma con sospecha de sangrado interno o hemorragia intracraneal! Altera la coagulación plaquetaria.',
      'Peligro de fallo renal agudo en pacientes deshidratados.'
    ],
    flashcard: {
      pregunta: '¿Por qué el Ketorolaco es el analgésico de elección en el Cólico Nefrítico sobre los opioides y en qué pacientes está contraindicado?',
      respuesta: 'Porque inhibe las prostaglandinas que median el espasmo del músculo liso ureteral y reducen la presión intrapélvica renal. Está contraindicado en insuficiencia renal, deshidratación/hipovolemia y hemorragia activa o trauma severo.',
      puntosClave: [
        'Dosis: 30 mg IV (15 mg en ancianos).',
        'Primera línea en cólico ureteral.',
        'Peligro de daño renal en pacientes hipovolémicos.'
      ]
    }
  },

  // 28. LIDOCAINA
  {
    id: 'lidocaina',
    nombre: 'Lidocaína al 1% o 2%',
    nombreComercial: 'Xylocaína',
    clasificacion: 'Antiarrítmico de clase IB, anestésico local tipo amida',
    categoria: 'antiarritmicos',
    presentacion: 'Ampolla al 1% (10 mg/mL) o 2% (20 mg/mL = 200 mg / 10 mL)',
    concentracion: '20 mg/mL (al 2%)',
    mgPorMl: 20,
    dosisPorDefecto: { tipo: 'mg/kg', valor: 1.5, etiqueta: '1 a 1.5 mg/kg IV en paro o anestesia local' },
    dosisPresets: [
      { label: 'Paro FV/TVSP refractario 1ª dosis (1 a 1.5 mg/kg IV)', doseVal: 1.5, unit: 'mg/kg' },
      { label: 'Paro FV/TVSP 2ª dosis (0.5 a 0.75 mg/kg IV)', doseVal: 0.75, unit: 'mg/kg' },
      { label: 'Anestesia para acceso intraóseo EZ-IO despierto (40 mg IO lento)', doseVal: 40, unit: 'mg_fijo' },
    ],
    viasAdministracion: ['IV', 'IO', 'Infiltración Local', 'ET'],
    indicaciones: [
      'Paro cardiorrespiratorio por FV o TVSP refractaria a desfibrilación (alternativa de igual nivel a la Amiodarona)',
      'Taquicardia ventricular monomórfica con pulso hemodinámicamente estable',
      'Anestesia del espacio medular óseo para infusión por acceso intraóseo (IO) en pacientes conscientes',
      'Anestesia local por infiltración para suturas y procedimientos'
    ],
    contraindicaciones: [
      'Bloqueo AV de 2º o 3º grado sin marcapasos',
      'Hipersensibilidad a anestésicos locales tipo amida',
      'Toxicidad severa por anestésicos locales'
    ],
    dosis: {
      adulto: 'Paro: 1 a 1.5 mg/kg IV/IO en bolo inicial; dosis posteriores de 0.5 a 0.75 mg/kg cada 5-10 min hasta un máximo acumulado de 3 mg/kg. Anestesia IO: 40 mg (2 mL al 2%) administrados lentamente en 2 minutos.',
      pediatrico: 'Paro: 1 mg/kg IV/IO (máx 100 mg).',
      formulaMgKg: 1.5,
      maxDose: '3 mg/kg acumulados.',
      dilucionSugerida: 'Bolo IV directo.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Bloqueador de los canales de sodio dependientes de voltaje en estado inactivo y abierto, acortando la duración del potencial de acción y el periodo refractario de las fibras de Purkinje y tejido ventricular isquémico, suprimiendo la automaticidad anormal.',
      farmacocinetica: {
        inicio: '1 a 2 minutos',
        pico: '3 a 5 minutos',
        duracion: '10 a 20 minutos',
        metabolismoSemivida: 'Metabolismo hepático extenso por CYP1A2 y CYP3A4 a MEGX (activo). Semivida: 1.5 a 2 horas.'
      }
    },
    efectosSecundarios: ['Sabor metálico, acúfenos, mareos, parestesias peribucales, somnolencia, visión borrosa.'],
    efectosAdversos: ['Toxicidad por anestésicos locales (LAST): convulsiones tónico-clónicas, coma, depresión respiratoria, bradicardia extrema, colapso cardiovascular.'],
    txSobredosis: 'Antídoto específico para toxicidad por anestésicos locales: Emulsión Lipídica al 20% (Intralipid: bolo inicial de 1.5 mL/kg en 1 min + infusión de 0.25 mL/kg/min).',
    riesgoEmbarazo: 'B',
    puntosImportantes: [
      'Las guías ACLS actuales sitúan a la Lidocaína al mismo nivel de recomendación que la Amiodarona en el paro cardíaco por FV/TV refractaria.',
      'En accesos intraóseos colocados en pacientes conscientes, la infusión de líquidos causa dolor insoportable: pasar 40 mg de lidocaína al 2% IO lento en 2 minutos antes de perfundir fluidos.',
      'Antídoto de toxicidad: Terapia de rescate con emulsión lipídica al 20% (Lipid Rescue).'
    ],
    flashcard: {
      pregunta: '¿Cuál es el antídoto específico para la toxicidad sistémica por anestésicos locales (LAST) inducida por Lidocaína?',
      respuesta: 'Emulsión Lipídica intravenosa al 20% (Intralipid). Se administra un bolo de 1.5 mL/kg en 1 minuto seguido de infusión a 0.25 mL/kg/min para atrapar la droga liposoluble ("trampa lipídica").',
      puntosClave: [
        'Dosis en paro: 1 a 1.5 mg/kg IV inicial.',
        'Máximo total acumulado: 3 mg/kg.',
        'Anestesia intraósea: 40 mg IO lento antes de pasar fluidos.'
      ]
    }
  },

  // 29. METOXIFLURANO
  {
    id: 'metoxiflurano',
    nombre: 'Metoxiflurano',
    nombreComercial: 'Penthrox ("El Silbato Verde")',
    clasificacion: 'Analgésico inhalatorio volátil, hidrocarburo halogenado fluorado',
    categoria: 'sedacion_analgesia',
    presentacion: 'Inhalador verde precargado de un solo uso con vial de 3 mL',
    concentracion: '3 mL de líquido volátil / inhalador',
    mgPorMl: 1000,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 3, etiqueta: '1 frasco de 3 mL inhalado por el paciente' },
    dosisPresets: [
      { label: 'Dosis inicial adulto dolor moderado-grave (3 mL inhalados)', doseVal: 3, unit: 'mg_fijo' },
      { label: 'Segunda dosis adulto consecutiva si dolor persiste (3 mL)', doseVal: 3, unit: 'mg_fijo' },
    ],
    viasAdministracion: ['Inhalatoria autoadministrada por el paciente mediante dispositivo Penthrox'],
    indicaciones: [
      'Alivio rápido del dolor moderado a grave en pacientes con traumatismo agudo consciente (fracturas, luxaciones, quemaduras, rescate)'
    ],
    contraindicaciones: [
      'Hipersensibilidad conocida a anestésicos halogenados',
      'Antecedente personal o familiar de Hipertermia Maligna',
      'Insuficiencia renal significativa o antecedentes de daño renal',
      'Alteración del nivel de conciencia o incapacidad para sostener el dispositivo',
      'Inestabilidad cardiovascular grave o depresión respiratoria'
    ],
    dosis: {
      adulto: '1 frasco de 3 mL vertido en el inhalador Penthrox. El paciente inhala a demanda a través de la boquilla (dura 20-25 minutos). Puede administrarse un segundo frasco de 3 mL si es necesario (máximo 6 mL por día y 15 mL por semana).',
      pediatrico: 'En niños colaboradores > 6 años: 3 mL en dosis única.',
      maxDose: '6 mL en 24 horas (máx 15 mL a la semana por riesgo de nefrotoxicidad fluorada).',
      dilucionSugerida: 'Sin diluir. Verter los 3 mL en la base del silbato con la cámara de carbón activado acoplada.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Vapor anestésico inhalatorio halogenado que a dosis subanestésicas bajas ejerce una potente acción analgésica mediante modulación de receptores GABA-A y glicina en el tálamo y médula espinal.',
      farmacocinetica: {
        inicio: '6 a 8 respiraciones (1 a 2 minutos)',
        pico: '3 a 5 minutos',
        duracion: '20 a 30 minutos por frasco (cesa a los 5 min de soltar el silbato)',
        metabolismoSemivida: 'Metabolismo hepático por CYP2E1 liberando iones fluoruro inorgánicos. Excreción pulmonar (inalterado) y renal.'
      }
    },
    efectosSecundarios: ['Mareo, euforia leve, somnolencia, náuseas, tos, sabor dulzón, sequedad bucal.'],
    efectosAdversos: ['Nefrotoxicidad dependiente de la dosis acumulada (insuficiencia renal por fluoruros), hepatotoxicidad, hipertermia maligna.'],
    txSobredosis: 'Retirar el dispositivo; el efecto se elimina rápidamente por la respiración.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'Autoadministrado: el propio paciente sostiene el inhalador. Si el paciente se duerme o seda demasiado, su mano cae y deja de inhalar, lo que garantiza una excelente seguridad.',
      'Tapar el orificio de dilución con el dedo incrementa la concentración de vapor y la potencia analgésica.',
      'No sobrepasar los 6 mL diarios para evitar el daño renal por fluoruro libre.'
    ],
    flashcard: {
      pregunta: '¿Por qué el Metoxiflurano (Penthrox) es especialmente seguro para el manejo prehospitalario del dolor traumático agudo?',
      respuesta: 'Porque es autoadministrado por el propio paciente sosteniendo el "silbato": si el paciente entra en sedación excesiva, la mano cae, la boquilla se aparta de la boca y la inhalación se interrumpe de forma natural e inmediata.',
      puntosClave: [
        'Inicio en 6-8 respiraciones.',
        'Dosis máxima: 6 mL en 24 horas.',
        'Contraindicado en hipertermia maligna e insuficiencia renal.'
      ]
    }
  },

  // 30. MIDAZOLAM
  {
    id: 'midazolam',
    nombre: 'Midazolam',
    nombreComercial: 'Dormicum, Versed',
    clasificacion: 'Benzodiazepina de acción corta, anillo imidazólico hidrosoluble',
    categoria: 'sedacion_analgesia',
    presentacion: 'Ampolla 5 mg / 5 mL (1 mg/mL) o 15 mg / 3 mL (5 mg/mL) y 50 mg / 10 mL',
    concentracion: '1 mg/mL o 5 mg/mL',
    mgPorMl: 1,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 10, etiqueta: '10 mg IM/IN en convulsiones activas' },
    dosisPresets: [
      { label: 'Estatus epiléptico sin vía (10 mg IM o IN con MAD)', doseVal: 10, unit: 'mg_fijo' },
      { label: 'Estatus epiléptico con vía venosa (0.1 mg/kg IV lento)', doseVal: 0.1, unit: 'mg/kg' },
      { label: 'Sedación para cardioversión / TCP (2 a 5 mg IV)', doseVal: 2.5, unit: 'mg_fijo' },
      { label: 'Inducción SRI (0.2 a 0.3 mg/kg IV)', doseVal: 0.2, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV', 'IO', 'IM', 'IN (Intranasal con atomizador MAD)', 'Rectal', 'VO'],
    indicaciones: [
      'Estatus epiléptico y crisis convulsivas prolongadas (> 5 min) de primera línea prehospitalaria',
      'Sedación consciente o profunda para cardioversión eléctrica sincronizada o marcapasos transcutáneo',
      'Inducción y sedación continua en Secuencia Rápida de Intubación y ventilación mecánica',
      'Agitación psicomotriz severa'
    ],
    contraindicaciones: [
      'Shock descompensado o hipotensión severa (disminuye la resistencia vascular sistémica)',
      'Insuficiencia respiratoria aguda sin soporte de vía aérea disponible',
      'Miastenia gravis'
    ],
    dosis: {
      adulto: 'Convulsiones: 10 mg IM o IN (peso > 40 kg); o 0.1 mg/kg IV lento (2.5 a 5 mg). Cardioversión: 2 a 5 mg IV. SRI inducción: 0.2 a 0.3 mg/kg IV.',
      pediatrico: 'Convulsiones: 0.2 mg/kg IM o IN con MAD (máx 10 mg); o 0.1 mg/kg IV lento.',
      formulaMgKg: 0.1,
      maxDose: 'Convulsión única: 10 mg IM/IN o 5 mg IV inicial.',
      dilucionSugerida: 'Para IV se puede diluir con SF hasta 1 mg/mL y titular lentamente.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Modulador alostérico positivo del receptor GABA-A en el SNC, incrementando la conductancia al cloro y la inhibición neuronal. Posee potente efecto anticonvulsivo, ansiolítico, amnésico anterógrado y sedante.',
      farmacocinetica: {
        inicio: '1 a 2 minutos IV; 3 a 5 min IN/IM',
        pico: '3 a 5 minutos IV; 10 min IN',
        duracion: '30 a 60 minutos',
        metabolismoSemivida: 'Hepático por CYP3A4 a 1-hidroximidazolam. Semivida plasmática corta: 1.5 a 2.5 horas.'
      }
    },
    efectosSecundarios: ['Hipotensión leve, somnolencia, mareo, amnesia anterógrada, hipo.'],
    efectosAdversos: ['Depresión respiratoria y apnea (especialmente asociado a opioides), vasodilatación y colapso circulatorio en shock hipovolémico, agitación paradójica.'],
    txSobredosis: 'Flumazenilo (0.2 mg IV en 30 s), con precaución en epilépticos.',
    riesgoEmbarazo: 'D',
    puntosImportantes: [
      'En estatus epiléptico sin vía venosa, el Midazolam INTRAMUSCULAR o INTRANASAL es más rápido y eficaz que demorar minutos buscando una vena en un paciente rígido.',
      'Produce amnesia anterógrada casi completa: excelente para cardioversiones dolorosas.',
      'Tener siempre preparado Ambú y aspirador.'
    ],
    flashcard: {
      pregunta: '¿Cuál es la dosis y vía preferida de Midazolam para abortar una crisis convulsiva activa en un adulto sin vía venosa?',
      respuesta: '10 mg Intramuscular en el tercio medio del muslo o 10 mg Intranasal (5 mg en cada fosa nasal con atomizador MAD) para adultos de más de 40 kg.',
      puntosClave: [
        'Rápida absorción transmucosa nasal comparable a la IV.',
        'Dosis pediátrica: 0.2 mg/kg IN/IM.',
        'Antídoto: Flumazenilo.'
      ]
    }
  },

  // 31. NALOXONA
  {
    id: 'naloxona',
    nombre: 'Naloxona',
    nombreComercial: 'Narcan',
    clasificacion: 'Antagonista opioide puro competitivo',
    categoria: 'antidotos',
    presentacion: 'Ampolla 0.4 mg / 1 mL (0.4 mg/mL)',
    concentracion: '0.4 mg/mL',
    mgPorMl: 0.4,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 0.4, etiqueta: '0.04 a 0.4 mg IV titulado' },
    dosisPresets: [
      { label: 'Sobredosis con depresión respiratoria (0.04 a 0.4 mg IV titulado cada 2 min)', doseVal: 0.4, unit: 'mg_fijo' },
      { label: 'Sobredosis vía intranasal con atomizador (2 a 4 mg IN)', doseVal: 2, unit: 'mg_fijo' },
      { label: 'Paro cardíaco por sobredosis de opioides (2 mg IV/IN)', doseVal: 2, unit: 'mg_fijo' },
      { label: 'Pediátrico sobredosis (0.01 a 0.1 mg/kg IV/IN)', doseVal: 0.01, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV', 'IN (Intranasal con atomizador)', 'IM', 'SC', 'ET'],
    indicaciones: [
      'Intoxicación aguda por opioides con depresión respiratoria (FR < 10 rpm, pupilas mióticas, coma)',
      'Diagnóstico diferencial del coma de origen desconocido'
    ],
    contraindicaciones: [
      'Hipersensibilidad conocida a la naloxona'
    ],
    dosis: {
      adulto: 'IV: 0.04 a 0.4 mg titulados cada 2-3 minutos hasta restaurar FR ≥ 12 rpm. IN: 2 a 4 mg con atomizador. Si no hay respuesta tras 10 mg, dudar del diagnóstico de intoxicación por opioides pura.',
      pediatrico: '0.01 a 0.1 mg/kg IV o IN.',
      formulaMgKg: 0.01,
      maxDose: 'Hasta 10 mg en opioides sintéticos ultrapotentes (fentanilo, carfentanilo).',
      dilucionSugerida: 'Para titulación fina: tomar 1 ampolla (0.4 mg) y diluir en 9 mL de SF (0.04 mg/mL) y administrar 1 a 2 mL cada 2 minutos.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Antagonista puro de alta afinidad por los receptores mu, kappa y delta opioides en el SNC, desplazando a los agonistas opioides y revirtiendo la analgesia, sedación y depresión respiratoria.',
      farmacocinetica: {
        inicio: '1 a 2 minutos IV; 2 a 5 min IN/IM',
        pico: '5 minutos',
        duracion: '30 a 90 minutos (menor que casi todos los opioides)',
        metabolismoSemivida: 'Hepático por glucuronidación. Semivida: 30 a 90 minutos.'
      }
    },
    efectosSecundarios: ['Diaforesis, náuseas, vómitos, temblor, taquicardia, dolor súbito restablecido.'],
    efectosAdversos: ['Síndrome de abstinencia agudo severo con agitación psicomotriz agresiva, edema agudo de pulmón no cardiogénico por descarga adrenérgica masiva, arritmias ventriculares si se pasa en bolo rápido.'],
    txSobredosis: 'Efecto autolimitado.',
    riesgoEmbarazo: 'B',
    puntosImportantes: [
      'El objetivo clínico es restaurar una ventilación espontánea y oxigenación adecuadas (FR ≥ 12 rpm), ¡NO despertar por completo al paciente! Despertarlo bruscamente induce síndrome de abstinencia severo, vómitos con aspiración y agitación violenta.',
      'Vigilar la resedación tardía: la semivida de la naloxona (30-90 min) es mucho menor que la de la metadona o fentanilo.'
    ],
    flashcard: {
      pregunta: '¿Por qué la Naloxona debe titularse en dosis bajas hasta lograr una FR adecuada en lugar de buscar despertar por completo al paciente?',
      respuesta: 'Para evitar el síndrome de abstinencia hiperadrenérgico agudo (que puede provocar edema pulmonar no cardiogénico, hipertensión severa y agresión violenta) y vómitos con broncoaspiración masiva.',
      puntosClave: [
        'Meta: ventilación adecuada (FR ≥ 12 rpm).',
        'Dosis inicial: 0.04 a 0.4 mg IV titulado.',
        'Semivida corta: vigilar resedación.'
      ]
    }
  },

  // 32. NOREPINEFRINA (Noradrenalina)
  {
    id: 'norepinefrina',
    nombre: 'Norepinefrina (Noradrenalina)',
    nombreComercial: 'Levophed',
    clasificacion: 'Vasopresor potente, agonista adrenérgico Alfa-1 selectivo con efecto Beta-1 moderado',
    categoria: 'vasoactivos',
    presentacion: 'Ampolla 4 mg / 4 mL (1 mg/mL base)',
    concentracion: '1 mg/mL',
    mgPorMl: 1,
    dosisPorDefecto: { tipo: 'mcg/kg', valor: 0.1, etiqueta: '0.1 mcg/kg/min en infusión continua' },
    dosisPresets: [
      { label: 'Shock séptico / distributivo (0.05 a 0.5 mcg/kg/min)', doseVal: 0.1, unit: 'mcg/kg' },
      { label: 'Shock neurogénico (0.05 a 0.3 mcg/kg/min)', doseVal: 0.1, unit: 'mcg/kg' },
      { label: 'Dosis en mcg/min fijos (2 a 20 mcg/min)', doseVal: 5, unit: 'mcg/kg' },
    ],
    viasAdministracion: ['IV en infusión continua (vía central o periférica gruesa)', 'IO en infusión continua'],
    indicaciones: [
      'Vasopresor de primera línea en Shock Séptico y Shock Distributivo (Surviving Sepsis)',
      'Shock Neurogénico y Shock Cardiogénico severo con hipotensión extrema (TAM < 65 mmHg)'
    ],
    contraindicaciones: [
      'Hipotensión por hipovolemia pura no corregida (salvo medida de soporte puente transitorio)',
      'Nunca administrar en bolo directo rápido sin diluir'
    ],
    dosis: {
      adulto: '0.05 a 0.5 mcg/kg/min (o 2 a 30 mcg/min) en infusión continua por bomba. Titular cada 2-5 min hasta objetivo de TAM ≥ 65 mmHg.',
      pediatrico: '0.05 a 0.1 mcg/kg/min inicial; titular hasta 1-2 mcg/kg/min.',
      formulaMcgKg: 0.1,
      maxDose: 'Guiado por respuesta clínica y perfusión tisular.',
      dilucionSugerida: '4 mg en 250 mL SG 5% o SF 0.9% (concentración = 16 mcg/mL) u 8 mg en 250 mL (32 mcg/mL).'
    },
    mecanismoAccion: {
      farmacodinamia: 'Potente agonista de receptores adrenérgicos Alfa-1 periféricos, produciendo vasoconstricción arteriolar y venosa intensa (aumenta RVS y retorno venoso). Efecto inotrópico y cronotrópico Beta-1 moderado que preserva el volumen sistólico sin taquicardia excesiva.',
      farmacocinetica: {
        inicio: '1 a 2 minutos',
        pico: 'Inmediato tras titulación',
        duracion: '1 a 2 minutos tras suspender infusión',
        metabolismoSemivida: 'Inactivación tisular por MAO y COMT. Semivida plasmática: 1 a 2 minutos.'
      }
    },
    efectosSecundarios: ['Cefalea, ansiedad, bradicardia refleja por aumento de presión arterial, frialdad distal.'],
    efectosAdversos: ['Necrosis tisular y gangrena periférica en extremidades por vasoconstricción excesiva, necrosis por extravasación, arritmias cardíacas, aumento de postcarga cardíaca.'],
    txSobredosis: 'Cese de la infusión; antídoto en extravasación: infiltración local inmediata con Fentolamina (5 a 10 mg diluidos en 10 mL SF) en el área afectada.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'Vasopresor de primera elección en Shock Séptico según las guías internacionales.',
      'Objetivo hemodinámico estándar: Presión Arterial Media (TAM) ≥ 65 mmHg.',
      'Vigilar estrictamente la vía periférica ante cualquier signo de extravasación.'
    ],
    flashcard: {
      pregunta: '¿Cuál es el vasopresor de primera línea en el Shock Séptico y cuál es el objetivo de presión arterial media (TAM)?',
      respuesta: 'Norepinefrina (Noradrenalina) en infusión continua a dosis de 0.05 a 0.5 mcg/kg/min, con un objetivo terapéutico de TAM ≥ 65 mmHg.',
      puntosClave: [
        'Dilución estándar: 4 mg en 250 mL (16 mcg/mL).',
        'Antídoto de extravasación: Fentolamina.',
        'Semivida: 1 a 2 minutos.'
      ]
    }
  },

  // 33. ONDANSETRON
  {
    id: 'ondansetron',
    nombre: 'Ondansetrón',
    nombreComercial: 'Zofran',
    clasificacion: 'Antiemético antagonista selectivo del receptor de serotonina 5-HT3',
    categoria: 'antiemeticos',
    presentacion: 'Ampolla 4 mg / 2 mL y 8 mg / 4 mL (2 mg/mL)',
    concentracion: '2 mg/mL',
    mgPorMl: 2,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 4, etiqueta: '4 mg IV lento en náuseas/vómitos' },
    dosisPresets: [
      { label: 'Adulto náuseas / vómitos agudos (4 mg IV lento)', doseVal: 4, unit: 'mg_fijo' },
      { label: 'Adulto náuseas severas refractarias (8 mg IV en 15 min)', doseVal: 8, unit: 'mg_fijo' },
      { label: 'Pediátrico náuseas (0.15 mg/kg IV, máx 4 mg)', doseVal: 0.15, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV lenta', 'IM', 'VO (comprimidos bucodispersables)'],
    indicaciones: [
      'Náuseas y vómitos agudos en urgencias prehospitalarias (trauma, vértigo, cólico, post-opioides)',
      'Prevención de broncoaspiración por vómito en pacientes con alteración leve del sensorio o inmovilizados en tabla espinal'
    ],
    contraindicaciones: [
      'Hipersensibilidad al ondansetrón u otros antagonistas 5-HT3',
      'Síndrome de QT largo congénito conocido',
      'Uso concomitante con apomorfina (hipotensión severa y pérdida de conciencia)'
    ],
    dosis: {
      adulto: '4 mg IV lento en 2 a 5 minutos o IM (puede aumentarse a 8 mg en vómitos incoercibles).',
      pediatrico: '0.15 mg/kg IV en 2-5 min (máximo 4 mg por dosis).',
      formulaMgKg: 0.15,
      maxDose: '8 mg por dosis en emergencias.',
      dilucionSugerida: 'Administrar sin diluir en bolo lento o en 20 mL de SF.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Bloqueador selectivo y potente de los receptores de serotonina 5-HT3 tanto en terminales periféricos del nervio vago en el tracto digestivo como a nivel central en la zona gatillo quimiorreceptora del área postrema.',
      farmacocinetica: {
        inicio: '10 a 15 minutos IV',
        pico: '30 minutos',
        duracion: '4 a 8 horas',
        metabolismoSemivida: 'Hepático extenso por citocromo P450. Semivida: 3 a 4 horas.'
      }
    },
    efectosSecundarios: ['Cefalea (muy frecuente), estreñimiento, sensación de calor o rubor, mareo.'],
    efectosAdversos: ['Prolongación del intervalo QT, arritmias cardíacas (Torsades de Pointes raro a dosis altas), hipotensión leve.'],
    txSobredosis: 'Monitorización de ECG y soporte general.',
    riesgoEmbarazo: 'B',
    puntosImportantes: [
      'Carece de los efectos extrapiramidales (distonías, discinesias) y sedación de la metoclopramida (Plasil).',
      'Excelente fármaco para pacientes inmovilizados con collarín o tabla espinal para evitar broncoaspiración.',
      'Precaución con prolongación del QT si se asocia a otros fármacos como amiodarona o haloperidol.'
    ],
    flashcard: {
      pregunta: '¿Por qué el Ondansetrón es el antiemético preferido en trauma prehospitalario frente a la Metoclopramida?',
      respuesta: 'Porque no produce sedación ni reacciones extrapiramidales o distonías agudas, y tiene un excelente perfil de seguridad en pacientes inmovilizados con riesgo de broncoaspiración.',
      puntosClave: [
        'Dosis adulto: 4 mg IV lento.',
        'Antagonista de receptores 5-HT3.',
        'Precaución en pacientes con intervalo QT prolongado.'
      ]
    }
  },

  // 34. PARACETAMOL
  {
    id: 'paracetamol',
    nombre: 'Paracetamol (Acetaminofén)',
    nombreComercial: 'Perfalgan, Gelocatil, Tylenol',
    clasificacion: 'Analgésico y antipirético no opiáceo (derivado del paraaminofenol)',
    categoria: 'antiinflamatorios',
    presentacion: 'Frasco infusión 1.000 mg (1 g) / 100 mL (10 mg/mL) o Comprimidos 500 mg y 1 g',
    concentracion: '10 mg/mL',
    mgPorMl: 10,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 1000, etiqueta: '1 g IV a pasar en 15 min' },
    dosisPresets: [
      { label: 'Adulto dolor moderado / fiebre (1 g IV en 15 min)', doseVal: 1000, unit: 'mg_fijo' },
      { label: 'Adulto peso < 50 kg (15 mg/kg IV)', doseVal: 15, unit: 'mg/kg' },
      { label: 'Pediátrico dolor / fiebre (15 mg/kg IV)', doseVal: 15, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV en infusión de 15 min', 'VO', 'Rectal'],
    indicaciones: [
      'Dolor leve a moderado (somático, visceral, traumatológico)',
      'Fiebre elevada en adultos y pediatría'
    ],
    contraindicaciones: [
      'Insuficiencia hepatocelular grave o hepatitis aguda activa',
      'Hipersensibilidad al paracetamol o propacetamol'
    ],
    dosis: {
      adulto: '1.000 mg (1 g) IV en infusión de 15 minutos cada 6 horas (máx 4 g/día en normopeso; 3 g/día si peso < 50 kg o hepatopatía crónica).',
      pediatrico: '15 mg/kg IV en infusión de 15 minutos cada 6 horas (máximo 60 mg/kg/día).',
      formulaMgKg: 15,
      maxDose: 'Adulto: 1 g por dosis (máx 4 g/24h); Pediátrico: 15 mg/kg por dosis.',
      dilucionSugerida: 'Frasco listo para infundir en 15 minutos.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Inhibición de la síntesis de prostaglandinas a nivel del SNC (probablemente COX-3 / variante central) e interacción con las vías serotoninérgicas descendentes del dolor y receptores cannabinoides CB1. Carece de efecto antiinflamatorio periférico significativo.',
      farmacocinetica: {
        inicio: '5 a 10 minutos IV',
        pico: '15 a 30 minutos',
        duracion: '4 a 6 horas',
        metabolismoSemivida: 'Hepático por glucuronidación y sulfatación (90-95%); una fracción menor por CYP2E1 a NAPQI (tóxico). Semivida: 2 a 3 horas.'
      }
    },
    efectosSecundarios: ['Raros a dosis terapéuticas; hipotensión transitoria leve por infusión rápida.'],
    efectosAdversos: ['Hepatotoxicidad fulminante por necrosis centrolobulillar en sobredosis, trombocitopenia rara, erupciones cutáneas graves.'],
    txSobredosis: 'Antídoto específico de intoxicación: N-Acetilcisteína (NAC) IV (bolo inicial de 150 mg/kg en 1 h, seguido de 50 mg/kg en 4 h y 100 mg/kg en 16 h).',
    riesgoEmbarazo: 'B',
    puntosImportantes: [
      'Analgésico intravenoso con el mejor perfil de seguridad gastrointestinal, renal y cardiovascular en emergencias.',
      'No altera la función plaquetaria ni la coagulación sanguínea (seguro en trauma).',
      'Antídoto de sobredosis: N-Acetilcisteína (administrada antes de las 8 horas previene el daño hepático).'
    ],
    flashcard: {
      pregunta: '¿Cuál es el metabolito hepatotóxico del Paracetamol y cuál es su antídoto específico en sobredosis?',
      respuesta: 'El metabolito tóxico es el N-acetil-p-benzoquinoneimina (NAPQI). El antídoto específico es la N-Acetilcisteína (NAC), que restaura los depósitos hepáticos de glutatión.',
      puntosClave: [
        'Dosis estándar: 1 g IV en 15 min.',
        'Dosis pediátrica: 15 mg/kg IV.',
        'No altera la agregación plaquetaria.'
      ]
    }
  },

  // 35. PROPOFOL
  {
    id: 'propofol',
    nombre: 'Propofol',
    nombreComercial: 'Diprivan',
    clasificacion: 'Anestésico intravenoso no barbitúrico de acción ultracorta (derivado del alquilfenol)',
    categoria: 'via_aerea',
    presentacion: 'Ampolla / Vial al 1% (10 mg/mL = 200 mg / 20 mL) emulsión lipídica blanca',
    concentracion: '10 mg/mL',
    mgPorMl: 10,
    dosisPorDefecto: { tipo: 'mg/kg', valor: 2, etiqueta: '1.5 a 2.5 mg/kg IV en inducción SRI' },
    dosisPresets: [
      { label: 'Inducción SRI adulto normotenso (1.5 a 2.5 mg/kg IV)', doseVal: 2, unit: 'mg/kg' },
      { label: 'Inducción en anciano o frágil (1.0 a 1.5 mg/kg IV)', doseVal: 1, unit: 'mg/kg' },
      { label: 'Sedación para cardioversión (0.5 a 1.0 mg/kg IV lento)', doseVal: 0.5, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV estricta'],
    indicaciones: [
      'Inducción de anestesia general para SRI en pacientes hemodinámicamente ESTABLES y normotensos',
      'Sedación profunda para cardioversión sincronizada',
      'Sedación continua en pacientes bajo ventilación mecánica'
    ],
    contraindicaciones: [
      'Shock descompensado, hipotensión arterial severa (TAS < 90 mmHg)',
      'Hipersensibilidad grave al huevo, soja o propofol',
      'Trastornos graves del metabolismo lipídico'
    ],
    dosis: {
      adulto: 'Inducción SRI: 1.5 a 2.5 mg/kg IV en bolo lento en 30-60 segundos. Cardioversión: 0.5 a 1 mg/kg IV.',
      pediatrico: 'Inducción: 2 a 3 mg/kg IV.',
      formulaMgKg: 2,
      maxDose: 'Reducir a 1 mg/kg en ancianos o hipovolémicos.',
      dilucionSugerida: 'Bolo IV directo sin diluir. Dolor en la inyección: mitigar inyectando 20-40 mg de lidocaína previa.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Facilita la neurotransmisión inhibitoria en los receptores GABA-A disminuyendo la disociación del GABA, y bloquea subtipos de receptores de glutamato. Produce hipnosis rápida y profunda sin analgesia intrínseca.',
      farmacocinetica: {
        inicio: '30 a 45 segundos',
        pico: '1 minuto',
        duracion: '5 a 10 minutos (despertar rápido por redistribución)',
        metabolismoSemivida: 'Hepático rápido por glucuronidación. Semivida de eliminación: 4 a 7 horas (semivida de redistribución: 2-4 min).'
      }
    },
    efectosSecundarios: ['Dolor urente severo en el sitio de inyección venosa, mioclonías leves, orina verde con uso prolongado.'],
    efectosAdversos: ['Hipotensión arterial profunda por vasodilatación y depresión miocárdica, apnea, Síndrome de Infusión por Propofol (PRIS: acidosis láctica, rabdomiólisis, fallo cardíaco en infusiones altas prolongadas).'],
    txSobredosis: 'Soporte hemodinámico con fluidos y vasopresores (Noradrenalina), ventilación asistida invasiva.',
    riesgoEmbarazo: 'B',
    puntosImportantes: [
      '¡PELIGRO!: Produce vasodilatación masiva y depresión miocárdica directa. En pacientes en shock o trauma inestable puede precipitar paro cardíaco por colapso circulatorio (usar Ketamina o Etomidato en su lugar).',
      'Excelente broncodilatador y antiemético intrínseco.',
      'No tiene efecto analgésico: debe combinarse siempre con un opioide.'
    ],
    flashcard: {
      pregunta: '¿Por qué el Propofol está contraindicado en la inducción de la secuencia rápida de intubación de un paciente con shock séptico o traumatismo hipotenso?',
      respuesta: 'Porque produce una vasodilatación venosa y arterial sistémica masiva sumada a depresión miocárdica directa, lo que desencadena un colapso cardiovascular y paro en pacientes hipovolémicos o dependientes de tono simpático.',
      puntosClave: [
        'Dosis: 1.5 a 2.5 mg/kg IV.',
        'Despertar rápido y limpio en 5-10 min.',
        'Usar Ketamina o Etomidato en su lugar si hay inestabilidad.'
      ]
    }
  },

  // 36. ROCURONIO
  {
    id: 'rocuronio',
    nombre: 'Bromuro de Rocuronio',
    nombreComercial: 'Esmeron, Zemuron',
    clasificacion: 'Bloqueante neuromuscular no despolarizante esteroideo de acción intermedia',
    categoria: 'via_aerea',
    presentacion: 'Vial 50 mg / 5 mL (10 mg/mL)',
    concentracion: '10 mg/mL',
    mgPorMl: 10,
    dosisPorDefecto: { tipo: 'mg/kg', valor: 1.2, etiqueta: '1.2 mg/kg IV dosis estándar SRI' },
    dosisPresets: [
      { label: 'SRI Dosis Rápida Estándar (1.2 mg/kg IV)', doseVal: 1.2, unit: 'mg/kg' },
      { label: 'Intubación electiva convencional (0.6 mg/kg IV)', doseVal: 0.6, unit: 'mg/kg' },
      { label: 'Mantenimiento del bloqueo neuromuscular (0.15 mg/kg IV)', doseVal: 0.15, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV', 'IO'],
    indicaciones: [
      'Parálisis neuromuscular en Secuencia Rápida de Intubación (SRI) de elección internacional',
      'Mantenimiento de la relajación muscular en paciente crítico intubado y ventilado mecánicamente'
    ],
    contraindicaciones: [
      'Imposibilidad absoluta de oxigenar o ventilar sin plan de rescate quirúrgico inmediato',
      'Hipersensibilidad al rocuronio o bromuro'
    ],
    dosis: {
      adulto: 'SRI: 1.2 mg/kg IV en bolo rápido directo (alcanza condiciones de laringoscopia en 45 a 60 segundos). Intubación electiva: 0.6 mg/kg.',
      pediatrico: 'SRI: 1.0 a 1.2 mg/kg IV.',
      formulaMgKg: 1.2,
      maxDose: 'Calculado por peso ideal/predicho (PBW).',
      dilucionSugerida: 'Bolo IV directo sin diluir inmediatamente tras el fármaco inductor.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Antagonista competitivo de los receptores colinérgicos nicotínicos en la placa motora terminal del músculo esquelético, impidiendo la unión de la acetilcolina y produciendo parálisis muscular flácida completa sin fasciculaciones.',
      farmacocinetica: {
        inicio: '45 a 60 segundos (a 1.2 mg/kg)',
        pico: '1 a 2 minutos',
        duracion: '45 a 70 minutos',
        metabolismoSemivida: 'Eliminación biliar y hepática (70%) y renal (30%). Semivida: 60 a 90 minutos.'
      }
    },
    efectosSecundarios: ['Raros; ligera taquicardia transitoria.'],
    efectosAdversos: ['Apnea prolongada, anafilaxia (reacción a relajantes musculares), riesgo de conciencia intraoperatoria si no se mantiene sedoanalgesia adecuada.'],
    txSobredosis: 'Antídoto específico ultrarrápido: Sugammadex (16 mg/kg para reversión inmediata a los 3 min tras dosis de 1.2 mg/kg de rocuronio); Neostigmina + Atropina (solo en bloqueo residual parcial).',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'A dosis de 1.2 mg/kg IGUALA la rapidez de acción de la Succinilcolina (60 segundos) pero sin sus peligros mortales (hiperpotasemia, hipertermia maligna, quemaduras).',
      'Su parálisis dura entre 45 y 70 minutos: es imperativo iniciar infusión de sedación y analgesia (Fentanilo + Midazolam/Propofol) inmediatamente tras colocar el tubo para que el paciente no despierte paralizado.',
      'Existe reversor específico inmediato: Sugammadex.'
    ],
    flashcard: {
      pregunta: '¿Cuál es la dosis de Rocuronio en la Secuencia Rápida de Intubación y cuál es su antídoto de rescate específico inmediato?',
      respuesta: 'Dosis SRI: 1.2 mg/kg IV (logra condiciones de laringoscopia en 45-60 s). Su antídoto de reversión inmediata es el Sugammadex a 16 mg/kg.',
      puntosClave: [
        'No causa fasciculaciones ni elevación de potasio.',
        'Duración: 45 a 70 minutos.',
        'Asegurar sedación continua para evitar paciente consciente y paralizado.'
      ]
    }
  },

  // 37. SALBUTAMOL
  {
    id: 'salbutamol',
    nombre: 'Salbutamol (Albuterol)',
    nombreComercial: 'Ventolin',
    clasificacion: 'Broncodilatador agonista adrenérgico selectivo Beta-2 de acción corta (SABA)',
    categoria: 'respiratorio',
    presentacion: 'Solución para nebulización 5 mg/mL (0.5%) o Inhalador de dosis medida 100 mcg/pulsación',
    concentracion: '5 mg/mL',
    mgPorMl: 5,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 5, etiqueta: '5 mg (1 mL) nebulizado con O2' },
    dosisPresets: [
      { label: 'Adulto crisis broncoespasmo (2.5 a 5 mg nebulizado)', doseVal: 5, unit: 'mg_fijo' },
      { label: 'Hiperpotasemia severa con cambios ECG (10 a 20 mg nebulizado)', doseVal: 15, unit: 'mg_fijo' },
      { label: 'Pediátrico broncoespasmo (0.15 mg/kg neb, mín 1.25 mg, máx 5 mg)', doseVal: 0.15, unit: 'mg/kg' },
    ],
    viasAdministracion: ['Inhalatoria / Nebulizada', 'Inhalador con cámara espaciadora', 'IV lenta (excepcional)'],
    indicaciones: [
      'Broncoespasmo agudo severo en Asma y EPOC',
      'Hiperpotasemia aguda grave con alteraciones en el ECG (como adyuvante para redistribuir potasio al interior celular)'
    ],
    contraindicaciones: [
      'Hipersensibilidad al salbutamol',
      'Taquiarritmias ventriculares graves no controladas (evaluar riesgo/beneficio)'
    ],
    dosis: {
      adulto: '2.5 a 5 mg (0.5 a 1 mL de solución) diluido en 3 mL de SF nebulizado con flujo de O2 a 6-8 L/min cada 20 min (hasta 3 veces en la 1ª hora o en nebulización continua). Hiperpotasemia: 10 a 20 mg nebulizados.',
      pediatrico: '0.15 mg/kg (mínimo 1.25 mg, máximo 5 mg).',
      formulaMgKg: 0.15,
      maxDose: '5 mg por nebulización simple.',
      dilucionSugerida: 'Completar con SF 0.9% hasta un volumen total de 3 a 4 mL en la cazoleta de nebulización.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Estimulación selectiva de receptores Beta-2 en el músculo liso bronquial, activando la adenilil ciclasa y aumentando el AMP cíclico intracelular, provocando relajación bronquial potente y activando la bomba Na+/K+ ATPasa que introduce potasio al interior celular.',
      farmacocinetica: {
        inicio: '5 minutos inhalado',
        pico: '30 a 60 minutos',
        duracion: '3 a 6 horas',
        metabolismoSemivida: 'Metabolismo hepático a sulfato de albuterol inactivo. Semivida plasmática: 4 a 6 horas.'
      }
    },
    efectosSecundarios: ['Temblor distal fino (especialmente en manos), taquicardia sinusal, palpitaciones, cefalea, ansiedad.'],
    efectosAdversos: ['Hipopotasemia transitoria, taquiarritmias auriculares o ventriculares, prolongación del intervalo QT, acidosis láctica paradójica por estimulación beta-2 excesiva.'],
    txSobredosis: 'Betabloqueantes cardioselectivos (ej. Metoprolol) con precaución extrema por riesgo de broncoespasmo.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'En la primera hora de crisis asmática severa se puede nebulizar de forma continua o asociar con Bromuro de Ipratropio para efecto sinérgico.',
      'En hiperpotasemia grave con QRS ensanchado, nebulizar 10 a 20 mg (dosis 4 veces mayor que en asma) para introducir el potasio a la célula.',
      'Flujo de oxígeno del nebulizador: 6 a 8 litros/minuto para generar partículas de 1 a 5 micras.'
    ],
    flashcard: {
      pregunta: '¿Cuál es la dosis de Salbutamol nebulizado para tratar una Hiperpotasemia aguda grave con QRS ancho?',
      respuesta: '10 a 20 mg nebulizados con oxígeno (2 a 4 mL de solución para nebulizar), lo que equivale a 4 veces la dosis asmática habitual, para activar la bomba Na+/K+ ATPasa y meter el potasio a la célula en 15-30 minutos.',
      puntosClave: [
        'Dosis asmática: 2.5 a 5 mg.',
        'Dosis hiperpotasemia: 10 a 20 mg.',
        'Flujo de oxígeno: 6 a 8 L/min.'
      ]
    }
  },

  // 38. SULFATO DE MAGNESIO
  {
    id: 'sulfato_magnesio',
    nombre: 'Sulfato de Magnesio al 15% o 50%',
    nombreComercial: 'Sulfato de Magnesio',
    clasificacion: 'Antagonista fisiológico del calcio, anticonvulsivo obstétrico, electrolito',
    categoria: 'electrolitos',
    presentacion: 'Ampolla 1.5 g / 10 mL (15% = 150 mg/mL) o 1 g / 2 mL (50%)',
    concentracion: '150 mg/mL (15%)',
    mgPorMl: 150,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 2000, etiqueta: '2 g IV en asma o Torsades' },
    dosisPresets: [
      { label: 'Torsades de Pointes en paro (1 a 2 g IV/IO bolo en 2 min)', doseVal: 2000, unit: 'mg_fijo' },
      { label: 'Crisis asmática severa refractaria (2 g IV en 20 min)', doseVal: 2000, unit: 'mg_fijo' },
      { label: 'Eclampsia / Preeclampsia severa (4 g IV en 15-20 min)', doseVal: 4000, unit: 'mg_fijo' },
      { label: 'Pediátrico asma / arritmia (25 a 50 mg/kg IV en 20 min)', doseVal: 50, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV', 'IO', 'IM (solo obstétrico de rescate)'],
    indicaciones: [
      'Torsades de Pointes (taquicardia ventricular polimórfica con QT largo) con o sin pulso',
      'Crisis convulsivas en Eclampsia y prevención en Preeclampsia con criterios de severidad',
      'Crisis asmática severa con fallo respiratorio inminente refractaria a beta-2 agonistas',
      'Hipopotasemia o hipomagnesemia refractarias en paro'
    ],
    contraindicaciones: [
      'Bloqueo cardíaco auriculoventricular avanzado',
      'Miastenia gravis',
      'Insuficiencia renal anúrica severa'
    ],
    dosis: {
      adulto: 'Torsades de Pointes paro: 1 a 2 g IV bolo diluido en 10 mL SG 5% en 1-2 min. Asma severa: 2 g IV en 100 mL SF a pasar en 20 min. Eclampsia: 4 g IV en 100 mL en 15-20 min, seguido de infusión de 1 g/h.',
      pediatrico: '25 a 50 mg/kg IV en 20 minutos (máximo 2 g).',
      formulaMgKg: 50,
      maxDose: 'Adulto bolo inicial: 2 g (asma/torsades) o 4 g (eclampsia).',
      dilucionSugerida: 'Diluir 2 a 4 g en 100 mL de SF 0.9% o SG 5% y pasar en 15 a 20 minutos.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Bloquea los canales de calcio dependientes de voltaje en el músculo liso bronquial y vascular (broncodilatación y vasodilatación), estabiliza membranas excitables cardíacas, suprime posdespolarizaciones tempranas y bloquea la transmisión neuromuscular en la placa motora.',
      farmacocinetica: {
        inicio: 'Inmediato IV',
        pico: 'Inmediato tras infusión',
        duracion: '30 minutos (broncodilatación); horas en infusión',
        metabolismoSemivida: 'Eliminación 100% renal. Semivida: 4 horas.'
      }
    },
    efectosSecundarios: ['Sensación intensa de calor y rubor facial, sudoración, hipotensión leve, náuseas.'],
    efectosAdversos: ['Toxicidad por magnesio: abolición del reflejo rotuliano (patelar), bradicardia extrema, depresión respiratoria, coma y asistolia.'],
    txSobredosis: 'Antídoto específico inmediato: Gluconato de Calcio al 10% (1 g = 10 mL IV lento en 5-10 min).',
    riesgoEmbarazo: 'A',
    puntosImportantes: [
      'Tratamiento de elección indiscutible para las Torsades de Pointes.',
      'Fármaco anticonvulsivo de primera elección en Eclampsia (superior a diazepam y fenitoína).',
      'Vigilar siempre los reflejos osteotendinosos rotulianos: la pérdida del reflejo patelar es el primer signo de toxicidad antes de la depresión respiratoria.'
    ],
    flashcard: {
      pregunta: '¿Cuáles son las 3 indicaciones mayores del Sulfato de Magnesio IV en medicina de emergencias y cuál es su antídoto?',
      respuesta: '1) Torsades de Pointes (1-2 g). 2) Eclampsia / Preeclampsia severa (4 g). 3) Crisis asmática severa refractaria (2 g). Su antídoto inmediato es el Gluconato de Calcio al 10% (1 g IV).',
      puntosClave: [
        'Torsades: 1 a 2 g bolo IV.',
        'Asma: 2 g en 100 mL en 20 min.',
        'La pérdida del reflejo rotuliano alerta de toxicidad inminente.'
      ]
    }
  },

  // 39. SUCCINILCOLINA
  {
    id: 'succinilcolina',
    nombre: 'Succinilcolina (Suxametonio)',
    nombreComercial: 'Anectine, Quelicin',
    clasificacion: 'Bloqueante neuromuscular despolarizante de duración ultracorta',
    categoria: 'via_aerea',
    presentacion: 'Vial 100 mg / 2 mL (50 mg/mL) o 500 mg polvo liofilizado',
    concentracion: '50 mg/mL',
    mgPorMl: 50,
    dosisPorDefecto: { tipo: 'mg/kg', valor: 1.5, etiqueta: '1.5 mg/kg IV bolo directo en SRI' },
    dosisPresets: [
      { label: 'SRI adulto estándar (1.5 mg/kg IV)', doseVal: 1.5, unit: 'mg/kg' },
      { label: 'SRI adulto dosis máxima (2.0 mg/kg IV)', doseVal: 2.0, unit: 'mg/kg' },
      { label: 'SRI pediátrico (2.0 mg/kg IV)', doseVal: 2.0, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV', 'IO', 'IM (solo rescate extremo sin vía)'],
    indicaciones: [
      'Parálisis neuromuscular ultrarrápida para Secuencia Rápida de Intubación (SRI) cuando se requiere recuperación espontánea ultracorta'
    ],
    contraindicaciones: [
      'Hiperpotasemia conocida o sospechada (insuficiencia renal crónica)',
      'Quemaduras extensas o traumatismo por aplastamiento mayor > 24-48 horas',
      'Antecedente personal o familiar de Hipertermia Maligna',
      'Enfermedades neuromusculares desmielinizantes (ELA, esclerosis múltiple, distrofias, denervación motora)',
      'Trauma ocular penetrante reciente (aumenta presión intraocular)'
    ],
    dosis: {
      adulto: '1.5 a 2.0 mg/kg IV en bolo rápido directo.',
      pediatrico: '2.0 mg/kg IV (lactantes hasta 2.5-3 mg/kg).',
      formulaMgKg: 1.5,
      maxDose: '2.0 mg/kg.',
      dilucionSugerida: 'Bolo IV rápido sin diluir.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Agonista de receptores nicotínicos en la placa motora terminal. Produce despolarización persistente prolongada (observada clínicamente como fasciculaciones musculares transitorias) que agota e inhibe la transmisión neuromuscular, generando parálisis flácida.',
      farmacocinetica: {
        inicio: '30 a 60 segundos',
        pico: '1 minuto',
        duracion: '6 a 10 minutos (ultracorta)',
        metabolismoSemivida: 'Hidrólisis ultrarrápida por la pseudocolinesterasa plasmática (butirilcolinesterasa). Semivida: < 1 minuto.'
      }
    },
    efectosSecundarios: ['Fasciculaciones musculares generalizadas, mialgias musculares difusas posteriores, aumento transitorio de la presión intragástrica e intraocular.'],
    efectosAdversos: ['Hiperpotasemia masiva mortal (liberación letal de K+ en quemados/aplastamientos > 48 h), hipertermia maligna (rigidez muscular masiva, hipertermia extrema, acidosis), bradicardia sinusal y asistolia (especialmente en niños o con 2ª dosis).'],
    txSobredosis: 'Soporte ventilatorio hasta que el metabolismo espontáneo cese (6-10 min); Dantroleno sódico si desencadena Hipertermia Maligna.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'Eleva el potasio sérico en 0.5 a 1.0 mEq/L en pacientes sanos, pero puede provocar hiperpotasemia fulminante con paro cardíaco irreversible en quemados o pacientes con lesión medular de más de 48 horas de evolución.',
      'En niños puede causar bradicardia severa por estimulación vagal: se suele pretratar con Atropina 0.02 mg/kg.',
      'En caso de hipertermia maligna: detener el fármaco y administrar Dantroleno sódico de inmediato.'
    ],
    flashcard: {
      pregunta: '¿Por qué la Succinilcolina está contraindicada en pacientes quemados graves o con lesiones por aplastamiento transcurridas más de 48 horas?',
      respuesta: 'Porque se produce una proliferación y sobreexpresión masiva de receptores nicotínicos inmaduros en todo el sarcolema muscular, lo que provoca una salida torrencial de potasio hacia el torrente sanguíneo, causando hiperpotasemia fulminante y paro cardíaco.',
      puntosClave: [
        'Dosis: 1.5 a 2.0 mg/kg IV.',
        'Duración: 6 a 10 minutos.',
        'Contraindicada en hipertermia maligna e hiperpotasemia.'
      ]
    }
  },

  // 40. TRAMADOL
  {
    id: 'tramadol',
    nombre: 'Tramadol',
    nombreComercial: 'Adolonta, Tradonal, Ultram',
    clasificacion: 'Analgésico opioide atípico sintético, inhibidor de la recaptación de monoaminas',
    categoria: 'sedacion_analgesia',
    presentacion: 'Ampolla 100 mg / 2 mL (50 mg/mL)',
    concentracion: '50 mg/mL',
    mgPorMl: 50,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 100, etiqueta: '100 mg IV diluido a pasar en 10-15 min' },
    dosisPresets: [
      { label: 'Adulto dolor moderado-severo (100 mg IV diluido en 15 min)', doseVal: 100, unit: 'mg_fijo' },
      { label: 'Adulto dolor moderado / anciano (50 mg IV diluido)', doseVal: 50, unit: 'mg_fijo' },
      { label: 'Pediátrico > 12 años (1 a 1.5 mg/kg IV lento, máx 100 mg)', doseVal: 1, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV lenta en infusión', 'IM', 'SC', 'VO'],
    indicaciones: [
      'Dolor agudo moderado a severo (traumatismos, fracturas, cólico nefrítico, dolor postquirúrgico)'
    ],
    contraindicaciones: [
      'Epilepsia no controlada (disminuye el umbral convulsivo)',
      'Uso simultáneo con inhibidores de la MAO o fármacos serotoninérgicos (riesgo de Síndrome Serotoninérgico)',
      'Intoxicación aguda por alcohol, sedantes u opioides'
    ],
    dosis: {
      adulto: '50 a 100 mg IV diluidos en 100 mL de Solución Fisiológica a pasar en 15 a 20 minutos (nunca en bolo directo rápido por náuseas y vómitos incoercibles). Máximo 400 mg/día.',
      pediatrico: 'En mayores de 12 años: 1 a 1.5 mg/kg IV.',
      formulaMgKg: 1,
      maxDose: '100 mg por dosis única (máx 400 mg/día).',
      dilucionSugerida: 'Diluir siempre 100 mg en 100 mL de SF 0.9% y pasar en 15 minutos.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Mecanismo dual: agonista débil de receptores mu-opioides e inhibidor de la recaptación neuronal de serotonina (5-HT) y noradrenalina, potenciando las vías inhibitorias descendentes del dolor en la médula espinal.',
      farmacocinetica: {
        inicio: '10 a 20 minutos IV',
        pico: '30 a 60 minutos',
        duracion: '4 a 6 horas',
        metabolismoSemivida: 'Hepático por CYP2D6 a O-desmetiltramadol (M1, mucho más afín a receptores mu). Semivida: 6 horas.'
      }
    },
    efectosSecundarios: ['Náuseas y vómitos muy frecuentes si se pasa rápido, mareo, somnolencia, diaforesis, sequedad bucal.'],
    efectosAdversos: ['Convulsiones tónico-clónicas (disminuye umbral epileptógeno), síndrome serotoninérgico, depresión respiratoria leve, hipotensión postural.'],
    txSobredosis: 'Naloxona para revertir la depresión respiratoria (¡atención: la naloxona NO previene las convulsiones por tramadol e incluso puede aumentarlas!), soporte ventilatorio.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'La administración intravenosa rápida en bolo provoca náuseas y vómitos intensos en más del 50% de los pacientes: pasar SIEMPRE diluido en 100 mL en 15 minutos.',
      'Suele pautarse junto a un antiemético (Ondansetrón o Metoclopramida).',
      'Peligro en pacientes epilépticos: baja el umbral convulsivo.'
    ],
    flashcard: {
      pregunta: '¿Por qué el Tramadol IV nunca debe administrarse en bolo directo rápido y cuál es su riesgo neurológico principal?',
      respuesta: 'Porque en bolo rápido induce náuseas y vómitos incoercibles y mareo severo. Además, disminuye el umbral convulsivo y puede desencadenar crisis epilépticas en pacientes susceptibles.',
      puntosClave: [
        'Diluir 100 mg en 100 mL de SF a pasar en 15 min.',
        'Mecanismo dual: opioide débil + inhibidor de recaptación de serotonina/noradrenalina.',
        'Contraindicado en epilepsia no controlada.'
      ]
    }
  },

  // 41. VECURONIO
  {
    id: 'vecuronio',
    nombre: 'Bromuro de Vecuronio',
    nombreComercial: 'Norcuron',
    clasificacion: 'Bloqueante neuromuscular no despolarizante esteroideo de acción intermedia',
    categoria: 'via_aerea',
    presentacion: 'Vial 10 mg polvo liofilizado con ampolla disolvente de 5 mL (2 mg/mL)',
    concentracion: '2 mg/mL',
    mgPorMl: 2,
    dosisPorDefecto: { tipo: 'mg/kg', valor: 0.1, etiqueta: '0.1 mg/kg IV bolo' },
    dosisPresets: [
      { label: 'Intubación / SRI adulto (0.1 a 0.2 mg/kg IV)', doseVal: 0.1, unit: 'mg/kg' },
      { label: 'Mantenimiento de parálisis neuromuscular (0.02 a 0.03 mg/kg IV)', doseVal: 0.025, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV', 'IO'],
    indicaciones: [
      'Mantenimiento de la relajación neuromuscular en pacientes intubados bajo ventilación mecánica',
      'Alternativa al rocuronio para intubación orotraqueal'
    ],
    contraindicaciones: [
      'Imposibilidad de oxigenar o ventilar sin rescate',
      'Hipersensibilidad al vecuronio o al bromuro'
    ],
    dosis: {
      adulto: 'Intubación: 0.1 mg/kg IV en bolo directo (para secuencia rápida se puede usar 0.15-0.2 mg/kg). Mantenimiento: 0.02 a 0.03 mg/kg cada 30-45 minutos.',
      pediatrico: '0.1 mg/kg IV.',
      formulaMgKg: 0.1,
      maxDose: 'Calculado por peso ideal/predicho.',
      dilucionSugerida: 'Reconstituir los 10 mg en 5 mL de agua para inyección o SF (2 mg/mL) y administrar en bolo directo.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Antagonista competitivo de los receptores nicotínicos colinérgicos en la placa motora muscular. Prácticamente desprovisto de efectos cardiovasculares y sin liberación de histamina.',
      farmacocinetica: {
        inicio: '2 a 3 minutos',
        pico: '3 a 5 minutos',
        duracion: '30 a 45 minutos',
        metabolismoSemivida: 'Biliar y hepática (60-70%) y renal (30%). Semivida: 50 a 80 minutos.'
      }
    },
    efectosSecundarios: ['Raros; debilidad muscular residual.'],
    efectosAdversos: ['Apnea prolongada, debilidad muscular persistente/miopatía en estancias prolongadas, anafilaxia excepcional.'],
    txSobredosis: 'Sugammadex (a dosis de 2 a 4 mg/kg para bloqueo moderado a profundo) o Neostigmina + Atropina; soporte ventilatorio.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      'A diferencia del Rocuronio (que actúa en 45-60 s), el Vecuronio tarda entre 2 y 3 minutos en hacer efecto pleno, por lo que es de segunda elección en SRI pura pero excelente para mantenimiento.',
      'Excelente estabilidad cardiovascular (no produce taquicardia ni hipotensión).',
      'También es revertido específicamente por Sugammadex.'
    ],
    flashcard: {
      pregunta: '¿Cuál es la diferencia de tiempo de inicio entre el Vecuronio y el Rocuronio en la intubación?',
      respuesta: 'El Vecuronio tarda 2 a 3 minutos en alcanzar condiciones óptimas de intubación, mientras que el Rocuronio a dosis de 1.2 mg/kg actúa en 45 a 60 segundos, haciéndolo superior para la Secuencia Rápida de Intubación.',
      puntosClave: [
        'Dosis: 0.1 mg/kg IV.',
        'Duración: 30 a 45 minutos.',
        'Excelente estabilidad hemodinámica sin taquicardia.'
      ]
    }
  },

  // 42. VERAPAMILO
  {
    id: 'verapamilo',
    nombre: 'Verapamilo',
    nombreComercial: 'Manidon, Isoptin',
    clasificacion: 'Antiarrítmico de clase IV, calcioantagonista no dihidropiridínico (fenilalquilamina)',
    categoria: 'antiarritmicos',
    presentacion: 'Ampolla 5 mg / 2 mL (2.5 mg/mL)',
    concentracion: '2.5 mg/mL',
    mgPorMl: 2.5,
    dosisPorDefecto: { tipo: 'mg_fijo', valor: 5, etiqueta: '2.5 a 5 mg IV lento en 2 min' },
    dosisPresets: [
      { label: 'TSVP / FA control de frecuencia adulto (2.5 a 5 mg IV lento)', doseVal: 5, unit: 'mg_fijo' },
      { label: 'Segunda dosis a los 15-30 min si no revierte (5 a 10 mg IV)', doseVal: 7.5, unit: 'mg_fijo' },
      { label: 'Pediátrico > 1 año (0.1 a 0.2 mg/kg IV lento, máx 5 mg)', doseVal: 0.1, unit: 'mg/kg' },
    ],
    viasAdministracion: ['IV lenta estricta (en 2-3 min)', 'VO'],
    indicaciones: [
      'Taquicardia Supraventricular Paroxística (TSVP) por reentrada estable (cuando fallan adenosina o maniobras vagales)',
      'Control rápido de la frecuencia ventricular en Fibrilación Auricular o Flutter Auricular con RVR en paciente con FEVI conservada'
    ],
    contraindicaciones: [
      'Insuficiencia cardíaca descompensada o Fracción de Eyección reducida (FEVI < 40%: deprime fuertemente la contractilidad)',
      'Hipotensión arterial severa (TAS < 90 mmHg) o shock cardiogénico',
      'Taquicardia de complejo QRS ancho de origen desconocido o TV (puede provocar colapso cardiovascular y FV)',
      'Fibrilación Auricular preexcitada (Síndrome de Wolff-Parkinson-White: desvía la conducción por la vía accesoria induciendo FV mortal)',
      'Bloqueo AV de 2º o 3º grado o Síndrome del Seno Enfermo',
      'Uso simultáneo con Betabloqueantes IV (riesgo de bradicardia severa, paro sinusal y asistolia)'
    ],
    dosis: {
      adulto: '2.5 a 5 mg IV lento en no menos de 2 minutos. Si no hay respuesta tras 15 a 30 minutos, se puede administrar una segunda dosis de 5 a 10 mg (máximo 20 mg total).',
      pediatrico: 'En mayores de 1 año: 0.1 a 0.2 mg/kg IV lento en 2 min (máximo 5 mg). ¡CONTRAINDICADO en menores de 1 año por colapso cardiovascular y parada!',
      formulaMgKg: 0.1,
      maxDose: 'Adulto: 10 mg por dosis única (20 mg acumulados).',
      dilucionSugerida: 'Inyección IV lenta en no menos de 2 a 3 minutos comprobando monitor y presión arterial.'
    },
    mecanismoAccion: {
      farmacodinamia: 'Bloquea los canales lentos de calcio tipo L en el nódulo auriculoventricular y miocitos. Retrasa la conducción y prolonga el periodo refractario efectivo en el nódulo AV, frena la frecuencia ventricular y disminuye la contractilidad (inótropo negativo) y tono vascular.',
      farmacocinetica: {
        inicio: '3 a 5 minutos IV',
        pico: '10 a 15 minutos',
        duracion: '2 a 6 horas',
        metabolismoSemivida: 'Hepático extenso por CYP3A4 a norverapamilo. Semivida: 3 a 7 horas.'
      }
    },
    efectosSecundarios: ['Hipotensión arterial transitoria, mareo, cefalea, náuseas, sofocos.'],
    efectosAdversos: ['Bradicardia severa, asistolia, bloqueo AV completo, colapso circulatorio y shock cardiogénico (especialmente si se administra junto a betabloqueantes o en insuficiencia cardíaca previa).'],
    txSobredosis: 'Antídoto: Gluconato de Calcio al 10% (1 a 2 g IV lento), infusión de Insulina a dosis altas con Glucosa (terapia HIET), vasopresores (Norepinefrina) y marcapasos.',
    riesgoEmbarazo: 'C',
    puntosImportantes: [
      '¡PELIGROS MORTALES!: 1) NUNCA administrar en taquicardias de QRS ancho (si es una TV, induce colapso circulatorio y parada). 2) NUNCA asociar con Betabloqueantes IV (induce bloqueo AV completo y asistolia refractaria). 3) NUNCA dar en lactantes < 1 año.',
      'Antídoto en intoxicación o hipotensión inducida: Gluconato de Calcio IV.'
    ],
    flashcard: {
      pregunta: '¿Cuáles son las 3 contraindicaciones fatales del Verapamilo IV que nunca deben olvidarse en urgencias?',
      respuesta: '1) Taquicardia de QRS ancho (riesgo de parada si es TV). 2) Asociación concomitante con Betabloqueantes IV (asistolia y bloqueo completo). 3) Fibrilación auricular preexcitada (WPW) o insuficiencia cardíaca con FEVI reducida.',
      puntosClave: [
        'Dosis: 2.5 a 5 mg IV lento en 2 minutos.',
        'Antídoto en sobredosis: Gluconato de Calcio al 10%.',
        'Contraindicado absolutamente en menores de 1 año.'
      ]
    }
  }
];

export const VASOACTIVE_PRESETS: VasoactiveDrugPreset[] = [
  {
    id: 'noradrenalina',
    nombre: 'Norepinefrina (Noradrenalina)',
    ampollaMg: 4,
    ampollaMl: 4,
    dilucionEstandarMl: 250,
    unidadDosis: 'mcg/kg/min',
    rangoDosis: { min: 0.05, max: 1.0, tipico: 0.1 },
    vehiculo: 'SG 5% o SF 0.9%',
    indicacion: 'Shock séptico, distributivo, neurogénico'
  },
  {
    id: 'epinefrina_infusion',
    nombre: 'Epinefrina (Adrenalina) Infusión',
    ampollaMg: 4,
    ampollaMl: 4,
    dilucionEstandarMl: 250,
    unidadDosis: 'mcg/kg/min',
    rangoDosis: { min: 0.02, max: 0.5, tipico: 0.05 },
    vehiculo: 'SG 5%',
    indicacion: 'Shock cardiogénico, bradicardia inestable refractaria, shock anafiláctico'
  },
  {
    id: 'dobutamina_infusion',
    nombre: 'Dobutamina Infusión',
    ampollaMg: 250,
    ampollaMl: 20,
    dilucionEstandarMl: 250,
    unidadDosis: 'mcg/kg/min',
    rangoDosis: { min: 2.5, max: 20, tipico: 5 },
    vehiculo: 'SG 5% o SF 0.9%',
    indicacion: 'Falla cardíaca aguda con bajo gasto y TAS > 90 mmHg'
  },
  {
    id: 'fentanilo_infusion',
    nombre: 'Fentanilo Infusión Sedación',
    ampollaMg: 0.5,
    ampollaMl: 10,
    dilucionEstandarMl: 100,
    unidadDosis: 'mcg/kg/min',
    rangoDosis: { min: 0.02, max: 0.08, tipico: 0.03 },
    vehiculo: 'SF 0.9% o SG 5%',
    indicacion: 'Analgesia y sedación continua en paciente bajo ventilación mecánica'
  },
  {
    id: 'midazolam_infusion',
    nombre: 'Midazolam Infusión Sedación',
    ampollaMg: 50,
    ampollaMl: 10,
    dilucionEstandarMl: 100,
    unidadDosis: 'mg/h',
    rangoDosis: { min: 2, max: 15, tipico: 5 },
    vehiculo: 'SF 0.9% o SG 5%',
    indicacion: 'Sedación profunda / estatus epiléptico refractario'
  }
];
