import { ArrhythmiaItem } from '../types/clinical';

export interface ArrhythmiaCardioversionInfo {
  joulesBifasico: string;
  joulesMonofasico: string;
  requiereSincronizacion: boolean;
  pseudoanalgesiaRecomendada: string;
}

export interface ExtendedArrhythmiaItem extends ArrhythmiaItem {
  esInestable?: boolean;
  cardioversion?: ArrhythmiaCardioversionInfo;
}

export const ARRHYTHMIAS_DATABASE: ExtendedArrhythmiaItem[] = [
  // 1. ASISTOLIA
  {
    id: 'asistolia',
    nombre: 'Asistolia ("Línea Plana")',
    categoria: 'paro_no_desfibrilable',
    esDesfibrilable: false,
    fcTipica: '0 lpm (Ausencia de actividad eléctrica detectable)',
    criteriosECG: [
      'Línea isoeléctrica plana o mínima ondulación no rítmica (< 0.1 mV).',
      'Ausencia total de complejos QRS u ondas P organizadas.',
      'Protocolo de confirmación de "Línea Plana": verificar cables/electrodos, aumentar ganancia (×2) y cambiar de derivación (DII a V1 o DIII) para descartar FV fina.'
    ],
    significadoClinico: 'Paro cardiorrespiratorio con cese total de actividad miocárdica. Peor pronóstico si no se revierte causa desencadenante inmediata.',
    tratamientoInmediato: {
      paso1: '¡NO DESFIBRILAR! Iniciar RCP de alta calidad de inmediato durante 2 minutos.',
      farmaco1: 'Epinefrina (Adrenalina) 1 mg IV/IO lo antes posible tras acceso venoso. Repetir cada 3-5 minutos.',
      paso2: 'Manejo avanzado de vía aérea con capnografía continua (ETCO2). Si ETCO2 < 10 mmHg tras 20 min de RCP adecuada, pronóstico infausto.',
      farmaco2: 'Buscar y revertir inmediatamente las 5H y 5T (especialmente Hipoxia, Hipovolemia, Acidosis, Hipotermia).',
      cuidadosAvanzados: [
        'No interrumpir compresiones para intubar.',
        'Considerar cese de maniobras de reanimación si no hay causa reversible tras 20-30 min.'
      ]
    },
    svgWaveformType: 'asystole'
  },

  // 2. AESP (Actividad Eléctrica Sin Pulso)
  {
    id: 'aesp',
    nombre: 'Actividad Eléctrica Sin Pulso (AESP)',
    categoria: 'paro_no_desfibrilable',
    esDesfibrilable: false,
    fcTipica: 'Variable (desde bradicárdico a taquicárdico, sin gasto cardíaco)',
    criteriosECG: [
      'Presencia de actividad eléctrica cardíaca organizada en el monitor (cualquier ritmo que no sea FV ni TV)',
      'Ausencia total de pulso arterial central palpable (carotídeo o femoral).',
      'QRS estrecho: suele deberse a causas mecánicas (Hipovolemia, Neumotórax a tensión, Taponamiento cardíaco, TEP masivo).',
      'QRS ancho: suele deberse a causas metabólicas o tóxicas (Hiperpotasemia, Acidosis extrema, bloqueantes cálcicos).'
    ],
    significadoClinico: 'Disociación electromecánica profunda: el corazón genera despolarización eléctrica pero el miocardio no se contrae o no tiene sangre que expulsar.',
    tratamientoInmediato: {
      paso1: '¡NO DESFIBRILAR! RCP de alta calidad ininterrumpida.',
      farmaco1: 'Epinefrina (Adrenalina) 1 mg IV/IO inmediato. Repetir cada 3-5 min.',
      paso2: 'Tratar causa subyacente en los primeros minutos (la clave de la supervivencia en AESP).',
      farmaco2: 'Si QRS estrecho: sospechar Hipovolemia (cristaloides tibios rápidos), Taponamiento (pericardiocentesis) o Neumotórax a tensión (descompresión torácica con aguja o toracostomía).',
      cuidadosAvanzados: [
        'Si QRS ancho: sospechar Hiperpotasemia (Gluconato de Calcio 1-2 g IV + Bicarbonato de Sodio 1 mEq/kg).'
      ]
    },
    svgWaveformType: 'pea'
  },

  // 3. FV (Fibrilación Ventricular)
  {
    id: 'fv',
    nombre: 'Fibrilación Ventricular (FV)',
    categoria: 'paro_desfibrilable',
    esDesfibrilable: true,
    fcTipica: 'Caótica / Indeterminable (> 300/min desorganizada)',
    criteriosECG: [
      'Ausencia total de complejos QRS identificables, ondas P u ondas T.',
      'Ondas polimórficas irregulares caóticas continuas de amplitud y frecuencia variable.',
      'FV Gruesa: amplitud > 0.2 mV (alta probabilidad de respuesta a desfibrilación).',
      'FV Fina: amplitud < 0.2 mV (hacer RCP de alta calidad previo al choque para oxigenar miocardio).'
    ],
    significadoClinico: 'Paro cardiorrespiratorio primario. Pérdida inmediata de conocimiento (< 10 segundos) por colapso total del gasto cardíaco.',
    tratamientoInmediato: {
      paso1: '¡DESFIBRILACIÓN ASINCRÓNICA INMEDIATA! Bifásico: 120-200 J (o energía máxima del equipo). Monofásico: 360 J.',
      farmaco1: 'Reiniciar RCP de alta calidad de inmediato durante 2 minutos tras el choque (NO detenerse a palpar pulso).',
      paso2: 'Epinefrina 1 mg IV/IO tras la 2ª descarga (durante el 2º ciclo de RCP).',
      farmaco2: 'Amiodarona 300 mg IV/IO en bolo tras la 3ª descarga (alternativa: Lidocaína 1 a 1.5 mg/kg). Segunda dosis de Amiodarona: 150 mg tras la 5ª descarga.',
      cuidadosAvanzados: [
        'Minimizar tiempo sin compresiones torácicas a menos de 5 segundos para cargar el desfibrilador.',
        'Vía aérea avanzada con capnografía (ETCO2 objetivo > 15-20 mmHg).'
      ]
    },
    svgWaveformType: 'vf_coarse'
  },

  // 4. TVM SIN PULSO
  {
    id: 'tvm_sin_pulso',
    nombre: 'Taquicardia Ventricular Monomórfica Sin Pulso (TVSP)',
    categoria: 'paro_desfibrilable',
    esDesfibrilable: true,
    fcTipica: '150 a 250 lpm (rápida, regular, ancha)',
    criteriosECG: [
      'Complejos QRS anchos (> 120 ms / > 3 cuadritos), idénticos entre sí (monomórficos) y regulares.',
      'Ausencia de ondas P asociadas a cada QRS.',
      'Paciente clínicamente inconsciente, apneico y SIN PULSO palpable en carótida o femoral.'
    ],
    significadoClinico: 'Ritmo de paro desfibrilable. Manejo exactamente idéntico al algoritmo de Fibrilación Ventricular (FV).',
    tratamientoInmediato: {
      paso1: '¡DESFIBRILACIÓN ASINCRÓNICA INMEDIATA! Bifásico: 120-200 J (o máximo). Monofásico: 360 J.',
      farmaco1: 'Reanudar inmediatamente 2 minutos de compresiones torácicas.',
      paso2: 'Epinefrina 1 mg IV tras 2ª descarga. Amiodarona 300 mg tras 3ª descarga.',
      cuidadosAvanzados: [
        'Asegurar que el paciente realmente no tiene pulso antes de disparar sin sincronizar.'
      ]
    },
    svgWaveformType: 'vt_mono'
  },

  // 5. TVM CON PULSO
  {
    id: 'tvm_con_pulso',
    nombre: 'Taquicardia Ventricular Monomórfica Con Pulso',
    categoria: 'taquicardia',
    esDesfibrilable: false,
    fcTipica: '140 a 220 lpm (regular y ancha)',
    criteriosECG: [
      'Complejos QRS anchos (> 120 ms) con morfología idéntica y ritmo regular.',
      'Disociación auriculoventricular (ondas P independientes a menor frecuencia), latidos de captura o fusión (patognomónicos).',
      'Paciente CON PULSO palpable presente.'
    ],
    significadoClinico: 'Arritmia ventricular potencialmente letal con riesgo inminente de degenerar en TVSP o FV y shock cardiogénico.',
    cardioversion: {
      joulesBifasico: '100 J inicial (subir a 200 J si no revierte)',
      joulesMonofasico: '100 J (subir a 200 J)',
      requiereSincronizacion: true,
      pseudoanalgesiaRecomendada: 'Midazolam 2 a 5 mg IV lento + Fentanilo 50 a 100 mcg IV (o Ketamina 0.5 a 1 mg/kg IV si hay hipotensión).'
    },
    tratamientoInmediato: {
      paso1: '¿INESTABLE? (Hipotensión, dolor torácico isquémico, alteración mental, edema pulmonar, shock): CARDIOVERSIÓN ELÉCTRICA SINCRONIZADA con 100 J bifásico (con pseudoanalgesia si está consciente).',
      farmaco1: 'Si está ESTABLE: Amiodarona 150 mg IV diluida en 100 mL de SG 5% a pasar en 10 minutos (repetir si es necesario; infusión de mantenimiento 1 mg/min por 6 h).',
      paso2: 'Alternativa antiarrítmica estable: Procainamida 20 a 50 mg/min IV o Lidocaína 1 a 1.5 mg/kg IV.',
      cuidadosAvanzados: [
        '¡Activar siempre el botón SYNC del monitor para no descargar sobre la onda T e inducir FV mortal!',
        'Monitoreo continuo de ECG y SpO2.'
      ]
    },
    svgWaveformType: 'vt_mono'
  },

  // 6. TVP TORSADA DE POINTES
  {
    id: 'torsades',
    nombre: 'TVP Torsada de Pointes (TV Polimórfica con QT Largo)',
    categoria: 'paro_desfibrilable',
    esDesfibrilable: true,
    fcTipica: '150 a 300 lpm',
    criteriosECG: [
      'Complejos QRS polimórficos de amplitud variable que rotan o "se tuercen" helicoidalmente alrededor de la línea isoeléctrica.',
      'Intervalo QT basal previo marcadamente prolongado (QTc > 500 ms).',
      'Desencadenado comúnmente por hipomagnesemia, hipopotasemia o fármacos que alargan el QT.'
    ],
    significadoClinico: 'Arritmia extremadamente inestable que suele degenerar en paro cardíaco por FV en segundos.',
    cardioversion: {
      joulesBifasico: 'Desfibrilación Asincrónica 200 J (la sincronización falla por QRS polimórfico)',
      joulesMonofasico: '360 J',
      requiereSincronizacion: false,
      pseudoanalgesiaRecomendada: 'Si está consciente: Ketamina 1 mg/kg IV o Midazolam 3 mg IV.'
    },
    tratamientoInmediato: {
      paso1: 'FÁRMACO DE PRIMERA LÍNEA OBLIGATORIO: SULFATO DE MAGNESIO 1 a 2 gramos IV/IO diluido en 10 mL SG 5% a pasar en 1 a 2 minutos.',
      farmaco1: 'Si el paciente está inestable o sin pulso: DESFIBRILACIÓN ASINCRÓNICA INMEDIATA con 200 J bifásico.',
      paso2: 'Corregir hipopotasemia (mantener K+ > 4.5 mEq/L). Suspender todos los fármacos prolongadores del QT.',
      farmaco2: 'Estimulación por marcapasos a 100-110 lpm o Isoproterenol para acortar el QT si es recurrente por pausas.',
      cuidadosAvanzados: [
        '¡CONTRAINDICADA la Amiodarona porque prolonga el QT y empeora mortalmente las Torsades!'
      ]
    },
    svgWaveformType: 'torsades'
  },

  // 7. TAQUICARDIA SINUSAL
  {
    id: 'taquicardia_sinusal',
    nombre: 'Taquicardia Sinusal',
    categoria: 'taquicardia',
    esDesfibrilable: false,
    fcTipica: '101 a 150 lpm (rara vez > 160 en reposo)',
    criteriosECG: [
      'Ritmo regular con onda P sinusal idéntica y positiva en DII, DIII y aVF antes de cada complejo QRS.',
      'Intervalo PR constante normal (120-200 ms). Complejo QRS estrecho.',
      'Respuesta fisiológica refleja a estrés, dolor, hipovolemia, fiebre, sepsis o hipoxia.'
    ],
    significadoClinico: 'Signo compensador secundario. ¡NO tratar la taquicardia en sí, tratar la causa de base!',
    tratamientoInmediato: {
      paso1: '¡NO CARDIOVERTIR NI DAR ANTIARRÍTMICOS! Buscar y corregir la causa desencadenante:',
      farmaco1: 'Hipovolemia/Shock: infundir cristaloides. Fiebre: Paracetamol 1 g IV. Dolor: analgesia (fentanilo/morfina). Hipoxia: oxígeno.',
      paso2: 'Monitoreo de signos vitales, lactato y diuresis.',
      cuidadosAvanzados: [
        'Frenar la taquicardia sinusal con betabloqueantes en un paciente hipovolémico precipita colapso cardiovascular y shock mortal.'
      ]
    },
    svgWaveformType: 'pea'
  },

  // 8. TSV ESTABLE
  {
    id: 'tsv_estable',
    nombre: 'Taquicardia Supraventricular Estable (TSVP)',
    categoria: 'taquicardia',
    esDesfibrilable: false,
    fcTipica: '150 a 250 lpm (estrecha, perfectamente regular)',
    criteriosECG: [
      'Complejos QRS estrechos (< 120 ms) con ritmo matemáticamente regular.',
      'Ondas P no visibles (ocultas en el QRS) o retrógradas negativas inmediatamente tras el QRS.',
      'Paciente hemodinámicamente ESTABLE (sin dolor torácico, sin shock, sin disnea severa, TAS > 90).'
    ],
    significadoClinico: 'Taquicardia por reentrada nodal (TRNAV) o por vía accesoria. En paciente estable permite tratamiento farmacológico escalonado.',
    tratamientoInmediato: {
      paso1: '1º Maniobras Vagales: Maniobra de Valsalva Modificada (soplar en jeringa de 10 mL por 15 s + elevación pasiva de piernas a 45°: tasa de éxito > 43%).',
      farmaco1: '2º Si falla Valsalva: ADENOSINA 6 mg IV bolo ultrarrápido (1-2 s) con llave de 3 vías + 20 mL de SF y elevar el brazo.',
      paso2: 'Si no revierte en 1-2 min: 2ª dosis de ADENOSINA 12 mg IV en bolo rápido.',
      farmaco2: '3º Si no revierte: Calcioantagonista (Verapamilo 2.5-5 mg IV lento o Diltiazem) o Betabloqueante (Metoprolol 5 mg IV).',
      cuidadosAvanzados: [
        'Registrar tira de ECG continua durante la administración de adenosina.',
        'Advertir al paciente de la sensación transitoria de opresión en el pecho.'
      ]
    },
    svgWaveformType: 'svt'
  },

  // 9. TSV INESTABLE
  {
    id: 'tsv_inestable',
    nombre: 'Taquicardia Supraventricular Inestable (TSVP)',
    categoria: 'taquicardia',
    esDesfibrilable: false,
    esInestable: true,
    fcTipica: '150 a 250 lpm con signos de hipoperfusión',
    criteriosECG: [
      'QRS estrecho regular a frecuencia rápida > 150 lpm.',
      'Presencia de al menos 1 signo de INESTABILIDAD hemodinámica (TAS < 90 mmHg, dolor torácico isquémico, alteración mental, edema agudo de pulmón o signos de shock).'
    ],
    significadoClinico: 'Emergencia hemodinámica. El acortamiento extremo de la diástole colapsa el gasto cardíaco.',
    cardioversion: {
      joulesBifasico: '50 a 100 J Sincronizado inicial',
      joulesMonofasico: '100 J Sincronizado',
      requiereSincronizacion: true,
      pseudoanalgesiaRecomendada: 'Midazolam 2 a 5 mg IV (o 0.05 mg/kg) + Fentanilo 50 mcg IV (o Ketamina 0.5-1 mg/kg si TAS límite).'
    },
    tratamientoInmediato: {
      paso1: '¡CARDIOVERSIÓN ELÉCTRICA SINCRONIZADA INMEDIATA! Energía bifásica: 50 a 100 J (activar botón SYNC).',
      farmaco1: 'Administrar Pseudoanalgesia previa si el paciente está consciente (Midazolam 2-5 mg IV o Ketamina 0.5 mg/kg). No demorar el choque si el colapso es crítico.',
      paso2: 'Si no revierte: aumentar energía a 100 J -> 150 J -> 200 J bifásico.',
      cuidadosAvanzados: [
        'Si el acceso venoso ya está colocado y listo, se puede intentar 1 dosis rápida de Adenosina 6 mg mientras se prepara el desfibrilador, pero sin retrasar la cardioversión.'
      ]
    },
    svgWaveformType: 'svt'
  },

  // 10. FA (Fibrilación Auricular)
  {
    id: 'fa',
    nombre: 'Fibrilación Auricular (FA con RVR)',
    categoria: 'taquicardia',
    esDesfibrilable: false,
    fcTipica: '120 a 180 lpm (irregularmente irregular)',
    criteriosECG: [
      'Ausencia total de ondas P organizadas (reemplazadas por ondas "f" desorganizadas en línea de base).',
      'Intervalos R-R absolutamente caóticos e irregulares ("irregularmente irregular").',
      'Complejos QRS estrechos (< 120 ms) en ausencia de bloqueo de rama previo.',
      'Respuesta ventricular rápida (RVR) si FC > 100-110 lpm.'
    ],
    significadoClinico: 'Pérdida de la sístole auricular. En FC > 130 lpm produce descompensación cardíaca aguda.',
    cardioversion: {
      joulesBifasico: '120 a 200 J Sincronizado inicial',
      joulesMonofasico: '200 J Sincronizado',
      requiereSincronizacion: true,
      pseudoanalgesiaRecomendada: 'Midazolam 2 a 5 mg IV + Fentanilo 50 a 100 mcg IV (o Propofol 0.5 mg/kg si normotenso).'
    },
    tratamientoInmediato: {
      paso1: '¿INESTABLE? Cardioversión Eléctrica Sincronizada inmediata con 120 - 200 J bifásico (previa pseudoanalgesia).',
      farmaco1: 'Si está ESTABLE: Control de frecuencia ventricular. 1ª Línea: Betabloqueante (Metoprolol 2.5 a 5 mg IV lento en 2 min) o Calcioantagonista (Diltiazem 0.25 mg/kg IV en 2 min o Verapamilo 5 mg IV).',
      paso2: 'Si hay insuficiencia cardíaca descompensada (FEVI reducida): Amiodarona 150 mg IV en 10 min o Digoxina.',
      cuidadosAvanzados: [
        '¡PELIGRO WPW!: Si la FA tiene preexcitación (WPW: QRS ancho, muy rápida > 200 y caótica), ESTÁN CONTRAINDICADOS Adenosina, Calcioantagonistas y Betabloqueantes (desvían impulsos a la vía accesoria induciendo FV letal). Usar Cardioversión Eléctrica o Procainamida.'
      ]
    },
    svgWaveformType: 'afib'
  },

  // 11. FLUTTER AURICULAR
  {
    id: 'flutter_auricular',
    nombre: 'Flutter Auricular (Aleteo Auricular)',
    categoria: 'taquicardia',
    esDesfibrilable: false,
    fcTipica: 'Auricular: 300 lpm; Ventricular típica: 150 lpm (conducción 2:1)',
    criteriosECG: [
      'Ondas "F" idénticas y regulares en patrón continuo en "dientes de sierra", mejor visibles en DII, DIII y aVF.',
      'Frecuencia auricular constante de 250 a 350 lpm (típicamente 300 lpm).',
      'Conducción AV fija (2:1 da FC 150 lpm; 3:1 da FC 100 lpm; 4:1 da FC 75 lpm) o variable.',
      'Complejos QRS estrechos y regulares.'
    ],
    significadoClinico: 'Circuito de macro-reentrada en la aurícula derecha. Alta respuesta a cardioversión con baja energía.',
    cardioversion: {
      joulesBifasico: '50 J Sincronizado inicial (muy sensible)',
      joulesMonofasico: '100 J Sincronizado',
      requiereSincronizacion: true,
      pseudoanalgesiaRecomendada: 'Midazolam 2 a 4 mg IV + Fentanilo 50 mcg IV.'
    },
    tratamientoInmediato: {
      paso1: '¿INESTABLE?: Cardioversión Eléctrica Sincronizada con 50 J bifásico (responde excelentemente a choques de baja energía).',
      farmaco1: 'Si está ESTABLE: Control de frecuencia con Betabloqueantes (Metoprolol 5 mg IV) o Diltiazem.',
      paso2: 'Cardioversión eléctrica electiva si los fármacos no controlan la frecuencia.',
      cuidadosAvanzados: [
        'La adenosina no suele revertir el flutter, pero al frenar el nódulo AV desenmascara con claridad las ondas en dientes de sierra diagnósticas.'
      ]
    },
    svgWaveformType: 'afib'
  },

  // 12. BRADICARDIA SINUSAL
  {
    id: 'bradicardia_sinusal',
    nombre: 'Bradicardia Sinusal',
    categoria: 'bradicardia',
    esDesfibrilable: false,
    fcTipica: '< 50 lpm',
    criteriosECG: [
      'Ritmo regular con onda P sinusal idéntica positiva en DII, DIII y aVF que precede a cada QRS.',
      'Intervalo PR constante normal (120-200 ms). QRS estrecho.',
      'Frecuencia cardíaca < 50 lpm.'
    ],
    significadoClinico: 'Frecuente en deportistas sanos, pero en ancianos o patología aguda produce bajo gasto y shock.',
    tratamientoInmediato: {
      paso1: '¿SIGNOS DE INESTABILIDAD? (Hipotensión, dolor torácico, alteración mental, shock, insuficiencia cardíaca aguda):',
      farmaco1: '1ª LÍNEA: ATROPINA 1 mg IV en bolo rápido cada 3-5 min (máx 3 mg acumulados).',
      paso2: 'Si no responde a Atropina: MARCAPASOS TRANSCUTÁNEO (TCP) inmediato a 60-70 ppm con captura eléctrica y mecánica.',
      farmaco2: 'Alternativa o adyuvante: Infusión de Norepinefrina o Dopamina (5 a 20 mcg/kg/min) o Epinefrina (2 a 10 mcg/min).',
      cuidadosAvanzados: [
        'Si el paciente está estable y asintomático, solo monitorizar y observar.'
      ]
    },
    svgWaveformType: 'sinus_brady'
  },

  // 13. RITMO NODAL (Ritmo de la Unión AV)
  {
    id: 'ritmo_nodal',
    nombre: 'Ritmo Nodal (Ritmo de la Unión AV)',
    categoria: 'bradicardia',
    esDesfibrilable: false,
    fcTipica: '40 a 60 lpm (o < 40 si es escape lento)',
    criteriosECG: [
      'Ritmo regular con complejos QRS estrechos (< 120 ms).',
      'Ondas P ausentes (ocultas en el QRS), retrógradas invertidas inmediatamente antes o después del QRS con PR corto (< 120 ms).',
      'Frecuencia intrínseca del marcapasos de la unión: 40 a 60 lpm.',
      'Surge por fallo o depresión del nódulo sinusal (isquemia, fármacos, vagotonía).'
    ],
    significadoClinico: 'Mecanismo de escape fisiológico ante fallo del marcapasos sinusal. Si es lento genera bajo gasto.',
    tratamientoInmediato: {
      paso1: '¿Asintomático?: Observación y búsqueda de causas (intoxicación digitálica, betabloqueantes, calcioantagonistas, IAM inferior).',
      farmaco1: 'Si está INESTABLE: Atropina 1 mg IV en bolo (puede acelerar la unión o restaurar el nódulo SA).',
      paso2: 'Si la Atropina falla: Marcapasos Transcutáneo (TCP) o infusión de Dopamina/Adrenalina.',
      cuidadosAvanzados: [
        'Descartar infarto agudo de miocardio inferior (arteria coronaria derecha).'
      ]
    },
    svgWaveformType: 'sinus_brady'
  },

  // 14. BLOQUEO AV DE 1ER GRADO
  {
    id: 'bloqueo_av_1',
    nombre: 'Bloqueo AV de 1er Grado',
    categoria: 'bradicardia',
    esDesfibrilable: false,
    fcTipica: 'Normal o bradicárdica (50 a 80 lpm)',
    criteriosECG: [
      'Prolongación constante del intervalo PR > 200 ms (> 5 cuadritos pequeños o 1 cuadro grande).',
      'TODAS las ondas P son conducidas y van seguidas de un complejo QRS (relación 1:1 estricta).',
      'Intervalo PR fijo y uniforme en todos los latidos. QRS habitualmente estrecho.'
    ],
    significadoClinico: 'Retraso de la conducción en el nódulo AV. Benigno en la gran mayoría de los casos; raramente causa inestabilidad por sí mismo.',
    tratamientoInmediato: {
      paso1: '¡NO REQUIERE TRATAMIENTO DE URGENCIA! Monitorización de rutina.',
      farmaco1: 'Buscar causas: fármacos cronótropos negativos (Betabloqueantes, Verapamilo, Digoxina) o isquemia inferior.',
      paso2: 'Vigilar progresión a grados más avanzados de bloqueo si hay infarto agudo en curso.',
      cuidadosAvanzados: ['No administrar atropina salvo bradicardia extrema concomitante con síntomas.']
    },
    svgWaveformType: 'av_block_1'
  },

  // 15. BLOQUEO AV DE 2º GRADO MOBITZ 1 (Wenckebach)
  {
    id: 'bloqueo_av_2_mobitz1',
    nombre: 'Bloqueo AV de 2º Grado Mobitz I (Wenckebach)',
    categoria: 'bradicardia',
    esDesfibrilable: false,
    fcTipica: '40 a 60 lpm',
    criteriosECG: [
      'Alargamiento progresivo del intervalo PR latido tras latido hasta que una onda P se bloquea y NO produce complejo QRS ("Fenómeno de Wenckebach").',
      'Tras la pausa, el siguiente ciclo recomienza con el intervalo PR más corto.',
      'Complejos QRS habitualmente estrechos; lesión típicamente a nivel del nódulo AV.'
    ],
    significadoClinico: 'Típicamente transitorio y de buen pronóstico. Común en IAM de cara inferior (por isquemia nodal o hipertonía vagal).',
    tratamientoInmediato: {
      paso1: 'Si está asintomático: no requiere tratamiento inmediato, solo monitorización continua.',
      farmaco1: 'Si está INESTABLE (hipotensión, dolor torácico, mareo): ATROPINA 1 mg IV en bolo (suele responder muy bien por nivel nodal).',
      paso2: 'Si no responde a Atropina: Marcapasos Transcutáneo (TCP) de respaldo.',
      cuidadosAvanzados: ['Suele resolverse espontáneamente tras la reperfusión en el infarto inferior.']
    },
    svgWaveformType: 'av_block_2_1'
  },

  // 16. BLOQUEO AV DE 2º GRADO MOBITZ 2
  {
    id: 'bloqueo_av_2_mobitz2',
    nombre: 'Bloqueo AV de 2º Grado Mobitz II',
    categoria: 'bradicardia',
    esDesfibrilable: false,
    fcTipica: '30 a 50 lpm (ritmo lento con pausas)',
    criteriosECG: [
      'Intervalo PR constante y fijo en los latidos conducidos (no se alarga progresivamente).',
      'Súbitamente una o varias ondas P se bloquean sin previo aviso, sin conducir al ventrículo.',
      'Complejos QRS habitualmente anchos (> 120 ms) debido a lesión infranodal en el haz de His o ramas fasciculares.'
    ],
    significadoClinico: 'Ritmo de alto riesgo. Lesión estructural infranodal severa con altísimo riesgo de progresión repentina a Bloqueo AV Completo y Asistolia súbita.',
    tratamientoInmediato: {
      paso1: 'COLOCAR INMEDIATAMENTE PARCHES DE MARCAPASOS TRANSCUTÁNEO (TCP) LISTO PARA DISPARAR.',
      farmaco1: 'La Atropina habitualmente es INEFICAZ (e incluso peligrosa al aumentar la frecuencia auricular sobre un His enfermo).',
      paso2: 'Si hay inestabilidad: Iniciar Marcapasos Transcutáneo a 60 ppm con corriente suficiente para captura mecánica.',
      farmaco2: 'Infusión vasoactiva adyuvante: Dopamina (5-20 mcg/kg/min) o Norepinefrina / Epinefrina.',
      cuidadosAvanzados: [
        'Indicación urgente de marcapasos definitivo transvenoso en centro hospitalario.'
      ]
    },
    svgWaveformType: 'av_block_2_2'
  },

  // 17. BLOQUEO AV DE 3ER GRADO (COMPLETO)
  {
    id: 'bloqueo_av_3',
    nombre: 'Bloqueo AV de 3er Grado (Completo)',
    categoria: 'bradicardia',
    esDesfibrilable: false,
    fcTipica: '20 a 40 lpm (escape ventricular lento)',
    criteriosECG: [
      'DISOCIACIÓN AURICULOVENTRICULAR COMPLETA: las ondas P marchan a su propia frecuencia regular (P-P regular) y los complejos QRS a su propia frecuencia más lenta (R-R regular).',
      'Ninguna onda P conduce a los ventrículos (intervalos PR completamente variables y sin relación fija).',
      'QRS ancho si el ritmo de escape es idioventricular (< 40 lpm), o estrecho si es nodal alto (40-50 lpm).'
    ],
    significadoClinico: 'Emergencia hemodinámica crítica. Ausencia total de comunicación entre aurículas y ventrículos; riesgo inminente de asistolia por fallo del marcapasos de escape.',
    tratamientoInmediato: {
      paso1: '¡MARCAPASOS TRANSCUTÁNEO (TCP) DE INMEDIATO! Colocar parches anteroposteriores o anteroapicales. Programar 60-70 ppm y subir miliamperios (mA) hasta lograr captura eléctrica (espícula seguida de QRS ancho) y MECÁNICA (pulso concordante).',
      farmaco1: 'Proveer Pseudoanalgesia si está consciente (Midazolam 2-5 mg IV + Fentanilo 50-100 mcg IV) porque la estimulación muscular es muy dolorosa.',
      paso2: 'La Atropina raramente es efectiva con QRS ancho infranodal, pero se puede probar 1 mg mientras se conecta el TCP.',
      farmaco2: 'Infusión continua de Epinefrina (2 a 10 mcg/min) o Dopamina (5 a 20 mcg/kg/min) si el marcapasos no captura.',
      cuidadosAvanzados: [
        'Traslado de máxima prioridad a hemodinamia para marcapasos transvenoso urgente.'
      ]
    },
    svgWaveformType: 'av_block_3'
  }
];
