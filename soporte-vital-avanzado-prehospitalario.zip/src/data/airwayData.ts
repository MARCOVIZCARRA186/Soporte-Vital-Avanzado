export interface SRIPhase {
  fase: string;
  tiempo: string;
  titulo: string;
  objetivo: string;
  accionesClave: string[];
  farmacosYDispositivos?: string[];
  perlasClinicas: string[];
}

export const SRI_7P_PROTOCOL: SRIPhase[] = [
  {
    fase: '1. Preparación',
    tiempo: 'T - 10 min',
    titulo: 'Preparación de equipo, paciente y plan alternativo (SOAP-ME)',
    objetivo: 'Garantizar que todo el equipamiento, fármacos y planes de rescate estén listos y verificados antes de iniciar.',
    accionesClave: [
      'Nemotecnia SOAP-ME: Succión (activa y funcional), Oxígeno (fuente y BVM), Vía Aérea (laringoscopio/videolaringo, TET 7.0/7.5/8.0 con fiador, Bougie, supraglótico), Farmacología (inductor + paralizante cargados y rotulados), Monitorización (ECG, PANI, SpO2, Capnógrafo ETCO2).',
      'Verificar 2 accesos venosos permeables o acceso intraóseo disponible.',
      'Posicionamiento en "Olfateo" (alineación de ejes oral, faríngeo y laríngeo; rampa en pacientes obesos con trago alineado al esternón).'
    ],
    farmacosYDispositivos: [
      'Tubo endotraqueal con balón comprobado + Bougie elástico de Eschmann',
      'Videolaringoscopio o pala Macintosh/Miller con luz probada',
      'Dispositivo supraglótico (i-gel) y kit de cricotiroidotomía de rescate en mano'
    ],
    perlasClinicas: [
      'Nunca empujar el primer fármaco hasta tener en la mano el Bougie y el dispositivo supraglótico de rescate.',
      'La posición en rampa (tragus al esternón) mejora la visión laringoscópica hasta un 40% en pacientes con sobrepeso u obesos.'
    ]
  },
  {
    fase: '2. Preoxigenación',
    tiempo: 'T - 5 min',
    titulo: 'Desnitrogenación del reservorio alveolar',
    objetivo: 'Llenar la Capacidad Residual Funcional (CRF) con oxígeno al 100% para extender el tiempo de apnea segura de 1 a 6-8 minutos sin desaturación.',
    accionesClave: [
      'Mascarilla con reservorio (NRB) a 15 L/min con sello hermético durante al menos 3 a 5 minutos a volumen corriente normal (o 8 respiraciones a capacidad vital).',
      'Si el paciente hipoxémico no satura > 93% (shunt intrapulmonar como edema o neumonía), utilizar BVM con válvula PEEP (5-10 cmH2O) o CPAP/VMNI para reclutar alvéolos colapsados.',
      'Colocar cánula nasal a 15 L/min bajo la mascarilla para iniciar Oxigenación Apneica pasiva (NO DESAT).'
    ],
    farmacosYDispositivos: ['Mascarilla de no reinhalación', 'Cánula nasal para oxigenación apneica (15 L/min)', 'Válvula PEEP'],
    perlasClinicas: [
      'La oxigenación apneica con cánula nasal a 15 L/min durante el intento de laringoscopia mantiene el intercambio difusional de O2 incluso en apnea completa.',
      'Evitar ventilar con bolsa si el paciente respira espontáneamente (previene distensión gástrica y broncoaspiración masiva).'
    ]
  },
  {
    fase: '3. Pretratamiento',
    tiempo: 'T - 3 min',
    titulo: 'Atenuación de respuestas fisiológicas adversas (LOAD)',
    objetivo: 'Mitigar la descarga simpática, bradicardia refleja, aumento de PIC y broncoespasmo asociados a la laringoscopia.',
    accionesClave: [
      'Nemotecnia LOAD: Lidocaína (1.5 mg/kg si asma/aumento PIC), Opiáceo/Fentanilo (2-3 mcg/kg si TEC o disección aórtica), Atropina (0.02 mg/kg en pediatría o bradicardia previa), Desfasciculante (obsoleto).',
      'En shock o hipotensión: reanimación previa con volumen o bolo de vasopresor de empuje (Push-dose Norepinefrina o Fenilefrina) antes de inducir.'
    ],
    farmacosYDispositivos: ['Fentanilo 2 a 3 mcg/kg IV (en bolo lento)', 'Lidocaína 1.5 mg/kg IV', 'Atropina 0.5 mg'],
    perlasClinicas: [
      'Si el paciente está en shock (TAS < 90), omitir el Fentanilo de pretratamiento para evitar empeorar la hipotensión.',
      'Optimizar la hemodinámica PREVIA a la intubación: "Resucitar antes de intubar".'
    ]
  },
  {
    fase: '4. Parálisis con Inducción',
    tiempo: 'T = 0 min',
    titulo: 'Administración rápida casi simultánea de sedante y bloqueante neuromuscular',
    objetivo: 'Lograr pérdida inmediata de conciencia seguida rápidamente de relajación muscular completa.',
    accionesClave: [
      'Administrar primero el agente inductor (Ketamina 1.5-2 mg/kg o Etomidato 0.3 mg/kg) en bolo IV rápido.',
      'Inmediatamente después administrar el bloqueante neuromuscular (Rocuronio 1.2 mg/kg o Succinilcolina 1.5 mg/kg) en bolo IV rápido y empujar con 20 mL de SF.',
      'No ventilar con presión positiva durante este periodo a menos que la SpO2 caiga por debajo de 90%.'
    ],
    farmacosYDispositivos: [
      'Inductor: Ketamina 1.5-2 mg/kg (ideal shock/asma) o Etomidato 0.3 mg/kg o Propofol 1.5-2 mg/kg (solo normotensos)',
      'Paralizante: Rocuronio 1.2 mg/kg IV o Succinilcolina 1.5-2 mg/kg IV'
    ],
    perlasClinicas: [
      'En pacientes en shock séptico o trauma severo, la dosis del inductor debe reducirse a la mitad (Ketamina 0.75-1 mg/kg) y la del bloqueante debe mantenerse o aumentarse ligeramente (Rocuronio 1.2-1.6 mg/kg) debido al retraso circulatorio.',
      'Esperar 45 a 60 segundos de reloj antes de insertar el laringoscopio; la relajación completa de la mandíbula es el indicador.'
    ]
  },
  {
    fase: '5. Protección y Posición',
    tiempo: 'T + 30 a 60 s',
    titulo: 'Mantenimiento de la permeabilidad y maniobras laríngeas externas',
    objetivo: 'Esperar la relajación óptima sin manipular prematuramente la vía aérea.',
    accionesClave: [
      'Verificar pérdida del reflejo palpebral y flacidez mandibular antes de laringoscopar.',
      'Maniobra de Sellick (presión cricoidea): YA NO SE RECOMIENDA de rutina, puede empeorar la visualización y desalinear la glotis.',
      'Maniobra BURP (Backward, Upward, Rightward Pressure sobre el cartílago tiroides): muy útil para mejorar la visión glótica si es solicitada por el operador.'
    ],
    farmacosYDispositivos: ['Aspirador Yankauer encendido junto a la cabeza'],
    perlasClinicas: [
      'Si se utiliza Sellick y se tiene dificultad para visualizar las cuerdas, ordenar inmediatamente que liberen la presión cricoidea.'
    ]
  },
  {
    fase: '6. Paso del Tubo y Comprobación',
    tiempo: 'T + 60 a 90 s',
    titulo: 'Laringoscopia, inserción bajo visión directa y confirmación cuádruple',
    objetivo: 'Colocar el tubo en la tráquea al primer intento y confirmar su posición inequívoca.',
    accionesClave: [
      'Laringoscopia bimanual: avanzar el laringoscopio por comisura derecha barriendo la lengua.',
      'Si se usa Bougie: introducir en tráquea, sentir los "clics" traqueales o tope de carina a 25-30 cm, y deslizar el TET sobre el bougie manteniendo rotación de 90° antihoraria.',
      'Inflar balón con 6-8 mL de aire (presión 20-30 cmH2O).',
      'Confirmación patrón oro: Capnografía cuantitativa de onda continua (ETCO2) mostrando al menos 5-6 ondas cuadrangulares sostenidas.',
      'Auscultación en 5 puntos: epigastrio primero (silente), bases axilares y ápices pulmonares simétricos.'
    ],
    farmacosYDispositivos: ['Detector cuantitativo de CO2 (ETCO2 de onda)', 'Manómetro de cuff', 'Auscultador'],
    perlasClinicas: [
      '¡Si no hay onda de capnografía ETCO2, el tubo está en el esófago hasta demostrar lo contrario! Retirar inmediatamente.',
      'Regla de profundidad en incisivos: Talla del tubo × 3 (ej. Tubo 7.5 × 3 = 22.5 cm en comisura labial).'
    ]
  },
  {
    fase: '7. Cuidados Post-intubación',
    tiempo: 'T + 1 min en adelante',
    titulo: 'Mantenimiento sedoanalgésico, fijación y configuración ventilatoria',
    objetivo: 'Prevenir extubación accidental, asegurar ventilación protectora y mantener analgesia profunda.',
    accionesClave: [
      'Fijar firmemente el tubo con fijador mecánico o cinta adhesiva técnica.',
      'Iniciar sedación y analgesia continua inmediata (Fentanilo + Midazolam/Propofol). Los paralizantes duran hasta 60 min y el paciente no debe despertar paralizado (trauma psicológico extremo).',
      'Configurar ventilación mecánica protectora: VT 6-8 mL/kg de peso ideal, PEEP 5 cmH2O, Pplat < 30 cmH2O.',
      'Colocar sonda orogástrica para descompresión gástrica.',
      'Reevaluar signos vitales cada 3-5 minutos (vigilar hipotensión post-intubación por supresión simpática y aumento de presión intratorácica).'
    ],
    farmacosYDispositivos: ['Fijador comercial de TET', 'Infusión continua de sedación', 'Sonda orogástrica N° 16'],
    perlasClinicas: [
      'El colapso hemodinámico posintubación es común: estar listos con bolos de 250 mL de cristaloide o infusión de Noradrenalina.'
    ]
  }
];

export const DIFFICULT_AIRWAY_SCALES = {
  lemon: [
    { letra: 'L', titulo: 'Look externally (Mirar externamente)', detalle: 'Trauma facial severo, barba espesa, micrognatia, obesidad mórbida, cuello corto.' },
    { letra: 'E', titulo: 'Evaluate 3-3-2 (Evaluar regla 3-3-2)', detalle: '3 traveses de dedos de apertura bucal / 3 dedos distancia hioideo-mentoniana / 2 dedos distancia tiro-hioidea.' },
    { letra: 'M', titulo: 'Mallampati score (Escala de Mallampati)', detalle: 'Clase I: paladar blando, fauces, úvula y pilares; Clase II: paladar blando, fauces y úvula; Clase III: paladar blando y base úvula; Clase IV: solo paladar duro.' },
    { letra: 'O', titulo: 'Obstruction (Obstrucción de vía aérea)', detalle: 'Estridor inspiratorio, sialorrea/babeo, cuerpo extraño, edema de glotis, absceso periamigdalino.' },
    { letra: 'N', titulo: 'Neck mobility (Movilidad cervical)', detalle: 'Collarín cervical colocado, espondilitis anquilosante, trauma de columna cervical, artrosis severa.' }
  ],
  mallampati: [
    { clase: 'Clase I', visibilidad: 'Paladar blando, úvula completa, fauces y pilares amigdalinos visibles.', dificultad: 'Baja probabilidad de dificultad' },
    { clase: 'Clase II', visibilidad: 'Paladar blando, fauces y mayor parte de la úvula visibles.', dificultad: 'Dificultad leve' },
    { clase: 'Clase III', visibilidad: 'Paladar blando y solo la base de la úvula visibles.', dificultad: 'Alta probabilidad de vía aérea difícil' },
    { clase: 'Clase IV', visibilidad: 'Solo se visualiza el paladar duro. Ni paladar blando ni úvula.', dificultad: 'Vía aérea extremadamente difícil' }
  ],
  cormackLehane: [
    { grado: 'Grado I', vision: 'Visualización completa de la glotis, cuerdas vocales y comisura anterior.', conducta: 'Intubación sencilla' },
    { grado: 'Grado II', vision: 'Solo se visualiza la porción posterior de las cuerdas vocales o aritenoides.', conducta: 'Usar estilete/Bougie' },
    { grado: 'Grado III', vision: 'Solo se visualiza la epiglotis, sin visualizar glotis ni cuerdas vocales.', conducta: 'Vía aérea difícil: uso obligatorio de Bougie o videolaringoscopio' },
    { grado: 'Grado IV', vision: 'No se visualiza ni siquiera la epiglotis (solo paladar blando / lengua).', conducta: 'Fallo laringoscópico inminente: pasar a rescate supraglótico o rescate quirúrgico' }
  ]
};

export const SUPRAGLOTTIC_DEVICES = [
  {
    dispositivo: 'i-gel',
    caracteristica: 'Sellado elastomérico no inflable de termoplástico médico con canal gástrico y bloqueador de mordida.',
    tamanos: [
      { num: 'Tamaño 1', peso: '2 a 5 kg (Neonato)', color: 'Rosa' },
      { num: 'Tamaño 1.5', peso: '5 a 12 kg (Lactante)', color: 'Azul' },
      { num: 'Tamaño 2', peso: '10 a 25 kg (Pediátrico pequeño)', color: 'Gris' },
      { num: 'Tamaño 2.5', peso: '25 a 35 kg (Pediátrico grande)', color: 'Blanco' },
      { num: 'Tamaño 3', peso: '30 a 60 kg (Adulto pequeño)', color: 'Amarillo' },
      { num: 'Tamaño 4', peso: '50 a 90 kg (Adulto mediano/estándar)', color: 'Verde' },
      { num: 'Tamaño 5', peso: '> 90 kg (Adulto grande)', color: 'Naranja' }
    ],
    consejos: 'Excelente tasa de inserción al primer intento (> 95%), permite paso de sonda gástrica 12F e intubación a ciegas guiada por Bougie o fibrobroncoscopio.'
  },
  {
    dispositivo: 'Tubo Laríngeo (LTS-D)',
    caracteristica: 'Doble balón inflable con canal de aspiración gástrica. Se infla con jeringa codificada por color.',
    tamanos: [
      { num: 'Tamaño 3', peso: '< 155 cm de estatura', color: 'Amarillo' },
      { num: 'Tamaño 4', peso: '155 a 180 cm de estatura', color: 'Rojo' },
      { num: 'Tamaño 5', peso: '> 180 cm de estatura', color: 'Morado' }
    ],
    consejos: 'Muy seguro en rescate durante RCP prehospitalario con compresiones continuas.'
  }
];

export const CRICOTHYROIDOTOMY_PROTOCOL = {
  indicacion: 'Fallo en intubar y fallo en oxigenar (CICO - Can’t Intubate, Can’t Oxygenate) tras intento de rescate con dispositivo supraglótico o BVM.',
  tecnicaQuirurgica: [
    '1. Posición: Hiperextensión cervical moderada (si no hay sospecha de trauma cervical). Operador al lado derecho del paciente si es diestro.',
    '2. Palpación de referencia anatómica: Localizar cartílago tiroides (nuez de Adán), deslizar el dedo hacia abajo en línea media hasta sentir la depresión de la Membrana Cricotiroidea (entre tiroides y cricoides).',
    '3. Incisión vertical cutánea: 2 a 3 cm en línea media sobre la membrana cricotiroidea para exponer fascia y evitar vasos colaterales.',
    '4. Incisión transversal en membrana: Cortar horizontalmente la membrana cricotiroidea con bisturí N° 10 u 11.',
    '5. Dilatación o tracción: Mantener el bisturí girado o introducir pinza/dedo.',
    '6. Inserción de Bougie: Introducir la punta roma del Bougie orientada 10-15 cm hacia los pulmones.',
    '7. Deslizamiento de Tubo: Deslizar sobre el Bougie un Tubo Endotraqueal lubricado N° 6.0 (o cánula de traqueostomía 6.0) hasta el tope del balón.',
    '8. Inflado y comprobación: Inflar el balón (3-5 mL de aire), conectar capnógrafo ETCO2 y verificar ventilación pulmonar bilateral simétrica.'
  ],
  perlasSalvavidas: [
    'No dudar: la hipoxia cerebral irreversible se produce en menos de 4 minutos.',
    'La regla nemotécnica rápida es: "Bisturí, Dedo, Bougie, Tubo" (Scalpel, Finger, Bougie, Tube).',
    'La complicación más frecuente es el retraso en la toma de decisión por temor del reanimador.'
  ]
};
